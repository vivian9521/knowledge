package com.design;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/4
 * @Modified By:
 * @since DK 1.8
 */
public class TestThrowable extends RuntimeException{

}
