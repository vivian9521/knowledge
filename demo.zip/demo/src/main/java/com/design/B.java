package com.design;

import java.util.List;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/8/29
 * @Modified By:
 * @since DK 1.8
 */
public class B extends A{

    public B(String s){
        System.out.println(s);
    }
    // 如下funD方法会报错
    public static void funC(List<? extends A> listA) {
        // ...
    }
    public static void funD(List<B> listB) {
        funC(listB); // Unresolved compilation problem: The method doPrint(List<A>) in the type test is not applicable for the arguments (List<B>)
        // ...
    }
}

