package com.design;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/4
 * @Modified By:
 * @since DK 1.8
 */
public class ThreadPools {
    public static void main(String[] args) {
        ExecutorService executorService = Executors.newFixedThreadPool(3);
        executorService.submit(new Runnable() {
            @Override
            public void run() {

            }
        });

    }

    public void run(){
        throw new TestThrowable();
    }
}
