package com.design;


import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.Exchanger;
import java.util.concurrent.Semaphore;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/4
 * @Modified By:
 * @since DK 1.8
 */
public class BaseCode{
    public static void main(String[] args) {
        //-128-127
//        Integer a = Integer.valueOf(129);
//        Integer b = Integer.valueOf(129);
//        System.out.println(a==b);
//
//        Integer c = new Integer(1);
//        Integer d = new Integer(1);
//        System.out.println(c==d);

        String s = new String("1");
        String s1 = s.intern();
        System.out.println(s.intern()==s1);

//        Double.isNaN()
        short s2= 1;
//        s2=s2+1;
        System.out.println();
        s2 = (short) (s2 + 1);
        System.out.println(s2);

        Integer x = new Integer(1);
        Integer y = new Integer(1);
        System.out.println(x.equals(y)); // true
        System.out.println(x == y);      // false

        Integer x1 = 128;
        Integer x2 = 128;
        System.out.println(x1 == x2);
        BaseCode baseCode = new BaseCode();
//        baseCode.hashCode()

        CountDownLatch countDownLatch=new CountDownLatch(1);
        Exchanger exchanger=new Exchanger();
//        exchanger.exchange();
        try {
            Semaphore semaphore=new Semaphore(3);
            semaphore.acquire();
            semaphore.release();

        }catch (Exception e){
            e.printStackTrace();
        }


        try {
            CyclicBarrier cyclicBarrier=new CyclicBarrier(5,()->{

            });
//            cyclicBarrier.await();
        } catch (Exception e) {
            e.printStackTrace();
        }

//        long x=111;
//        switch (x){
//            case 111:
//                break;
//        }

    }


    public void run1(final int i){
    }
}


