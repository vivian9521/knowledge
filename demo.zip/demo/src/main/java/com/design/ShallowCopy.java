package com.design;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/5
 * @Modified By:
 * @since DK 1.8
 */
public class ShallowCopy {
    public static void main(String[] args) throws CloneNotSupportedException {
        Teacher1 teacher1 = new Teacher1();
        teacher1.setName("riemann");
        teacher1.setAge(28);

        Student student1 = new Student();
        student1.setName("edgar");
        student1.setAge(18);
        student1.setTeacher1(teacher1);

        Student student2 = (Student) student1.clone();
        System.out.println("-------------拷贝后-------------");
        System.out.println(student2.getName());
        System.out.println(student2.getAge());
        System.out.println(student2.getTeacher1().getName());
        System.out.println(student2.getTeacher1().getAge());

        System.out.println("-------------修改老师的信息后-------------");
        // 修改老师的信息
        teacher1.setName("jack");
        System.out.println("student1的teacher为： " + student1.getTeacher1().getName());
        System.out.println("student2的teacher为： " + student2.getTeacher1().getName());

    }
}

class Teacher1 implements Cloneable {
    private String name;
    private int age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}

class Student implements Cloneable {
    private String name;
    private int age;
    private Teacher1 teacher1;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public Teacher1 getTeacher1() {
        return teacher1;
    }

    public void setTeacher1(Teacher1 teacher1) {
        this.teacher1 = teacher1;
    }

    public Object clone() throws CloneNotSupportedException {
        Object object = super.clone();
        return object;
    }
}
