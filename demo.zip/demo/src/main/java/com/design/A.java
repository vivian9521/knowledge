package com.design;

import net.sourceforge.pinyin4j.PinyinHelper;
import net.sourceforge.pinyin4j.format.HanyuPinyinCaseType;
import net.sourceforge.pinyin4j.format.HanyuPinyinOutputFormat;
import net.sourceforge.pinyin4j.format.HanyuPinyinToneType;
import net.sourceforge.pinyin4j.format.HanyuPinyinVCharType;
import net.sourceforge.pinyin4j.format.exception.BadHanyuPinyinOutputFormatCombination;

import javax.sound.midi.Track;
import java.util.ArrayDeque;
import java.util.Collections;
import java.util.HashMap;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.Stack;
import java.util.WeakHashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/8/29
 * @Modified By:
 * @since DK 1.8
 */
public class A {
    public static void main(String[] args) {
//        PriorityQueue
//        ArrayDeque
//        Integer b = 2;
//        final Integer a = b;
//        Integer c = 3;
//        b = c;
//        Stack<>
//        B b = new B("1");
//        final B a = b;
//        B c = new B("2");
//        b = c;
//        System.out.println(a);
//        System.out.println(b);
//        try {
//        } catch (NumberFormatException e) {
//        } catch (IllegalArgumentException e) {
//        }

//        HashMap<String, String> map = new HashMap<>();
//
//        Set<Object> set = Collections.newSetFromMap(new WeakHashMap<>())
//        ;
//        String s = "测试";
//        s = s.replace("", " ");
//        String piYin = getPiYin(s);
//        System.out.println(piYin);
//
//        Long a = 1L;
//        a = 2L;
//        FutureTask<Integer> task = new FutureTask<>(new Callable<Integer>() {
//            @Override
//            public Integer call() throws Exception {
//                return null;
//            }
//        });
//        new Thread(task);


//        ExecutorService executorService = Executors.newSingleThreadExecutor();
//        for (int i = 0; i < 5; i++) {
//            executorService.execute(new MyRunnable1());
//        }
//        executorService.shutdown();
//        executorService.shutdownNow();
        float a = 1.0f;
        float b = 2.0f;
        double c = a + b;
        System.out.println(c);


        final short d = 1;
        final short e = 2;
        short f = d + e;
        System.out.println(f);
    }

    public static String getPiYin(String src) {

        HanyuPinyinOutputFormat outFormat = new HanyuPinyinOutputFormat();
        outFormat.setCaseType(HanyuPinyinCaseType.UPPERCASE);
        outFormat.setToneType(HanyuPinyinToneType.WITHOUT_TONE);
        outFormat.setVCharType(HanyuPinyinVCharType.WITH_V);
        try {
            return PinyinHelper.toHanYuPinyinString(src, outFormat, " ",false);
        } catch (BadHanyuPinyinOutputFormatCombination e1) {
            e1.printStackTrace();
            return src;
        }
    }
}
