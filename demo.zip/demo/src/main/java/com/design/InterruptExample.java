package com.design;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/9/1
 * @Modified By:
 * @since DK 1.8
 */
public class InterruptExample {
    private static class MyThread2 extends Thread {
        @Override
        public void run() {
            while (!interrupted()) {
                // ..
            }
            System.out.println("Thread end");
        }
    }

    public static void main(String[] args) throws InterruptedException {
        MyThread2 myThread2 = new MyThread2();
        Thread.sleep(1);
    }
}
