package com.design;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/5
 * @Modified By:
 * @since DK 1.8
 */
public abstract class AbstractClass {
    abstract void run();
}
