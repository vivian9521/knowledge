package com.design;

import java.lang.reflect.InvocationTargetException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.zip.DeflaterOutputStream;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/4/18
 * @Modified By:
 * @since DK 1.8
 */
public class Test2 {
    public static void main(String[] args){
        List<Integer> a=new ArrayList<>();
        List<String> b=new ArrayList<>();
        System.out.println(a.getClass()==b.getClass());
        a.add(1);
        try {
            a.getClass().getMethod("add",Object.class).invoke(a,"asd");
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(a);
        ArrayList<String> list2 = new ArrayList<String>(); //第二种 情况
        list2.add("1");
        System.out.println(list2.getClass());
//        a.add(1);
//        a.add(2);
//        List<Integer> collect = a.stream().filter(x -> Objects.equals(3, x)).collect(Collectors.toList());
//        System.out.println(collect.size());
//        System.out.println(collect.contains(null));
//        Math.abs(-2);
//        Calendar instance = Calendar.getInstance();
//        Date date=new Date();
//        System.out.println(date);
//        LocalDate localDate=LocalDate.now();
    }

    public void arrMeth(){
//        List<String>[] lsa = new List<String>[10]; // Not really allowed.
//        Object o = lsa;
//        Object[] oa = (Object[]) o;
//        List<Integer> li = new ArrayList<Integer>();
//        li.add(new Integer(3));
//        oa[1] = li; // Unsound, but passes run time store check
//        String s = lsa[1].get(0); // Run-time error ClassCastException.


        List<?>[] lsa = new List<?>[10]; // OK, array of unbounded wildcard type.
        Object o = lsa;
        Object[] oa = (Object[]) o;
        List<Integer> li = new ArrayList<Integer>();
        li.add(new Integer(3));
        oa[1] = li; // Correct.
        Integer i = (Integer) lsa[1].get(0); // OK

    }

    public <T> T getNewClass(Class<T> clazz) throws IllegalAccessException, InstantiationException {
        T t = clazz.newInstance();
        return t;
    }
}


class Test3{
    public static void main(String[] args) {
        List<?>[] lsa = new List<?>[10]; // OK, array of unbounded wildcard type.
        System.out.println(lsa.getClass());
        Object o = lsa;
        Object[] oa = (Object[]) o;
        List<Integer> li = new ArrayList<Integer>();
        li.add(new Integer(3));
        oa[1] = li; // Correct.
        Integer i = (Integer) lsa[1].get(0); // OK
        System.out.println(i);
    }
}
