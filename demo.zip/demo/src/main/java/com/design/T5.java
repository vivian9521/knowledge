package com.design;

import java.util.Comparator;
import java.util.Objects;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/8/25
 * @Modified By:
 * @since DK 1.8
 */
public class T5  {
    public static void main(String[] args) {
        int a = 0;
        int b = 2;
        boolean equals = Objects.equals(a, b);

    }
}
