package com.design;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/5
 * @Modified By:
 * @since DK 1.8
 */
public class CloneCode {
    public static void main(String[] args) {
//        Teacher teacher1 = new Teacher();
//        teacher1.setName("333");
        ShallowCloneExample e1 = new ShallowCloneExample();
        e1.setName(8);
        ShallowCloneExample e2 = null;
//        e1.setName(teacher1);
        try {
            e2 = e1.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }
        e1.set(2, 222);
        e1.setName(10);
//        teacher1.setName("666");
        System.out.println(e1.getName()==e2.getName());
        System.out.println(e2.getName());

    }
}

class ShallowCloneExample implements Cloneable {
    private int[] arr;

    private Integer name;



    public ShallowCloneExample() {
        arr = new int[10];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = i;
        }
    }

    public Integer getName() {
        return name;
    }

    public void setName(Integer name) {
        this.name = name;
    }

    public void set(int index, int value) {
        arr[index] = value;
    }

    public int get(int index) {
        return arr[index];
    }

    @Override
    protected ShallowCloneExample clone() throws CloneNotSupportedException {
        return (ShallowCloneExample) super.clone();
    }
}

class Teacher {
    private String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

//    @Override
//    protected Object clone() throws CloneNotSupportedException {
//        return super.clone();
//    }
}