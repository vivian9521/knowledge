package com.design;

import java.util.Collections;
import java.util.Comparator;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/5
 * @Modified By:
 * @since DK 1.8
 */
public class DriverClass {
    public static void main(String[] args) throws ClassNotFoundException {
//        Class<?> aClass = Class.forName("com.mysql.jdbc.Driver");

        byte a=1;
        byte b=2;
//        b=a+b;
        b+=a;

        DriverClass driverClass=new DriverClass();
        driverClass.hashCode();

        System.out.println(3*0.1==0.3);

        Comparator comparator= (o1, o2) -> 0;
        Comparable comparable= o -> 0;

//        Collections.sort();
    }
}
