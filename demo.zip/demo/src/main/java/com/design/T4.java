package com.design;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/8/24
 * @Modified By:
 * @since DK 1.8
 */
public class T4 {
    private static int c;
    public int d;
    public static void main(String[] args) throws CloneNotSupportedException {
//        String s1 = new String("aaa");
//        String s3 = s1.intern();
//        System.out.println(s3 == s1);
//
//        String s4 = "aaa";
//        System.out.println(s1 == s4);
//        System.out.prin;tln(s1.intern() == s3);  // true

//        List<String> list = new ArrayList<>();
//        list.add("a");
//        func(list);
//        System.out.println(list);

//        float l =  1.1f;
//        System.out.println(l);
//
//        T4 a = new T4();
//        Object clone = a.clone();
//        System.out.println(a.toString());
//        System.out.println(a.hashCode());
//        double a = 233.10;
//        double b =233.1;
//        System.out.println(a == b);

        func(new ArrayList<>());
    }
    public static  void func(List<String> list){
        list = new ArrayList<>();
        System.out.println(list);

        int c1 = c;
        new String(new byte[]{});

    }
}
