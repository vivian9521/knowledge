package com.design;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/9/1
 * @Modified By:
 * @since DK 1.8
 */
public interface A2 extends A1{
}
