package com.design;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.FutureTask;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/4
 * @Modified By:
 * @since DK 1.8
 */
public class MyThread {

    public static void main(String[] args) {

        Thread thread1=new MyThread1("线程1");
        thread1.start();

        Runnable runnable=new MyRunnable();
        Thread thread2 = new Thread(runnable,"线程2");
        thread2.start();

        MyCallable myCallable = new MyCallable();
        FutureTask task=new FutureTask(myCallable);
        Thread thread3=new Thread(task,"线程3");
        thread3.start();

        try {
            System.out.println(Thread.currentThread().getName()+task.get());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}

class  MyThread1 extends Thread{
    public MyThread1(String name) {
        super(name);
    }

    @Override
    public void run() {
        super.run();
        for (int i=0;i<=10;i++){
            System.out.println(Thread.currentThread().getName()+"=="+i);
        }
    }
}

class MyRunnable implements Runnable{

    @Override
    public void run() {
        for (int i=0;i<=10;i++){
            System.out.println(Thread.currentThread().getName()+"=="+i);
        }
    }
}

class MyCallable implements Callable {

    @Override
    public Object call() throws Exception {
        int sum=0;
        for (int i=0;i<=10;i++){
            sum+=i;
            System.out.println(Thread.currentThread().getName()+"=="+i);
        }
        return sum;
    }
}

