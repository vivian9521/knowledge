package com.base.outputstream;

import java.io.PrintStream;
import java.io.PrintWriter;

/**
 * @Auther:vivian
 * @Description:打印流
 * @Date:Created in 2022/7/13
 * @Modified By:
 * @since DK 1.8
 */
public class PrintStreamDemo {
    public static void main(String[] args) {

        try(PrintStream pr=new PrintStream("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\demo08.txt");
        ){
            pr.write("测试111".getBytes());
            pr.println("测试111111");
            pr.println("2222");
            pr.println(123);
            pr.println("是叫姐夫".toCharArray());
        }catch (Exception e){
            e.printStackTrace();
        }

        try(PrintWriter pr=new PrintWriter("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\demo09.txt")){
            pr.println("测试111111");
            pr.println("2222");
            pr.println(123);
            pr.println("是叫姐夫".toCharArray());
            pr.write("范围范围分为非".toCharArray());
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
