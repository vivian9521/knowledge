package com.base.outputstream;


import java.io.FileOutputStream;
import java.io.OutputStream;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/11
 * @Modified By:
 * @since DK 1.8
 */
public class FileOutputStreamDemo {
    public static void main(String[] args) {
        try(OutputStream os=new FileOutputStream("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\demo02.txt")) {
            byte[] bytes = "java是最优美的语言".getBytes();
            os.write(bytes);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
