package com.base.outputstream;

import java.io.FileWriter;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/11
 * @Modified By:
 * @since DK 1.8
 */
public class WriterDemo {
    public static void main(String[] args) {
        try(FileWriter os=new FileWriter("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\demo04.txt",true)){
            os.write("Java优美的语言");
            os.write("\r\n");
            os.write("Java优美的语言".toCharArray());
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
