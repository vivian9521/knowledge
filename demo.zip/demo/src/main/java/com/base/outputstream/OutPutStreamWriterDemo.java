package com.base.outputstream;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.lang.reflect.WildcardType;
import java.net.InetAddress;
import java.net.InetSocketAddress;

/**
 * @Auther:vivian
 * @Description:字节流转字符流，定义编码方式
 * @Date:Created in 2022/7/12
 * @Modified By:
 * @since DK 1.8
 */
public class OutPutStreamWriterDemo {
    public static void main(String[] args) {
        try(OutputStream os=new FileOutputStream("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\demo07.txt");
            OutputStreamWriter ost=new OutputStreamWriter(os,"utf-8");
            BufferedWriter writer=new BufferedWriter(ost);
        ){
            writer.write("JAVA蔡文姬饿哦服务加配方开网课佩服我陪没法玩");
            writer.newLine();
            writer.write("法尔馥马尔麻烦帕尔发泡么法怕么发么反扒！");
        }catch (Exception e){
            e.printStackTrace();
        }
//        File file = new File();
//        InetAddress address = new InetSocketAddress();
    }
}
