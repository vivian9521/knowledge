package com.base.unsafe;

import java.util.concurrent.atomic.AtomicMarkableReference;
import java.util.concurrent.atomic.AtomicStampedReference;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/2/22
 * @Modified By:
 * @since DK 1.8
 */
public class WaitNotifyTest {

//    private final Integer a;

    public static void main(String[] args) {

//        AtomicMarkableReference reference = new AtomicMarkableReference();

//        AtomicStampedReference reference = new AtomicStampedReference();

        MyThread myThread = new MyThread();
        synchronized (myThread) {
            try {
                myThread.start();
                // 主线程睡眠3s
                Thread.sleep(3000);
                System.out.println("before wait");
                // 阻塞主线程
                myThread.wait();
                System.out.println("after wait");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    static class  MyThread extends Thread{
        @Override
        public void run() {
            synchronized (this){
                System.out.println("before notify");
                notify();
                System.out.println("after notify");
            }
        }
    }
}
