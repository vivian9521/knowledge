package com.base.unsafe;

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerArray;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/2/20
 * @Modified By:
 * @since DK 1.8
 */
public class Atomic {

    public static void main(String[] args) {
        AtomicInteger atomicInteger = new AtomicInteger();
        int andAdd = atomicInteger.getAndAdd(2);
        System.out.println(andAdd);

        AtomicIntegerArray arr = new AtomicIntegerArray(2);
        int i = arr.get(1);
        System.out.println(i);
    }
}
