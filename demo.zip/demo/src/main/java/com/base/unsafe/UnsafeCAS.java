package com.base.unsafe;

import sun.misc.Unsafe;

import java.lang.reflect.Field;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/2/16
 * @Modified By:
 * @since DK 1.8
 */
public class UnsafeCAS {
    public static void main(String[] args) throws NoSuchFieldException {
        Unsafe unsafe = GetUnSafe.get();
        /**
         * CAS操作
         * Compare And Swap（比较并交换），当需要改变的值为期望的值时，那么就替换它为新的值，是原子
         * （不可在分割）的操作。很多并发框架底层都用到了CAS操作，CAS操作优势是无锁，可以减少线程切换耗费
         * 的时间，但CAS经常失败运行容易引起性能问题，也存在ABA问题。在Unsafe中包含compareAndSwapObject、
         * compareAndSwapInt、compareAndSwapLong三个方法，compareAndSwapInt的简单示例如下。
         */
        Data data = new Data();
        data.setId(1L);
        Field id = data.getClass().getDeclaredField("id");
        long l = unsafe.objectFieldOffset(id);
        id.setAccessible(true);
//比较并交换，比如id的值如果是所期望的值1，那么就替换为2，否则不做处理
        unsafe.compareAndSwapLong(data,1L,1L,2L);
        System.out.println(data.getId());
    }
}
