package com.base.unsafe;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/2/16
 * @Modified By:
 * @since DK 1.8
 */
public class Data {
    private Long id;

    private String name;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
