package com.base.testprint;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/9/21
 * @Modified By:
 * @since DK 1.8
 */
class Base {
    public Base() {
        System.out.println("Base");
    }
    public Base(int c) {
        System.out.println("Base--" + c);
    }

    public void run (){
        System.out.println("111111");
    }
}
interface DerivedInter {
    void run();
    void walk();
}
public class Derived implements DerivedInter{
    public Derived() {
        System.out.println("Derived");
    }
    public Derived(int c) {
//        super(c);
        System.out.println("Derived--" + c);
    }
    public static void main(String[] args) {
        DerivedInter inter = new Derived();
        inter.run();
        inter.walk();
        Derived a = new Derived();
        Derived b = new Derived(33);
    }

    @Override
    public void run() {

    }

    @Override
    public void walk() {

    }
}



