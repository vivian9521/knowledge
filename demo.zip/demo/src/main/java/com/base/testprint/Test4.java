package com.base.testprint;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/9/21
 * @Modified By:
 * @since DK 1.8
 */
public class Test4 {

    public static String func() throws Exception {
        String ret = "dokey";
        try {
            B1 b = new B1();
            C1 c = new C1();
            c.s.append("ey");
            if (b.s.toString().equals("okey")) {
                throw new Foo5("Foo");
            } else {
                throw new Bar1("Bar");
            }
        } catch (Bar1 e) {
            System.out.println(e.getMessage());
            return ret;
        } catch (Foo5 e) {
            System.out.println(e.getMessage());
            return ret;
        } finally {
            System.out.println("hello");
            ret = "world";
        }
    }
    public static void main(String[] args) throws Exception {
        System.out.println(func());
    }
}

interface A1 {
    StringBuilder s = new StringBuilder("ok");
}
class B1 implements A1 {}
class C1 implements A1 {}
class Foo5 extends Exception {public Foo5(String m) {super(m);}}
class Bar1 extends Foo5 {public Bar1(String m) {super(m);}}
