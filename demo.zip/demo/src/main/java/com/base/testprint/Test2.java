package com.base.testprint;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/9/21
 * @Modified By:
 * @since DK 1.8
 */
public class Test2 {
    public static void main(String[] args) {
        Integer a = new Integer(200);
        int b = 200;
        Integer c = 200;
        Integer d = 200;
        Integer e = 3;
        Integer f = 3;
        Double g = 3.0;
        Double h = 3.0;
        System.out.println(a == b); //true
        System.out.println(a == c); //false
        System.out.println(c == d); //false
        System.out.println(e == f); //true
        System.out.println(g == h); //false
    }
}
