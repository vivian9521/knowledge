package com.base.testprint;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/9/21
 * @Modified By:
 * @since DK 1.8
 */
public class Foo {
    String a = new String("hello");
    StringBuilder b = new StringBuilder("okey");
    public static void main(String[] args) {
        Foo bar = new Foo();
        bar.change(bar.a, bar.b);
        System.out.println(bar.a); // hello
        System.out.println(bar.a.hashCode());
        System.out.println(bar.b); // okey dokey
    }
    public void change(String x, StringBuilder y) {
        x += " world";
        System.out.println(x.hashCode());
        y.append(" dokey");
    }
}
