package com.base.testprint;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/9/21
 * @Modified By:
 * @since DK 1.8
 */
public class Foo2 {
    public static void main(String[] args) {
        B s = new B();
        System.out.println(s.f(3.0)); //2.0
        System.out.println(s.f(3)); //6
        System.out.println(s.f('3')); //33
    }

}

class A {
    public String f(double x) {
        return String.valueOf(x - 1);
    }
    protected String f(int x) {
        return String.valueOf(x * x);
    } }
class B extends A {
    protected int f(char x) {
        return Integer.parseInt(String.valueOf(x) + x);
    }
    public String f(int x) {
        return String.valueOf(x + x);
    } }
