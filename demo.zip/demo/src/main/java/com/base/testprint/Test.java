package com.base.testprint;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/9/21
 * @Modified By:
 * @since DK 1.8
 */
public class Test {
    public static void main(String[] args) {
        String[] a = {"e", "a", "t"};
        Integer[] b = {1, 6, 3};
        Foo1.<String,Integer>func(a, b);
        Foo1.<Integer,String>func(b, a);
    }


}
class Foo1 {
    public static <K extends Comparable<K>,V> Map<K,V> func(K[] k, V[] v) {
        Map<K,V> m = new HashMap<K,V>();
        for (int i=0; i<k.length; i++) {
            m.put(k[i], v[i]);
        }
        List<Map.Entry<K,V>> l = new ArrayList<Map.Entry<K,V>>(m.entrySet());
        Collections.sort(l, new Comparator<Map.Entry<K,V>>() {
            public int compare(Map.Entry<K,V> m1, Map.Entry<K,V> m2) {
                return m1.getKey().compareTo(m2.getKey());
            }
        });
        for (Map.Entry<K,V> e: l) {
            System.out.println(m.get(e.getKey()));
        }
        return m;
    } }
