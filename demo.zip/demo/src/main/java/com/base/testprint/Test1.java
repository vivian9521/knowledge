package com.base.testprint;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/9/21
 * @Modified By:
 * @since DK 1.8
 */
public class Test1 {
    public static void main(String[] args) {
        String str1 = "he" + "llo";
        String str2 = "hello";
        String str3 = new String("hello");
        String str4 = new String("hello");
        StringBuilder str5 = new StringBuilder("hello");
        StringBuilder str6 = new StringBuilder("hello");
        System.out.println(str1 == str2); //true
        System.out.println(str3 == str4); //false
        System.out.println(str5 == str6); // false
        System.out.println(str1.equals(str2)); //true
        System.out.println(str3.equals(str4)); //true
        System.out.println(str5.equals(str6)); //false
    }
}
