package com.base.testprint;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/9/21
 * @Modified By:
 * @since DK 1.8
 */
public class HelloA {
    public HelloA() {
        System.out.println("HelloA");
    }
    { System.out.println("I'm A class"); }
    static { System.out.println("static A"); }
}

//存在继承的情况下，初始化顺序为:
//父类(静态变量、静态语句块)
//子类(静态变量、静态语句块)
//父类(实例变量、普通语句块)
//父类(构造函数)
//子类(实例变量、普通语句块)
//子类(构造函数)
class HelloB extends HelloA {
    public HelloB() {
        System.out.println("HelloB");
    }
    { System.out.println("I'm B class"); }
    static { System.out.println("static B"); }
    public static void main(String[] args) {
        new HelloB();
    } }
