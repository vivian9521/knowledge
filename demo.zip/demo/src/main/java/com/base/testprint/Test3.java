package com.base.testprint;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/9/21
 * @Modified By:
 * @since DK 1.8
 */
public class Test3 {
    public static void main(String[] args) {
        int[] a= {1, 2, 3};
        a = Arrays.copyOf(a, a.length+1);
        for(int i: a) {
            System.out.println(a[i]);// 2 3 0 1
        }
    }
}
