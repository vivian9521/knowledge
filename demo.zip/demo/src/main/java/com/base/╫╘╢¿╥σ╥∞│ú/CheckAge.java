package com.base.自定义异常;

import jdk.nashorn.internal.ir.IfNode;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/8
 * @Modified By:
 * @since DK 1.8
 */
public class CheckAge {
    public void check(int age) throws IllAgeException {
        if(age <0 || age>200){
            throw new IllAgeException("年龄不合法！");
        }
    }


    public static void main(String[] args) throws ParseException {
        CheckAge checkAge=new CheckAge();
        try {
            checkAge.check(300);
        } catch (IllAgeException e) {
            e.printStackTrace();
        }
//        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
//        String format1 = format.format(new Date());
//        System.out.println(format1);

//        String date="2022-07-08 11:56:22";
//        SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
//        Date parse = format.parse(date);
//        System.out.println(parse.getTime());
    }
}
