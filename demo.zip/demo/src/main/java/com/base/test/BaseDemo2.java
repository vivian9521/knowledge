package com.base.test;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Objects;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/7
 * @Modified By:
 * @since DK 1.8
 */
public class BaseDemo2 {
    public static void main(String[] args) {

        String b=new String("测试");
        b.intern();

        String a="测试";

        System.out.println(a==b);

        String s1 = "张三";
        String s2 = new String("张三");
        String s3 = new String("张三").intern();
        System.out.println(s3==s1);


//        String s1 = new String("hello") + new String("world");
//        s1.intern();
//        String s2 = "helloworld";
//        System.out.println(s1==s2);


        String str1 = new StringBuilder("计算机").append("软件").toString();
        System.out.println(str1.intern() == str1);

        String str2 = new StringBuilder("ja").append("va").toString();
        System.out.println(str2.intern() == str2);

        //String str3 = new String("1") + new String("2");
        //10,11,12这三个比较特殊
        String str3 = new String("1") + new String("1");
        str3.intern();
        //String str4 = "12";
        String str4 = "11";
        System.out.println(str3 == str4);

        try {
            SimpleDateFormat format=new SimpleDateFormat("yyyy-mm-dd");
            format.parse(null);
        }catch (Exception e){
            System.out.println(e.toString());
        }

        System.out.println(111111);

        StringBuilder builder=new StringBuilder();
        System.out.println(Objects.isNull(builder));

        Integer r=0;
        System.out.println(r.toString());
    }

    public void run1(){
    }
}
