package com.base.test;

import java.io.InputStream;
import java.util.Scanner;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/8
 * @Modified By:
 * @since DK 1.8
 */
public class FinallyDemo {
    public static void main(String[] args) {
        try {
            Scanner scanner=new Scanner(System.in);
            System.out.println("请输入：");
            scanner.nextLine();
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
