package com.base.test;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/1/13
 * @Modified By:
 * @since DK 1.8
 */
public interface EnumInterface {
    int getValue();
}
