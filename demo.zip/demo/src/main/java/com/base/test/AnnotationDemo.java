package com.base.test;

import java.lang.annotation.*;
import java.lang.reflect.AnnotatedElement;
import java.util.stream.Stream;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/7
 * @Modified By:
 * @since DK 1.8
 */
//@Annotation(key = "GFG", value = "GeeksForGeeks")
    @Deprecated
    public class AnnotationDemo {
    public static void main(String[] args) {
        AnnotationDemo demo=new AnnotationDemo();
        Annotation[] annotations = demo.getClass().getAnnotations();
        Stream.of(annotations).forEach(System.out::println);
        AnnotatedElement element=new AnnotatedElement() {
            @Override
            public <T extends Annotation> T getAnnotation(Class<T> annotationClass) {
                return null;
            }

            @Override
            public Annotation[] getAnnotations() {
                return new Annotation[0];
            }

            @Override
            public Annotation[] getDeclaredAnnotations() {
                return new Annotation[0];
            }
        };
    }
}
