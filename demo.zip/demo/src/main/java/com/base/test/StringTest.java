package com.base.test;


import java.lang.ref.PhantomReference;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/9/27
 * @Modified By:
 * @since DK 1.8
 */
public class StringTest {
    public static void main(String[] args) {
//        String a= "adasda#12121";
////        int i = a.indexOf("#");
////        System.out.println(a.substring(0, i));
//        String b = null;
//        System.out.println(Objects.equals(b, null));
//        String[] split = a.split(",");
//        Arrays.stream(split).forEach(System.out::println);
//        LinkedList<Integer> list = new LinkedList<>();
//        list.add(1);
//        list.add(2);
//        list.add(1);
//        System.out.println(list);
//        List<Integer> list1 = new ArrayList<>();
////        list1.add(2, 3);
//        Map<String, String> map = new HashMap<>(5);
//        map.get(1);
//        map.put(null, "1");
//        System.out.println(map.get(null));
//        String[] arr = {null, null};
//        System.out.println(arr[0]);
//        Set<String> set = new HashSet<>();
//        set.add("1");
        // String a = new String("a");
        //        String a1 = new String("a");
        //        System.out.println(a.intern() == a1.intern());
//        LinkedHashMap<String, String> linkedHashMap = new LinkedHashMap<>();
//        linkedHashMap.put("1", "1");
//        String s = linkedHashMap.get("1");
//        linkedHashMap.get()
//        Collections.synchronizedMap(linkedHashMap);
//        TreeMap<String, String> map = new TreeMap<>();
//        map.put("2", "2");
//        map.get(1);
        //软引用
        /*Object obj = new Object();
        SoftReference<Object> sf = new SoftReference<Object>(obj);
        obj = null;
        System.gc();
        //有时候会返回null
        System.out.println(sf.get());*/
        //弱引用
//        Object obj = new Object();
//        ReferenceQueue<Object> queue = new ReferenceQueue<>();
//        WeakReference<Object> sf = new WeakReference<Object>(obj, queue);
//        obj = null;
//        System.gc();
//        //有时候会返回null
//        System.out.println(sf.get());
//        System.out.println(queue.poll());
        //虚引用
        Object obj = new Object();
        ReferenceQueue<Object> queue = new ReferenceQueue<>();
        PhantomReference<Object> pf = new PhantomReference<Object>(obj, queue);
        obj=null;
        System.gc();
        //永远返回null
//        System.out.println(pf.get());
        //返回是否从内存中已经删除
//        System.out.println(pf.isEnQueued());
        System.out.println(queue.poll());
//        Set<Object> objects = Collections.newSetFromMap(new WeakHashMap<>());

        AtomicInteger atomicInteger = new AtomicInteger();
        atomicInteger.addAndGet(2);
        int andIncrement = atomicInteger.getAndIncrement();

        AtomicIntegerFieldUpdater<Integer> newUpdater = AtomicIntegerFieldUpdater.newUpdater(Integer.class, "");
        
    }
}
