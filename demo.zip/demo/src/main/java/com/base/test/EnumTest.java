package com.base.test;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/1/13
 * @Modified By:
 * @since DK 1.8
 */
public enum  EnumTest implements EnumInterface{
    APPLY(0, "申请"),
    DOING(1, "执行中"),
    FINISH(2, "完成"),
    CANCEL(9, "取消");

    EnumTest(Integer value, String name) {
        this.value = value;
        this.name = name;
    }

    private Integer value;
    private String name;

    @Override
    public int getValue() {
        return this.value;
    }

    @Override
    public String toString() {
        return this.name;
    }

    public String getName() {
        return this.name;
    }

    public boolean isEqual(Integer val) {
        if (val == null)
            return false;
        return this.value.equals(val);
    }

    public static EnumTest get(Integer val) {
        if (val == null)
            return null;
        switch (val) {
            case 0:
                return APPLY;
            case 1:
                return DOING;
            case 2:
                return FINISH;
            case 9:
                return CANCEL;
        }
        return null;
    }

}
