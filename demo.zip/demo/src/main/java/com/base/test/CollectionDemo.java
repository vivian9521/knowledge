package com.base.test;

import org.junit.Test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/12
 * @Modified By:
 * @since DK 1.8
 */
public class CollectionDemo {
    @Test
    public void arrList(){
        List<Integer> list=new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(1,2);
        list.add(null);
        list.add(3);
//        list.set(0,4);
//        System.out.println(list);
//        list.remove(0);
//        System.out.println(list);
        //迭代器遍历
        Iterator<Integer> iterator = list.iterator();
        while (iterator.hasNext()){
            Integer next = iterator.next();
            System.out.println(next);
        }
    }

    public static void main(String[] args) {

    }
}
