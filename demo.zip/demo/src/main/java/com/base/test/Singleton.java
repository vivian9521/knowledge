package com.base.test;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/2/16
 * @Modified By:
 * @since DK 1.8
 */
public class Singleton {
    private Singleton() {
    }
    public static Singleton getInstance() {
        // 实际是返回静态内部类中的实例
        return Holder.instance;
    }

    private static class Holder {
        // 在静态内部类中定义instance并实例化
        private static Singleton instance = new Singleton();
    }
}
