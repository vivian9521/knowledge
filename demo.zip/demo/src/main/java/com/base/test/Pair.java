package com.base.test;

import java.util.Date;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/9/26
 * @Modified By:
 * @since DK 1.8
 */
public class Pair<T> {

    private T value;

    public T getValue() {
        return value;
    }

    public void setValue(T value) {
        this.value = value;
    }
}


class DateInter extends Pair<Date> {
    @Override
    public void setValue(Date value) {
    }

    @Override
    public Date getValue() {
        return super.getValue();
    }

    public static void main(String[] args) throws IllegalAccessException, InstantiationException {
        Pair pair = Pair.class.newInstance();
        System.out.println(pair.getValue());
    }
}
