package com.base.test;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Test;

import java.math.BigDecimal;
import java.sql.DriverManager;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ServiceLoader;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.concurrent.RecursiveTask;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.stream.LongStream;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/7
 * @Modified By:
 * @since DK 1.8
 */
public class A {
//        private static A a;
//        public static A getA() {
//            System.out.println(a);
//            if (a == null) {
//                synchronized (A.class) {
//                    if (a == null) {
//                        a = new A();
//                    }
//                }
//            }
//            return a;
//        }

//    private static ScheduledExecutorService executorService = Executors.newScheduledThreadPool(5);
//    public static void main(String[] args) {
//        executorService.scheduleAtFixedRate(A::ping, 0, 1, TimeUnit.SECONDS);
//    }
//    private static void ping() {
//        while (true) {
//            new PingTask().check();
//        }
//    }
//    private static class PingTask {
//    }

//    public static void main(String[] args) {
//        A a = A.getA();
//        System.out.println(a);
//
//    }
public static void main(String[] args) {
//    Executors.defaultThreadFactory();
//    ExecutorService service = Executors.newCachedThreadPool();
//    ForkJoinPool forkJoinPool = ForkJoinPool.commonPool();
//
//    ForkJoinTask task = forkJoinPool.submit(new Runnable() {
//        @Override
//        public void run() {
//
//        }
//    });
//
//    task.fork();
//    ScheduledThreadPoolExecutor executor = new ScheduledThreadPoolExecutor();
//    executor.setCorePoolSize();
//    service.submit()
//    service.execute();
    ServiceLoader loader = ServiceLoader.load(A.class);
//    DriverManager.getConnection()

//    Log log = LogFactory.getLog(A.class);

    System.out.println("12344".substring(0, 2));

    System.out.println(new BigDecimal(1).subtract(new BigDecimal("0.1")));

    long between = ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.now());
    System.out.println(between);
    System.out.println(LocalDate.now().minusDays(2));

    LocalDate d_sch = LocalDate.now();
    LocalDate d_temp = d_sch;
    d_temp = d_temp.minusDays(1);
    System.out.println(d_sch + "----------" + d_temp);
}

    /**
     *并行流 与 顺序流
     */
    @Test
    public void test03() {
        Instant start = Instant.now();
        long reduce1 = LongStream.rangeClosed(0, 10)
                //并行流
                .parallel()
                .reduce(1, Long::sum);
        long reduce = LongStream.rangeClosed(0, 10)
                //顺序流
                .sequential()
                .reduce(0, Long::sum);

        Instant end = Instant.now();
        System.out.println("耗费时间"+ Duration.between( start,end ).toMillis());
        System.out.println(reduce1);
        System.out.println(reduce);
    }
}
