package com.base.test;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/2/1
 * @Modified By:
 * @since DK 1.8
 */
public class MyString {

    private String innerString;

    public int length(){
        return innerString.length();
    }

    //添加新的方法
    public String toMyString(){
        return null;
    }

}
