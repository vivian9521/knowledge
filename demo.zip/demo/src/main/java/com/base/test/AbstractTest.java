package com.base.test;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/5/25
 * @Modified By:
 * @since DK 1.8
 */
public abstract class AbstractTest {
    public abstract void run();

    protected abstract void run1();

    public void run2(){}

}
