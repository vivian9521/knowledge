package com.base.test;

import com.defaulttest.DefaultInterface;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/4/6
 * @Modified By:
 * @since DK 1.8
 */
public class ProtectedTest {

    public class StatTest implements StatInter {

    }

    public interface  StatInter{

    }


    public class StatExtends {

    }

    protected void run(){
        System.out.println("bird is flying......");
    }

    public static void main(String[] args) {
        StatExtends statExtends = new ProtectedTest().new StatExtends();

        DefaultInterface defaultInterface = new DefaultInterface() {
            @Override
            public void method() {
                System.out.println("1111111");
            }

            @Override
            public void method1() {

            }
        };
        defaultInterface.method();

        new AbstractTest(){

            @Override
            public void run() {

            }

            @Override
            protected void run1() {

            }
        };


    }
}
