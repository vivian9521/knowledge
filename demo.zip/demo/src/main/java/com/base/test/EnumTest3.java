package com.base.test;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/1/13
 * @Modified By:
 * @since DK 1.8
 */
public enum EnumTest3{

    APPLY(1, "申请"),
    APPTED(2, "已预约");

    private Integer value;
    private String name;

    EnumTest3(Integer value, String name) {
        this.value = value;
        this.name = name;
    }


}
