package com.base.test;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/6
 * @Modified By:
 * @since DK 1.8
 */
public class BaseExtends extends BaseTest{
    /**
     *
     */
    @Override
    public void run() {
//        super.run();
    }

    public void ann(){

    }



    public static void main(String[] args) {
        BaseExtends clazz=new BaseExtends();
        Class<? extends BaseExtends> aClass = clazz.getClass();
        System.out.println(aClass.getAnnotations());
    }
}
