package com.base.test;

import com.alibaba.excel.EasyExcelFactory;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/9/21
 * @Modified By:
 * @since DK 1.8
 */
public class TestPrint {
    public static void main(String[] args) throws NoSuchAlgorithmException, InvalidKeyException {
        String str1 = "he" + "llo";
        String str2 = "hello";
        String str3 = new String("hello");
        String str4 = new String("hello");
        StringBuilder str5 = new StringBuilder("hello");
        StringBuilder str6 = new StringBuilder("hello");
        System.out.println(str1 == str2);
        System.out.println(str3 == str4);
        System.out.println(str5 == str6);
        System.out.println(str1.equals(str2));
        System.out.println(str3.equals(str4));
        System.out.println(str5.equals(str6));

//        LocalDateTime now = LocalDateTime.now();
//        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");
//        String format = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));
//        System.out.println(format);
//
//        System.out.println(UUID.randomUUID().toString());

//        Mac hmacSha256 = Mac.getInstance("HmacSHA256");
//        SecretKeySpec secret_key = new SecretKeySpec("M/vkPOWXgBa7GnRd73t7j+jsKfbZtb+f".getBytes(), "HmacSHA256");
//        hmacSha256.init(secret_key);
//        byte[] bytes = hmacSha256.doFinal("201609211528139b5bc4eccbb84d814234122ee560f355".getBytes());
//        System.out.println(byteArrayToHexString(bytes));

//        LocalDateTime dt_b = LocalDateTime.now();
//        LocalDateTime dt_e = LocalDateTime.now().plusSeconds(7205);
//        long seconds = Duration.between(dt_b, dt_e).getSeconds();
//        long l = seconds % 3600;
//        System.out.println(l);
//        System.out.println(Math.min(2,2));

//        Boolean a = true;
//        String s = a.toString();
//        System.out.println(s);

//        Date date = new Date();
//        // 将 Date 转换为 Instant
//        Instant instant = date.toInstant();
//        // 将 Instant 转换为 LocalDateTime
//        LocalDateTime localDateTime = LocalDateTime.ofInstant(instant, );
//        System.out.println(localDateTime);

//        Date date = new Date(7000);
////        Instant instant = date.toInstant();
////        ZoneId zoneId = ZoneId.systemDefault();
////        ZonedDateTime zonedDateTime = instant.atZone(zoneId);
////        LocalDate localDate = zonedDateTime.toLocalDate();
////        LocalDateTime of = LocalDateTime.of(localDate, LocalTime.of(0, 0, 0));
////        System.out.println(localDate);
////        System.out.println(of);
        List<String> errList = new ArrayList<>();
        errList.add("wewe");
        errList.add("1");

        String errMsg = String.join(",\n", errList);
        System.out.println(errMsg);
    }

    /**
     * 将加密后的字节数组转换成字符串
     *
     * @param b 字节数组
     * @return 字符串
     */
    private static String byteArrayToHexString(byte[] b) {
        StringBuilder hs = new StringBuilder();
        String stmp;
        for (int n = 0; b!=null && n < b.length; n++) {
            stmp = Integer.toHexString(b[n] & 0XFF);
            if (stmp.length() == 1)
                hs.append('0');
            hs.append(stmp);
        }
        return hs.toString().toLowerCase();
    }
}
