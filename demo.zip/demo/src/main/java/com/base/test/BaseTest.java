package com.base.test;

import com.extendstest.Animal;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/3/2
 * @Modified By:
 * @since DK 1.8
 */
public class BaseTest {
    public String name1;

     public static class  Person{
        private String name;
        private Integer age;

        public Person(String name, Integer age) {
            this.name = name;
            this.age = age;
        }

        public String getName() {
            return name;
        }

        public Integer getAge() {
            return age;
        }

         public void setName(String name) {
             this.name = name;
         }

         public void setAge(Integer age) {
             this.age = age;
         }

         public Object run(){
            System.out.println(name+"isRunning...");
            return "";
        }

    }
    static class Man extends Person{
        public Man(String name, Integer age) {
            super(name, age);
        }

        @Override
        public String run() {
            System.out.println("man is runing...");
            return "";
        }

        public void walk(){
            System.out.println("man is walking...");
        }
    }
    static {
//        int a=5;
//        System.out.println(a);
        System.out.println("-------------------");
    }
    public static void main(String[] args) {
         Person person=new Man("12",88);
//         person.run();
//        Person person=new Person("12",88);
        if (person instanceof Man){
            Man man= (Man) person;
        man.walk();
            man.run();
        }
//         ProtectedTest protectedTest=new ProtectedTest();
//         protectedTest.run();
//         int a=3;
//         int b=3;
//        System.out.println(a^b^a);
//
//        int c=3;
//        int d=c;
//        System.out.println(c^d^c);
//         Man man=new Man("1",2);
//         man.run();
//        List<Integer> a=new ArrayList<>();
//        a.add(1);
//        a.add(2);
//        a.add(2);
//        a.add(4);
//        Iterator<Integer> iterator = a.iterator();
//        while (iterator.hasNext()){
//            if (iterator.next()==2){
//                iterator.remove();
//            }
//        }

//        for (int i = 0; i < a.size(); i++) {
//            if (a.get(i)==2){
//                a.remove(i);
//            }
//        }
//        for (Integer integer : a) {
//            if (integer==2){
//                a.remove(1);
//            }
//        }
//        a.forEach(System.out::println);
//        List list=new ArrayList();
//        Person a=new Person("a",12);
//        Person b=new Person("b",12);
//        list.add(a);
//        list.add(b);
//        System.out.println(list.size());
//        boolean remove = list.remove(a);
//        System.out.println(remove);
//        System.out.println(list.size());
    }
    @Before
    public void run(){
        Integer a=null;
        System.out.println("Junit Test-----------");
    }

    @Test
    public void run2(){
        Integer a=null;
        List<String> list=new ArrayList<>();

        list.add("测试");
        list.add("测试");
        list.add("aaa");
        Iterator<String> iterator = list.iterator();
        while (iterator.hasNext()){
            if (iterator.next()== "测试"){
                System.out.println("1111");
//                iterator.remove();
            }
        }
//        for (String s : list) {
//            if (s=="测试"){
//                list.remove(s);
//            }
//        }
        System.out.println(list);
//        int i = list.indexOf("测试");
//        int lastIndex=list.lastIndexOf("测试");
//        System.out.println(i);
//        System.out.println(lastIndex);
        System.out.println("Junit Test2-----------");
    }


    @After
    public void run3(){
        Integer a=null;
        System.out.println("Junit Test3-----------");
    }
    @Ignore
    public void run4(){
        Integer a=null;
        System.out.println("Junit Test4-----------");
    }

    @AfterClass
    public static void run6(){
        System.out.println("Junit Test6-----------");
    }

    @BeforeClass
    public static void run5(){
        System.out.println("Junit Test5-----------");
    }


    @SuppressWarnings("rawtype")
    public List processList() {
        List list = new ArrayList();
        return list;
    }
}
