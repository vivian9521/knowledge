package com.base.test;

import java.lang.reflect.Constructor;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/2/16
 * @Modified By:
 * @since DK 1.8
 */
public enum  EnumSingleton {

    INST;

    public static void main(String[] args) {
        try {
            Constructor<EnumSingleton> constructor = EnumSingleton.class.getDeclaredConstructor();
            constructor.setAccessible(true);
//            EnumSingleton singleton = constructor.newInstance();
            constructor.newInstance("TEST",1);
        }catch (Exception e){
            System.out.println("枚举不能反射实例化！");
        }
    }
}
