package com.base.test;

//import checkers.nullness.quals.*;

import com.sun.istack.internal.NotNull;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/7
 * @Modified By:
 * @since DK 1.8
 */
public class AnnotationDemo2 {
//    private @NotNull Integer a;

    public void run (){
        @NotNull Integer  a=null;
        System.out.println(a);
    }

    public static void main(String[] args) {
        @NotNull Object ref = null;
//        AnnotationDemo2 demo2=new AnnotationDemo2();
//        demo2.run();
    }
}
