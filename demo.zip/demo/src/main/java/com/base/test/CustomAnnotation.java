package com.base.test;

import com.sun.istack.internal.NotNull;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/7
 * @Modified By:
 * @since DK 1.8
 */
public class CustomAnnotation{
//    @MtMethodAnnotation(title = "12121",description = "3333")
    public void useAnn(){
        @NotNull int a;

    }

    public void run(){

    }

    public static void main(String[] args) throws ClassNotFoundException {

//        try {
        // 获取所有methods
        Method[] methods = CustomAnnotation.class
//                    .getClassLoader()
//                    .loadClass(("com.base.CustomAnnotation"))
                .getMethods();

//            // 遍历
//            for (Method method : methods) {
//                // 方法上是否有MyMethodAnnotation注解
//                if (method.isAnnotationPresent(MtMethodAnnotation.class)) {
//                    try {
//                        // 获取并遍历方法上的所有注解
//                        for (Annotation anno : method.getDeclaredAnnotations()) {
//                            System.out.println("Annotation in Method '"
//                                    + method + "' : " + anno);
//                        }
//
//                        // 获取MyMethodAnnotation对象信息
//                        MtMethodAnnotation methodAnno = method
//                                .getAnnotation(MtMethodAnnotation.class);
//
//                        System.out.println(methodAnno.title());
//
//                    } catch (Throwable ex) {
//                        ex.printStackTrace();
//                    }
//                }
//            }
//        } catch (SecurityException  e) {
//            e.printStackTrace();
//        }
        Arrays.stream(methods).forEach(x -> {
            for (Annotation annotation : x.getDeclaredAnnotations()) {
                System.out.println(annotation);
            }
        });
    }
}
