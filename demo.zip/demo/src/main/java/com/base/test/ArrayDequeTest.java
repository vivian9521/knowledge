package com.base.test;

import java.util.ArrayDeque;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/10/10
 * @Modified By:
 * @since DK 1.8
 */
public class ArrayDequeTest {
    public static void main(String[] args) {
        ArrayDeque<Integer> deque = new ArrayDeque<>();
        deque.add(1);
        deque.add(2);
        deque.add(3);
        deque.addFirst(5);
        Integer last = deque.getLast();
        System.out.println(last);
        System.out.println(deque);
    }
}
