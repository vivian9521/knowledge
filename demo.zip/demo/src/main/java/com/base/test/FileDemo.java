package com.base.test;

import java.io.File;
import java.io.IOException;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/7
 * @Modified By:
 * @since DK 1.8
 */
public class FileDemo {
    public static void main(String[] args) {
        FileDemo fileDemo=new FileDemo();
        fileDemo.file2();
    }

    public void file1(){
        File file=new File("com/base");
        System.out.println(file.getAbsolutePath());
        System.out.println(file.getName());
        System.out.println(file.length());
        File absoluteFile = file.getAbsoluteFile();
        System.out.println(absoluteFile);
        String path = file.getPath();
        System.out.println(path);
    }

    public void file2(){
        File file=new File("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\test\\test\\test.ma");
//        boolean mkdir = file.mkdir();
//        boolean mkdirs = file.mkdirs();
        try {

            boolean newFile = file.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
//        System.out.println(file.delete());
    }

}
