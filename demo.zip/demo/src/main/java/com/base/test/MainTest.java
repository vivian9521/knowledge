package com.base.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/1/31
 * @Modified By:
 * @since DK 1.8
 */
public class MainTest {

    public static void main(String[] args) {
        Arrays.stream(args).forEach(System.out::println);
        System.out.println("-------------------");

        Integer a = new Integer(1000);
        int b = 1000;
        Integer c = new Integer(10);
        Integer d = new Integer(10);
        System.out.println(a == b);
        System.out.println(c == d);


        ApplicationContext context = new ClassPathXmlApplicationContext("","","");
        Object bean = context.getBean("");
        new AnnotationConfigApplicationContext();
    }
}
