package com.base.test;

import java.util.AbstractList;
import java.util.List;
import java.util.RandomAccess;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/9/29
 * @Modified By:
 * @since DK 1.8
 */
public class MyList<E> extends AbstractList<E>
        implements List<E>, RandomAccess, Cloneable, java.io.Serializable{

    @Override
    public int size() {
        return 0;
    }

    /**
     * {@inheritDoc}
     *
     * @param index
     * @throws IndexOutOfBoundsException {@inheritDoc}
     */
    @Override
    public E get(int index) {
        return null;
    }
}
