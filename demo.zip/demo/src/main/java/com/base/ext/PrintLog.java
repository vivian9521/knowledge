package com.base.ext;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;

/**
 * @Auther:vivian
 * @Description:输出日志到文件
 * @Date:Created in 2022/7/13
 * @Modified By:
 * @since DK 1.8
 */
public class PrintLog {
    public static void main(String[] args) throws Exception {
        PrintStream pr=new PrintStream(new FileOutputStream("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\log.txt",true));
        System.setOut(pr);
        System.out.println("机票空瓶磨破了每平米你就皮厚");
        System.out.println("qeewrweqreqre");
        System.out.println(1231243523);
    }
}
