package com.base.utils;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/12/7
 * @Modified By:
 * @since DK 1.8
 */
public class Test {
    public static void main(String[] args) {
//        Integer weight = 2350;
//
//        double i = weight / 1000.0;
//        System.out.println(i);

        String a = "123455";
        String[] arr = a.split(",");

        Arrays.stream(arr).forEach(System.out::println);
//        System.out.println(a.substring(0, 8));
    }
}
