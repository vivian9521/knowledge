package com.base.utils;

import io.netty.util.HashedWheelTimer;
import org.springframework.scheduling.annotation.Scheduled;
import sun.misc.Cleaner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/12/7
 * @Modified By:
 * @since DK 1.8
 */
public class GenerateBuilder {
    private static final String STR = "builder";

    private static final String SPLITSTR = "\n";

    public static List<String> generate (String str){
        String[] split = str.split(SPLITSTR);

        return Arrays.stream(split).map(s->{
            return STR + ".append(\" " + s +  " \");";
        }).collect(Collectors.toList());
    }

    public static void main(String[] args) {
        String str = "\tSELECT\n" +
                "\tsug.*\n" +
                "\tfrom\n" +
                "\tcis_cmd_i cmd\n" +
                "\tinner join CIS_AP_SUG_I sug on sug.pk_cmd = cmd.pk_cmd\n" +
                "\tinner JOIN pv_ip ip on ip.pk_pvt = cmd.pk_pvt\n" +
                "\tLEFT JOIN ss_dept dept on dept.pk_dept = ip.pk_dept_nur\n" +
                "\twhere\n" +
                "\tcmd.is_chk=1 and cmd.is_canc=0 and cmd.cd_itmtp='0401'";
        List<String> generate = generate(str);
        generate.stream().forEach(System.out::println);
    }

}
