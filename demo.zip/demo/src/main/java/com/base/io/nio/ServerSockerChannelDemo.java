package com.base.io.nio;

import java.io.IOException;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/2/8
 * @Modified By:
 * @since DK 1.8
 */
public class ServerSockerChannelDemo {
    public static void main(String[] args) throws IOException {
        Selector selector = Selector.open();

        ServerSocketChannel socketChannel = ServerSocketChannel.open();
        socketChannel.configureBlocking(false);
        SelectionKey register = socketChannel.register(selector, SelectionKey.OP_ACCEPT);

    }
}
