package com.base.ip.tcp.scoket1;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @Auther:vivian
 * @Description:Socket服务端  一对一
 * @Date:Created in 2022/7/15
 * @Modified By:
 * @since DK 1.8
 */
public class ServerSocketDemo {
    public static void main(String[] args) throws Exception{
        System.out.println("服务端启动");
        //注册端口
        ServerSocket serverSocket=new ServerSocket(7777);
        //接收socket管道连接
        Socket socket = serverSocket.accept();
        //管道中得到字节输入流
        InputStream is = socket.getInputStream();
        //转换成字符流
        InputStreamReader isr = new InputStreamReader(is);
        //包装成缓冲输入流
        BufferedReader reader = new BufferedReader(isr);
        //读取数据
        String msg;
        while ((msg=reader.readLine())!=null){
            System.out.println(msg);
        }

    }
}
