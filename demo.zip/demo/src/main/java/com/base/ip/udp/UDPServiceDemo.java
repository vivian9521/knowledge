package com.base.ip.udp;


import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Socket;
import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:UDP服务端
 * @Date:Created in 2022/7/14
 * @Modified By:
 * @since DK 1.8
 */
public class UDPServiceDemo {
    public static void main(String[] args) throws Exception{
        System.out.println("启动服务端");
        //创建接收数据包
        byte[] bytes=new byte[1024*64];
        DatagramPacket packet=new DatagramPacket(bytes,bytes.length);
        //创建接收码头
        DatagramSocket socket=new DatagramSocket(3333);
        //接收数据
        socket.receive(packet);

        String data = new String(bytes,0,packet.getLength());
        System.out.println(data);
        System.out.println(packet.getAddress().getHostAddress()+":"+packet.getPort());

    }
}
