package com.base.ip;

import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/14
 * @Modified By:
 * @since DK 1.8
 */
public class InetAddressDemo {
    public static void main(String[] args) throws IOException {
        InetAddress localHost = InetAddress.getLocalHost();
        System.out.println(localHost.getHostName());
        System.out.println(Arrays.toString(localHost.getAddress()));
        System.out.println(localHost.getHostAddress());
        System.out.println(localHost.getCanonicalHostName());
        System.out.println("---------------------");


        InetAddress byName = InetAddress.getByName("www.baidu.com");
        System.out.println("--"+byName.getHostName());
        System.out.println("++"+Arrays.toString(byName.getAddress()));
        System.out.println("((("+byName.getHostAddress());
        System.out.println(")))"+byName.getCanonicalHostName());

//        System.out.println(byName.isReachable(3000));

        InetAddress byAddress = InetAddress.getByAddress(new byte[]{-74, 61, -56, 6});
        System.out.println(byAddress.getHostName());
    }
}
