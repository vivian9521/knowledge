package com.base.ip.udp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * @Auther:vivian
 * @Description:UDP客户端
 * @Date:Created in 2022/7/14
 * @Modified By:
 * @since DK 1.8
 */
public class UDPClientDemo {
    public static void main(String[] args) throws Exception {
        System.out.println("启动客户端");
        byte[] bytes = "你好世界！".getBytes();
        //数据包
        //要发送的地址和端口
        DatagramPacket packet=new DatagramPacket(bytes,bytes.length, InetAddress.getLocalHost(),3333);
        //装入码头
        DatagramSocket socket=new DatagramSocket();
        //发送数据
        socket.send(packet);
    }
}
