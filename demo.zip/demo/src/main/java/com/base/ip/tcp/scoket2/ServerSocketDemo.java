package com.base.ip.tcp.scoket2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @Auther:vivian
 * @Description:Socket服务端  多对一
 * 多线程实现
 * @Date:Created in 2022/7/15
 * @Modified By:
 * @since DK 1.8
 */
public class ServerSocketDemo {
    public static void main(String[] args) throws Exception{
        System.out.println("服务端启动");
        //注册端口
        ServerSocket serverSocket=new ServerSocket(6666);
        while (true){
            //接收socket管道连接
            Socket socket = serverSocket.accept();
            //每接收一个客户端，必须为管道分配一个独立的线程与之通信
            new SocketThread(socket).start();
        }


    }
}
class SocketThread extends Thread{

    private Socket socket;

    public SocketThread(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try {
            //管道中得到字节输入流
            InputStream is = socket.getInputStream();
            //转换成字符流
            InputStreamReader isr = new InputStreamReader(is);
            //包装成缓冲输入流
            BufferedReader reader = new BufferedReader(isr);
            //读取数据
            String msg;
            while ((msg=reader.readLine())!=null){
                System.out.println("用户"+currentThread().getName()+"接收:"+msg);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
