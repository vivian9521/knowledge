package com.base.ip.tcp.scoket2;

import java.io.OutputStream;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Scanner;

/**
 * @Auther:vivian
 * @Description:Socket客户端
 * @Date:Created in 2022/7/15
 * @Modified By:
 * @since DK 1.8
 */
public class ClientSocketDemo {
    public static void main(String[] args) throws Exception {
        System.out.println("客户端启动");
        //管道连接
        Socket socket=new Socket(InetAddress.getLocalHost(),6666);
        //从管道中得到一个输出流
        OutputStream os = socket.getOutputStream();
        //包装成高级打印流
        PrintStream ps=new PrintStream(os);
        //发消息出去
        Scanner scanner=new Scanner(System.in);
        while (true){
            System.out.println("请说：");
            ps.println(scanner.nextLine());
            ps.flush();
        }
    }
}
