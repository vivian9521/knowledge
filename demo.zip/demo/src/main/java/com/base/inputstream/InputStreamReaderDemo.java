package com.base.inputstream;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;

/**
 * @Auther:vivian
 * @Description:字节流转字符流，定义编码方式
 * @Date:Created in 2022/7/12
 * @Modified By:
 * @since DK 1.8
 */
public class InputStreamReaderDemo {
    public static void main(String[] args) {
        try(InputStream is=new FileInputStream("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\demo06.txt");
            InputStreamReader its=new InputStreamReader(is,"utf-8");
            BufferedReader reader=new BufferedReader(its);
        ) {
            String line;
            while ((line=reader.readLine())!=null){
                System.out.println(line);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
