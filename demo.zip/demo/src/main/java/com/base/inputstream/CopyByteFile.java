package com.base.inputstream;


import javax.swing.*;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Scanner;

/**
 * @Auther:vivian
 * @Description:字节输入输出流复制文件
 * @Date:Created in 2022/7/11
 * @Modified By:
 * @since DK 1.8
 */
public class CopyByteFile {
    public static void main(String[] args) {
        //源文件
        String srcFile="E:\\DEMO\\demo\\src\\main\\java\\com\\base\\demo02.txt";
        //目标文件
        String targetFile="E:\\DEMO\\demo\\src\\main\\java\\com\\base\\demo03.txt";
        try(InputStream is=new FileInputStream(srcFile);
                OutputStream os=new FileOutputStream(targetFile)) {
//            boolean b = is.markSupported();
//            is.mark();
//            is.reset();
            //字符输入流
            byte[] ch=new byte[3];
            int len;
            while ((len=is.read(ch))!=-1){
                os.write(ch,0,len);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
