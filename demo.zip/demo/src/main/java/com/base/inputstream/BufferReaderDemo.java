package com.base.inputstream;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/12
 * @Modified By:
 * @since DK 1.8
 */
public class BufferReaderDemo {
    public static void main(String[] args) {
        try(BufferedReader reader=new BufferedReader(new FileReader("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\demo05.txt"));
                BufferedWriter writer=new BufferedWriter(new FileWriter("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\demo06.txt"));
                ) {
            String line;
            while ((line=reader.readLine())!=null){
                writer.write(line);
                writer.newLine();
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
