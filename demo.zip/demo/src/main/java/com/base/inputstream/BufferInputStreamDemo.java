package com.base.inputstream;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/12
 * @Modified By:
 * @since DK 1.8
 */
public class BufferInputStreamDemo {
    public static void main(String[] args) {
        try(BufferedInputStream is=new BufferedInputStream(new FileInputStream("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\demo03.txt"));
            BufferedOutputStream os=new BufferedOutputStream(new FileOutputStream("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\demo05.txt"))
        ) {
            byte[] ch=new byte[1024];
            int len;
            while ((len=is.read(ch))!=-1){
                os.write(ch,0,len);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
