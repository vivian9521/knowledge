package com.base.inputstream;



import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.nio.channels.FileChannel;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/11
 * @Modified By:
 * @since DK 1.8
 */
public class FileInputStreamDemo {

    public static void main(String[] args) {
        //字节输入流
        try(FileInputStream is=new FileInputStream("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\demo01")){
            //一个一个字节读
            int ch;
            while ((ch=is.read())!=-1){
                System.out.print((char) ch);
            }
            //字节数组读
//            byte[] ch=new byte[3];
//            int len;
//            while ((len=is.read(ch))!=-1){
//                String str = new String(ch, 0, len);
//                System.out.print(str);
//            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
