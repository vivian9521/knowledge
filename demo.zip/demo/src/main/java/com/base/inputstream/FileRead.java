package com.base.inputstream;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/2/17
 * @Modified By:
 * @since DK 1.8
 */
public class FileRead {
    public static void main(String[] args) throws IOException {
        File file = new File("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\io\\dest.txt");
        RandomAccessFile raf = new RandomAccessFile(file, "rw");

        byte[] arr = new byte[(int) file.length()];
        raf.read(arr);

//        String s = new String(arr);
//        System.out.println(s);

        Socket socket = new ServerSocket(3333).accept();
        socket.getOutputStream().write(arr);
    }
}
