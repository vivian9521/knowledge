package com.base.inputstream;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/11
 * @Modified By:
 * @since DK 1.8
 */
public class ReaderDemo {
    public static void main(String[] args) {

        try(FileReader is = new FileReader("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\demo02.txt")){
            //一个一个字符读
//            int ch;
//            while ((ch=is.read())!=-1){
//                System.out.print((char)ch);
//            }
            //字符数组读
            char[] chars=new char[3];
            int len;
            while ((len=is.read(chars))!=-1){
                System.out.print(new String(chars,0,len));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
