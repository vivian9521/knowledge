package com.base.aqs;

import sun.misc.ConditionLock;

import java.math.BigDecimal;
import java.util.concurrent.locks.AbstractQueuedSynchronizer;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.LockSupport;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/2/27
 * @Modified By:
 * @since DK 1.8
 */
public class Test1 {
    public static void main(String[] args) throws InterruptedException {
        double pow = Math.pow(2, 16);
        System.out.println(pow);
        BigDecimal decimal = BigDecimal.valueOf(pow).subtract(new BigDecimal(1));
        System.out.println(decimal.intValue());
        int i = decimal.intValue() & 6;
        System.out.println(i);
    }
}
