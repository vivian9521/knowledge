package com.base.designpattern.nullmodel.model2;

import java.util.Optional;

/**
 * @Auther:vivian
 * @Description:用户类
 * @Date:Created in 2023/2/6
 * @Modified By:
 * @since DK 1.8
 */
public class User {
    public User(Address address) {
        this.address = address;
    }
    private Address address;
    public Optional<Address> getAddress() {
        return Optional.ofNullable(address);
    }
    public void setAddress(Address address) {
        this.address = address;
    }
}
