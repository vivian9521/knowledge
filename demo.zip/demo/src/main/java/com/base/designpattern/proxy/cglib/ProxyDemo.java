package com.base.designpattern.proxy.cglib;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/8/10
 * @Modified By:
 * @since DK 1.8
 */
public class ProxyDemo {
    public static void main(String[] args) {
        UserServiceImpl proxy = (UserServiceImpl) CglibProxy.getProxy(UserServiceImpl.class);
        proxy.addUser();
        proxy.findUserList();

    }
}
