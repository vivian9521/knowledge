package com.base.designpattern.nullmodel.model1;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/2/6
 * @Modified By:
 * @since DK 1.8
 */
public abstract class AbstractObject {
    String name;
    abstract String getName();
    abstract boolean isNull();
}
