package com.base.designpattern.tmpl;

/**
 * @Auther:vivian
 * @Description:模板模式
 * @Date:Created in 2023/2/27
 * @Modified By:
 * @since DK 1.8
 */
public abstract class CaffeineBeverage {
    final void prepareRecipe() {
        boilWater();
        brew();
        pourInCup();
        addCondiments();
    }

    abstract void brew();

    abstract void addCondiments();

    void boilWater() {
        System.out.println("boilWater");
    }

    void pourInCup() {
        System.out.println("pourInCup");
    }
}
