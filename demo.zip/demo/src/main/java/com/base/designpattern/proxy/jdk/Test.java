package com.base.designpattern.proxy.jdk;

import org.springframework.cglib.proxy.InvocationHandler;
import org.springframework.cglib.proxy.Proxy;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/3/28
 * @Modified By:DispatcherServlet
 * @since DK 1.8
 */
public class Test {
    public static void main(String[] args) {
        InvocationHandler renterHandler = new HobbyDynamicProxy(new MyHobby());
        Hobby hobbyProxy = (Hobby) Proxy.newProxyInstance(Hobby.class.getClassLoader(), new Class[]{Hobby.class},renterHandler);
        hobbyProxy.sing();
        hobbyProxy.dance();
    }
}
