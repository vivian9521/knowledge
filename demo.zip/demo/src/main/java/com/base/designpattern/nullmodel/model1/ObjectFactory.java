package com.base.designpattern.nullmodel.model1;

/**
 * @Auther:vivian
 * @Description:对象工厂
 * @Date:Created in 2023/2/6
 * @Modified By:
 * @since DK 1.8
 */
public class ObjectFactory {
    public static void main(String[] args) {
        AbstractObject creator = ObjectFactory.creator("A");
        System.out.println(creator.getName());
    }
    public static AbstractObject creator(final String name) {
        AbstractObject result = null;
        switch (name) {
            case "Java":
                result = new ConcreteObject("Java");
                break;
            case "SQL":
                result = new ConcreteObject("SQL");
                break;
            default:
                result = new NullObject();
                break;
        }
        return result;
    }
}
