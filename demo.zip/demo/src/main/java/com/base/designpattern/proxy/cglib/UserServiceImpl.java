package com.base.designpattern.proxy.cglib;

import java.util.Collections;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/8/10
 * @Modified By:
 * @since DK 1.8
 */
public class UserServiceImpl {
    /**
     * find user list.
     *
     * @return user list
     */
    public List<String> findUserList() {
        return Collections.singletonList("ces");
    }

    /**
     * add user
     */
    public void addUser() {
        // do something
    }
}
