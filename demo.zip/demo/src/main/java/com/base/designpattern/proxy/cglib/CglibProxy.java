package com.base.designpattern.proxy.cglib;

import org.springframework.cglib.proxy.Enhancer;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/3/28
 * @Modified By:
 * @since DK 1.8
 */
public class CglibProxy {
    public static Object getProxy(Class<?> clazz){
        Enhancer enhancer = new Enhancer();
        // 设置类加载
        enhancer.setClassLoader(clazz.getClassLoader());
        // 设置被代理类
        enhancer.setSuperclass(clazz);
        // 设置方法拦截器
        enhancer.setCallback(new TargetInterceptor());
        //回调过滤器
//        enhancer.setCallbackFilter();
        // 创建代理类
        return enhancer.create();
    }

}
