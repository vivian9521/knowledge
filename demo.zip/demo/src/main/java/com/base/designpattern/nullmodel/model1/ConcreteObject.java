package com.base.designpattern.nullmodel.model1;

/**
 * @Auther:vivian
 * @Description:具体对象
 * @Date:Created in 2023/2/6
 * @Modified By:
 * @since DK 1.8
 */
public class ConcreteObject extends AbstractObject{
    public ConcreteObject(final String name) {
        this.name = name;
    }
    @Override
    String getName() {
        return this.name;
    }
    @Override
    boolean isNull() {
        return false;
    }
}
