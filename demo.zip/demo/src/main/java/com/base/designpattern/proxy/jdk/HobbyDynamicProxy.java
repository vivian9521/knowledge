package com.base.designpattern.proxy.jdk;

import org.springframework.cglib.proxy.InvocationHandler;

import java.lang.reflect.Method;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/3/28
 * @Modified By:
 * @since DK 1.8
 */
public class HobbyDynamicProxy implements InvocationHandler {
    private final Object obj;

    public HobbyDynamicProxy(Object obj){
        this.obj = obj;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        rap();
        Object result = method.invoke(obj, args);
        rap();
        return result;
    }

    public void rap() {
        System.out.println("Dynamic-rap...");
    }
}
