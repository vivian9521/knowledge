package com.base.designpattern.proxy.cglib;

import org.springframework.cglib.proxy.MethodInterceptor;
import org.springframework.cglib.proxy.MethodProxy;

import java.lang.reflect.Method;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/3/28
 * @Modified By:
 * @since DK 1.8
 */
public class TargetInterceptor implements MethodInterceptor {
    @Override
    public Object intercept(Object o, Method method, Object[] objects, MethodProxy methodProxy) throws Throwable {
        System.out.println("CGLIB 调用前");
        Object result = methodProxy.invokeSuper(o, objects);
        System.out.println("CGLIB 调用后");
        return result;
    }
}
