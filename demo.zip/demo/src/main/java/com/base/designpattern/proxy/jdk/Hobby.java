package com.base.designpattern.proxy.jdk;

/**
 * @Auther:vivian
 * @Description:目标接口
 * @Date:Created in 2023/3/28
 * @Modified By:
 * @since DK 1.8
 */
public interface Hobby {
    void sing();

    void dance();
}
