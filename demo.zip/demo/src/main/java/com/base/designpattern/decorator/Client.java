package com.base.designpattern.decorator;

import org.springframework.context.annotation.DependsOn;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/2/3
 * @Modified By:
 * @since DK 1.8
 */
public class Client {
    public static void main(String[] args) {
        Beverage beverage = new HouseBlend();
        beverage = new Mocha(beverage);
        beverage = new Milk(beverage);
        System.out.println(beverage.cost());
    }
}
