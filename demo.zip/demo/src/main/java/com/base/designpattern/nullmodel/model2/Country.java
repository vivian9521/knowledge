package com.base.designpattern.nullmodel.model2;

/**
 * @Auther:vivian
 * @Description:国际编码类
 * @Date:Created in 2023/2/6
 * @Modified By:
 * @since DK 1.8
 */
public class Country {
    public Country(String isoCode) {
        this.isoCode = isoCode;
    }
    private String isoCode;
    public String getIsocode() {
        return isoCode;
    }
    public void setIsocode(String isoCode) {
        this.isoCode = isoCode;
    }
}
