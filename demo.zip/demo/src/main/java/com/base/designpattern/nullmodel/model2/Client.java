package com.base.designpattern.nullmodel.model2;

import java.util.Optional;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/2/6
 * @Modified By:
 * @since DK 1.8
 */
public class Client {
    public static void main(String[] args) {
        // JDK 8 Optional 对象判空示例
        // 具体对象
        User concreteUser = new User(new Address(new Country("china")));
        // 空对象
        User nullUser = new User(null);
        // 具体对象编码获取
        String concreteIsocode = Optional.ofNullable(concreteUser)
                .flatMap(u -> u.getAddress())
                .flatMap(a -> a.getCountry())
                .map(c -> c.getIsocode())
                .orElse("暂无").toUpperCase();
        // 空对象编码获取
        String nullIsocode = Optional.ofNullable(nullUser)
                .flatMap(u -> u.getAddress())
                .flatMap(a -> a.getCountry())
                .map(c -> c.getIsocode())
                .orElse("暂无").toUpperCase();
        System.out.println("Concrete User：" + concreteIsocode);
        System.out.println("Null User：" + nullIsocode);
    }
}
