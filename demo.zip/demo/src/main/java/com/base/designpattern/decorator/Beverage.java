package com.base.designpattern.decorator;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/2/3
 * @Modified By:
 * @since DK 1.8
 */
public interface Beverage {
    double cost();
}
