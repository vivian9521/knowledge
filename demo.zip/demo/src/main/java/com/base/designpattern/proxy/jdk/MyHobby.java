package com.base.designpattern.proxy.jdk;

/**
 * @Auther:vivian
 * @Description:目标类
 * @Date:Created in 2023/3/28
 * @Modified By:
 * @since DK 1.8
 */
public class MyHobby implements Hobby{

    @Override
    public void sing() {
        System.out.println("sing...");
    }

    @Override
    public void dance() {
        System.out.println("dance...");
    }
}
