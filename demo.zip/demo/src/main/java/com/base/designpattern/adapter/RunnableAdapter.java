package com.base.designpattern.adapter;

import java.util.concurrent.Callable;

/**
 * @Auther:vivian
 * @Description:适配器模式
 * @Date:Created in 2023/3/14
 * @Modified By:
 * @since DK 1.8
 */
public final class RunnableAdapter<T> implements Callable<T> {
    final Runnable task;
    final T result;

    RunnableAdapter(Runnable task, T result) {
        this.task = task;
        this.result = result;
    }
    public T call() {
        task.run();
        return result;
    }
}
