package com.base.designpattern.decorator;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/2/3
 * @Modified By:
 * @since DK 1.8
 */
public class DarkRoast  implements Beverage {
    @Override
    public double cost() {
        return 1;
    }
}
