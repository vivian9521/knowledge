package com.base.designpattern.nullmodel.model1;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/2/6
 * @Modified By:
 * @since DK 1.8
 */
public class NullObject extends AbstractObject{
    @Override
    String getName() {
        return "Not Available in Customer Database";
    }
    @Override
    boolean isNull() {
        return true;
    }
}
