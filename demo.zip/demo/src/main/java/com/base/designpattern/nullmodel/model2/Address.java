package com.base.designpattern.nullmodel.model2;

import java.util.Optional;

/**
 * @Auther:vivian
 * @Description:地址类
 * @Date:Created in 2023/2/6
 * @Modified By:
 * @since DK 1.8
 */
public class Address {
    public Address(Country country) {
        this.country = country;
    }
    private Country country;
    public Optional<Country> getCountry() {
        return Optional.ofNullable(country);
    }
    public void setCountry(Country country) {
        this.country = country;
    }
}
