package com.base.finalexample;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/2/1
 * @Modified By:
 * @since DK 1.8
 */
public class FinalMethod {
    private final int a;

    public FinalMethod() {
        a=1;
    }

    private final void run(){
    }
    private final void run(String name){

    }

    public static void main(String[] args) {
        FinalMethod method = new FinalMethod();
        int a = method.a;

    }
}
