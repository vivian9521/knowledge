package com.base.finalexample;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/2/1
 * @Modified By:
 * @since DK 1.8
 */
public class MyString {

    private String innerString;

//    private final Integer a;
//
//    public MyString(String innerString, Integer a) {
//        this.innerString = innerString;
//        this.a = a;
//    }


    public int length(){
        return innerString.length();
    }

    //添加新的方法
    public String toMyString(){
        return null;
    }

}
