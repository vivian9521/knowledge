package com.base.properties;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/13
 * @Modified By:
 * @since DK 1.8
 */
public class PropertiesDemo {
    public static void main(String[] args){
        //写入properties文件
//        Properties properties=new Properties();
//        properties.setProperty("name","1111");
//        try {
//            properties.store(new FileWriter("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\test.properties"),"测试注释11111");
//            System.out.println(properties);
//
//        } catch (IOException e) {
//            e.printStackTrace();
//        }

        //读取properties文件
        Properties properties=new Properties();
        System.out.println(properties);
        try{
            properties.load(new FileReader("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\test.properties"));
            System.out.println(properties);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
