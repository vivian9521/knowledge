package com.base.serializle;

import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/13
 * @Modified By:
 * @since DK 1.8
 */
public class SerializeDemo1 {
    public static void main(String[] args) {
//        try(ObjectOutputStream os=new ObjectOutputStream(new FileOutputStream("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\demo09.txt"));
//        ){
//            User user=new User("测试","111","名字");
//            os.writeObject(user);
//            System.out.println("序列化成功");
//        }catch (Exception e){
//            e.printStackTrace();
//        }

        try(ObjectInputStream is=new ObjectInputStream(new FileInputStream("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\demo09.txt"));){
            Object user;
            if ((user=is.readObject()) instanceof User){
                System.out.println((User)user);
            }
            System.out.println("反序列化成功");

        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
