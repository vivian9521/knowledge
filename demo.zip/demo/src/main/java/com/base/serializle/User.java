package com.base.serializle;

import java.io.Serializable;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/13
 * @Modified By:
 * @since DK 1.8
 */
public class User implements Serializable {
    //序列化版本号
    private static final long serialVersionUID = -5362273979926353683L;
    private String loginName;
    //修饰的成员变量不参与序列化
    private transient String password;
    private String name;

    public User(String loginName, String password, String name) {
        this.loginName = loginName;
        this.password = password;
        this.name = name;
    }

    public String getLoginName() {
        return loginName;
    }

    public void setLoginName(String loginName) {
        this.loginName = loginName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "User{" +
                "loginName='" + loginName + '\'' +
                ", password='" + password + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
