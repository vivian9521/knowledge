package com.base.jvm;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/25
 * @Modified By:
 * @since DK 1.8
 */
//stringTable垃圾回收
//-Xmx10m -XX:+PrintStringTableStatistics -XX:+PrintGCDetails -verbose:gc
public class StringTableDemo1 {
    public static void main(String[] args) {
        int i=0;
        try {
          for (int j=0;j<10000;j++){
              String.valueOf(j).intern();
              i++;
          }
        }catch (Exception e){
            e.printStackTrace();
        }
        System.out.println(i);
    }
}
