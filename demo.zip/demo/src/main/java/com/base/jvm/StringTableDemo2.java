package com.base.jvm;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/25
 * @Modified By:
 * @since DK 1.8
 */
//演示stringtable位置
//-Xmx10m -XX:-UseGCOverheadLimit
public class StringTableDemo2 {
    public static void main(String[] args) {
        List<String> list=new ArrayList<>();
        int i=0;
        try {
            for(int j=0;j<260000;j++){
                list.add(String.valueOf(i).intern());
                i++;
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            System.out.println(i);
        }
    }
}
