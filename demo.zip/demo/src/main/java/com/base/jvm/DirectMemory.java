package com.base.jvm;

import sun.misc.Unsafe;

import java.io.IOException;
import java.lang.reflect.Field;
import java.nio.ByteBuffer;

/**
 * @Auther:vivian
 * @Description:直接内存垃圾回收
 * @Date:Created in 2022/7/26
 * @Modified By:
 * @since DK 1.8
 */
public class DirectMemory {
    static int _1Gb=1024*1024*1024;
    //-XX:+DisableExplicitGC 显式的垃圾回收 设置后不再进行垃圾回收
    public static void main(String[] args) throws Exception {
        ByteBuffer buffer=ByteBuffer.allocateDirect(_1Gb);
        System.out.println("分配完毕...");
        System.in.read();
        System.out.println("开始释放...");
        buffer=null;
        System.gc();
        System.in.read();

        Unsafe unsafe = getUnsafe();
        long base = unsafe.allocateMemory(_1Gb);
        //设置内存
        unsafe.setMemory(base,_1Gb, (byte) 0);
        System.in.read();
        //释放内存
        unsafe.freeMemory(base);
        System.in.read();
    }

    public static Unsafe getUnsafe() throws Exception {
        Field f = Unsafe.class.getDeclaredField("theUnsafe");
        f.setAccessible(true);
        Unsafe unsafe=(Unsafe) f.get(null);
        return unsafe;
    }
}
