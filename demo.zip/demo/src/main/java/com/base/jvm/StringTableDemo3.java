package com.base.jvm;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;

/**
 * @Auther:vivian
 * @Description:设置串池桶大小
 * @Date:Created in 2022/7/25
 * @Modified By:
 * @since DK 1.8
 */
//-XX:StringTableSize=200000 -XX:+PrintStringTableStatistics
public class StringTableDemo3 {
    public static void main(String[] args) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\demo02.txt"),"utf-8"))) {
            String line = null;
            long start = System . nanoTime();
            while (true) {
                line =reader.readLine();
                if (line == null) {
                    break;
                }
                line.intern();
            }
            System.out.println("cost:" + (System. nanoTime() - start) / 1000000);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
