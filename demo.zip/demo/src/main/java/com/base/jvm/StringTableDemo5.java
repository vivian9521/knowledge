package com.base.jvm;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:stringtable优化
 * @Date:Created in 2022/7/25
 * @Modified By:
 * @since DK 1.8
 */
//演示使用inter和不使用inter所占内存大小，jvisualvm查看
//-XX:StringTableSize=200000 -XX:+PrintStringTableStatistics
public class StringTableDemo5 {
    public static void main(String[] args) throws IOException {
        List<String> list=new ArrayList<>();
        System.in.read();
        for (int i=0;i<100000;i++){
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream("E:\\DEMO\\demo\\src\\main\\java\\com\\base\\demo02.txt"),"utf-8"))) {
                String line = null;
                long start = System . nanoTime();
                while (true) {
                    line =reader.readLine();
                    if (line == null) {
                        break;
                    }
                    list.add(line.intern());
                }
                System.out.println("cost:" + (System. nanoTime() - start) / 1000000);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
        System.in.read();
    }
}
