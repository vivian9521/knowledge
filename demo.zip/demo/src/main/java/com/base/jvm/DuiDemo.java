package com.base.jvm;


import java.util.ArrayList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/25
 * @Modified By:
 * @since DK 1.8
 */
public class DuiDemo {
    public static void main(String[] args) throws InterruptedException {
        List<Student1> students = new ArrayList<>();
        for (int i = 0; i < 200; i++) {
            students.add(new Student1());
        }
        Thread.sleep(1000000000L);
    }
}
class Student1 {
    private byte[] big = new byte[1024 * 1024];

}


