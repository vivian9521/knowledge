package com.base.thread;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/11/1
 * @Modified By:
 * @since DK 1.8
 */
public class MyRunnable implements Runnable{
    /**
     * When an object implementing interface <code>Runnable</code> is used
     * to create a thread, starting the thread causes the object's
     * <code>run</code> method to be called in that separately executing
     * thread.
     * <p>
     * The general contract of the method <code>run</code> is that it may
     * take any action whatsoever.
     *
     * @see Thread#run()
     */
    @Override
    public void run() {
        int n = 0;
//        synchronized (this){
//            for (int i = 0 ; i< 5; i++){
//                n++;
//                System.out.println("当前线程：" + Thread.currentThread()+"---"+i);
//            }
//        }
        for (int i = 0 ; i< 10; i++){
            n++;
            System.out.println("当前线程：" + Thread.currentThread()+"---"+i);
        }
        System.out.println(n);
    }
}
