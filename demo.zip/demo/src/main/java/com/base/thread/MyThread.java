package com.base.thread;


/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/11/1
 * @Modified By:
 * @since DK 1.8
 */
public class MyThread extends Thread{
    @Override
    public void run() {
        while (!interrupted()){
            System.out.println("Thread run");
        }
        System.out.println("Thread End");
//        try {
//            Thread.sleep(2000);
//            System.out.println("Thread run");
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
    }

    public static void main(String[] args) {
        while (true){
            Thread thread1 = new MyThread();
            thread1.start();
            thread1.interrupt();
            boolean interrupted = thread1.isInterrupted();
        }

    }
}
