package com.base.thread;

import java.util.concurrent.Callable;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/14
 * @Modified By:
 * @since DK 1.8
 */
public class ThreadDemo extends Thread{
    public static void main(String[] args) {
        ThreadDemo t1=new ThreadDemo();
        t1.start();
        ThreadDemo t2=new ThreadDemo();
        t2.start();
        ThreadDemo t3=new ThreadDemo();
        t3.start();
        Thread thread=new Thread(()->{

        });

    }
    @Override
    public void run() {
        for (int i=0;i<50;i++){
            System.out.println(currentThread().getName()+":"+i);
        }
    }
}
