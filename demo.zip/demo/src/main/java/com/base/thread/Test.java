package com.base.thread;

import sun.misc.Unsafe;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.locks.StampedLock;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/10/26
 * @Modified By:
 * @since DK 1.8
 */
public class Test {
    public static void main(String[] args) {
//        AtomicInteger atomicInteger = new AtomicInteger();
//        atomicInteger.set(3);
//        atomicInteger.addAndGet(2);
//        atomicInteger.getAndAdd(3);
//        System.out.println(atomicInteger.get());
////        Unsafe unsafe = Unsafe.getUnsafe();
        ReentrantLock lock = new ReentrantLock();
        lock.lock();
        lock.unlock();

        int i = 1;
        i<<=1;
        System.out.println(i);
        List<String> list = new ArrayList<>();
        Collections.addAll(list);

        String a = "qwer";
        String replace = a.replace("q", "r");
        System.out.println(replace);


    }
}
