package com.base.thread;

import java.util.concurrent.locks.StampedLock;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/10/27
 * @Modified By:
 * @since DK 1.8
 */
public class StampedLockTest {
    public static void main(String[] args) {
        StampedLock lock = new StampedLock();
        long l = lock.tryOptimisticRead();
        boolean validate = lock.validate(l);
    }
}
