package com.base.thread;

import jdk.nashorn.internal.ir.Block;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingDeque;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.Delayed;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.TimeUnit;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/3/14
 * @Modified By:
 * @since DK 1.8
 */
public class BlockQueueTest {
    public static void main(String[] args) throws InterruptedException {
        //数组阻塞队列
        BlockingQueue<String> queue = new ArrayBlockingQueue<String>(1);
        queue.put("1");
        String take = queue.take();
        System.out.println(take);
        queue.put("2");
        System.out.println(queue.take());

        //链表队列
        LinkedBlockingQueue<String> linkedBlockingQueue = new LinkedBlockingQueue<>();
        linkedBlockingQueue.put("value");
        String take1 = linkedBlockingQueue.take();

        //优先级阻塞队列
        BlockingQueue  priorityBlockingQueue   = new PriorityBlockingQueue();
//String implements java.lang.Comparable
        priorityBlockingQueue.put("Value");
        String value = (String) priorityBlockingQueue.take();

        //同步队列
//        SynchronousQueue synchronousQueue = new SynchronousQueue();
//        synchronousQueue.put("2");
//        Object take2 = synchronousQueue.take();

        //延迟队列
        DelayQueue delayQueue = new DelayQueue();
//        delayQueue.put(new Delayed() {
//            @Override
//            public long getDelay(TimeUnit unit) {
//                return 0;
//            }
//
//            @Override
//            public int compareTo(Delayed o) {
//                return 0;
//            }
//        });


        BlockingDeque<String> deque = new LinkedBlockingDeque<String>();
        deque.addFirst("1");
        deque.addLast("2");

        String two = deque.takeLast();
        String one = deque.takeFirst();
        System.out.println(two);
        System.out.println(one);

    }
}
