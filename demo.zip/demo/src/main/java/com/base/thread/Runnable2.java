package com.base.thread;

import java.util.Vector;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.locks.ReentrantLock;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/11/9
 * @Modified By:
 * @since DK 1.8
 */
public class Runnable2 {
    static int a = 0; //多线程同时操作 val a
    static final Object obj = new Object(); //锁对象
    public static void main(String[] args) {
        Runnable runnable = () -> {
            ReentrantLock lock = new ReentrantLock();
            lock.lock();
            while (a < 10) {
                a++;
                System.out.print(a + "\t");
            }
            lock.unlock();
            synchronized (obj) {
                while (a < 10) {
                    a++;
                    System.out.print(a + "\t");
                }
            }
        };
        Thread t1 = new Thread(runnable);
        t1.start();  //线程t1 启动

//        Thread t2 = new Thread(runnable);
//        t2.start();  //线程t2 启动
//
//        Thread t3 = new Thread(runnable);
//        t3.start();  //线程t3 启动
        ExecutorService service = Executors.newSingleThreadExecutor();
    }
}
