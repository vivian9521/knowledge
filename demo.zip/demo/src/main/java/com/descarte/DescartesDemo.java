package com.descarte;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2020/11/23 16:08
 * @Modified By:
 */
public class DescartesDemo {
    public static void main(String[] args) {
        List<String> colorList = Arrays.asList("红色", "黑色", "金色");
        List<String> sizeList =Arrays.asList("");
//        List<String> sizeList = Arrays.asList("32G", "64G");
        List<String> placeList = Arrays.asList("国产", "进口");

        Map<String,String[]> splitMap=new HashMap<>();
        splitMap.put("颜色",colorList.toArray(new String[0]));
        splitMap.put("内存",sizeList.toArray(new String[0]));
        splitMap.put("产地",placeList.toArray(new String[0]));

        List<String[]> list=new ArrayList<>();
        list.add(colorList.toArray(new String[0]));
        list.add(sizeList.toArray(new String[0]));
        list.add(placeList.toArray(new String[0]));

//        Map<String, String[]> stringMap = descartes2(splitMap);
//        System.out.println(stringMap);

        List<String> list1 = descartes1(list);
        list1.forEach(System.out::println);
        System.out.println(list1);

//        List<String> descartesList = descartes(colorList,sizeList, placeList);
//        descartesList.forEach(System.out::println);
//        System.out.println(descartesList);

    }

    public static Map<String, String[]> descartes2(Map<String,String[]> splitedMap) {
        List<Map<String,String>> tempList=new ArrayList<>();
        Map<String,String[]> tempMap=new HashMap<>();
        for (Map.Entry<String,String[]> entry:splitedMap.entrySet()) {
            String key=entry.getKey();
            String[] value=entry.getValue();
           List<Map<String,String> > demoList=new ArrayList<>();
            if (tempList.isEmpty()) {

                tempList =new ArrayList<>();
            } else {
                //java8新特性，stream流
                Stream<String> stringStream = tempList.stream().flatMap(item -> demoList.stream().map(item2 -> item + "," + item2));
//                tempList.add(stringStream.)
            }
        }
        return tempMap;
    }


    public static List<String> descartes1(List<String[]> list1) {
        List<String> tempList = new ArrayList<>();
        for (String[] list : list1) {
            if (tempList.isEmpty()) {
                tempList =Arrays.asList(list);
            } else {
                //java8新特性，stream流
                tempList = tempList.stream().flatMap(item -> Arrays.stream(list).map(item2 -> item + "," + item2)).collect(Collectors.toList());
            }
        }
        return tempList;
    }

    public static List<String> descartes(List<String>... lists) {
        List<String> tempList = new ArrayList<>();
        for (List<String> list : lists) {
            if (tempList.isEmpty()) {
                tempList = list;
            } else {
                //java8新特性，stream流
                tempList = tempList.stream().flatMap(item -> list.stream().map(item2 -> item + " " + item2)).collect(Collectors.toList());
            }
        }
        return tempList;
    }
}
