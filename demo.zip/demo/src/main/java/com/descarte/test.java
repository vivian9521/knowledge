package com.descarte;

import javax.swing.*;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2020/11/24 16:06
 * @Modified By:
 */
public class test {
    public void extend(){
        System.out.println("1111111111111");
    }
    public static void main(String[] args) throws ParseException {
//        Set set= new HashSet<>();
//        set.add(null);
//        set.add(1);
//        for (Object o : set) {
//            if (o==null){
//                continue;
//            }
//            System.out.println(o);
//        }
//        set.forEach(System.out::println);
//        System.out.println(set);

        String msg="1";
        msg="2";
        System.out.println(msg);
        LocalDate now=LocalDate.now();
        LocalDate localDate = now.plusDays(7);
        LocalDate localDate1 = now.minusDays(7);
        System.out.println(localDate+"-----"+localDate1);

        List<Long> list=new ArrayList<>();
        list.add(null);
        list.add(1L);
        System.out.println(list);

        Object a="name";
        System.out.println("NAME"+a);
        System.out.println("NAME".equals("name".toUpperCase()));

        LocalDateTime b=LocalDateTime.now().plusDays(1);
        System.out.println(b);
        System.out.println(LocalDateTime.now().isAfter(b));

        System.out.println(Long.parseLong("01"));

        String a1 = new String("AAA");

        a1 = a1.substring(1);

        System.out.println("11111"==null);

        System.out.println(a1);

        String str1="12";
        int str3=12;
        DecimalFormat df=new DecimalFormat("0000");

        String str2=df.format(Integer.parseInt(str1));
        System.out.println(str2);

        SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
        System.out.println(format.format(new Date()));

        SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date tmpDate = format1.parse(new Date().toString());
        format1 = new SimpleDateFormat("yyyyMMddHHmmss");
        System.out.println(format1.format(new Date()));

    }
}
