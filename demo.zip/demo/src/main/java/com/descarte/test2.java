package com.descarte;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2021/2/22
 * @Modified By:
 * @since DK 1.8
 */
public class test2 extends test{
    @Override
    public void extend() {
        System.out.println("22222222222222222");
        super.extend();
    }

    public static void main(String[] args) {
        test2 a=new test2();
        a.extend();

        List<Integer> ticksDTOS= (List<Integer>)null;
        System.out.println(ticksDTOS);

        Boolean.parseBoolean(null);

        List<Long> b=new ArrayList<>();
        b.add(null);
//        b.addAll(null);

        System.out.println(LocalDateTime.now().isAfter(LocalDateTime.now().plusDays(1)));

//        System.out.println(!"1".equals(null));

        Date nowDate = new Date();
        long time = nowDate.getTime();
        System.out.println(time);

        long minutes = Duration.between(LocalTime.now(), LocalTime.of(0, 0, 0)).toMinutes();
        System.out.println(minutes);

        Map<String,String> map=new HashMap<>();
        String s = map.get("1");
        System.out.println(s);
        int[] a1=new int[]{};
        System.out.println(Arrays.stream(a1));

        System.out.println(LocalDateTime.now());
        LocalDate defaultDate=LocalDate.of(2020,7,22);
//        System.out.println(LocalDateTime.of(defaultDate,null));

        List<Integer> list1 = new ArrayList<Integer>() {{
                     this.add(1);
                      this.add(2);
                      this.add(3);
                  }};

             List<Integer> list2 = new ArrayList<Integer>() {{
                      this.add(2);
                    this.add(3);
                       this.add(4);
                   }};

            //取并集
              list1.removeAll(list2);
        System.out.println(list1);
        System.out.println(list2);
//               list1.forEach(System.out::println);
               System.out.println("-----------------------");
//                list2.forEach(System.out::println);
    }
}
