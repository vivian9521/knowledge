package com.leetcode;

import java.util.Comparator;
import java.util.PriorityQueue;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/13
 * @Modified By:
 * @since DK 1.8
 */
public class ListNode {
    public int val;
    public ListNode next;
    ListNode() {}
    public ListNode(int val) { this.val = val; }
    public ListNode(int val, ListNode next) { this.val = val; this.next = next; }


    /**
     * 遍历链表
     * @param listNode
     */
    public static void foreachListNode(ListNode listNode){
        while (listNode!=null){
            System.out.print(listNode.val);
            listNode=listNode.next;
            String a = new String();
            PriorityQueue<Integer> objects = new PriorityQueue<>((o1, o2) -> 0);
        }

    }
}
