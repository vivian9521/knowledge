package com.leetcode.one.hard;

import java.util.HashMap;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:466. 统计重复个数
 * 定义 str = [s, n] 表示 str 由 n 个字符串 s 连接构成。
 *
 * 例如，str == ["abc", 3] =="abcabcabc" 。
 * 如果可以从 s2 中删除某些字符使其变为 s1，则称字符串 s1 可以从字符串 s2 获得。
 *
 * 例如，根据定义，s1 = "abc" 可以从 s2 = "abdbec" 获得，仅需要删除加粗且用斜体标识的字符。
 * 现在给你两个字符串 s1 和 s2 和两个整数 n1 和 n2 。由此构造得到两个字符串，其中 str1 = [s1, n1]、str2 = [s2, n2] 。
 *
 * 请你找出一个最大整数 m ，以满足 str = [str2, m] 可以从 str1 获得。
 * @Date:Created in 2024/1/2
 * @Modified By:
 * @since DK 1.8
 */
public class GetMaxRepetitions {
    /**
     * 找出循环节
     * @param s1
     * @param n1
     * @param s2
     * @param n2
     * @return
     */
    public int getMaxRepetitions(String s1, int n1, String s2, int n2) {
        if (s1.length() * n1 < s2.length() * n2){
            return 0;
        }
        int s1cnt = 0, index = 0, s2cnt = 0;
        int[] preloop = new int[2];
        int[] inloop = new int[2];
        // s2的index,new int[]{s1数量,s2数量}
        Map<Integer, int[]> map = new HashMap<>();
        while (true){
            ++s1cnt;
            for (int i = 0; i < s1.length(); i++) {
                if (s1.charAt(i) == s2.charAt(index)){
                    index++;
                    if (index == s2.length()){
                        index = 0;
                        s2cnt++;
                    }
                }
            }
            // 还没有找到循环节，所有的 s1 就用完了
            if (s1cnt == n1){
                return s2cnt/n2;
            }
            // 出现了之前的 index，表示找到了循环节
            if (map.containsKey(index)){
                int[] value = map.get(index);
                int s1prime = value[0];
                int s2prime = value[1];
                // 前 s1cnt' 个 s1 包含了 s2cnt' 个 s2
                preloop = new int[]{s1prime, s2prime};
                // 以后的每 (s1cnt - s1cnt') 个 s1 包含了 (s2cnt - s2cnt') 个 s2
                inloop = new int[]{s1cnt - s1prime, s2cnt - s2prime};
                break;
            }else {
                map.put(index, new int[]{s1cnt, s2cnt});
            }
        }
        // ans 存储的是 S1 包含的 s2 的数量，考虑的之前的 preLoop 和 inLoop
        int ans = preloop[1] + (n1 - preloop[0])/inloop[0] * inloop[1];
        // S1 的末尾还剩下一些 s1，我们暴力进行匹配
        int rest = (n1 - preloop[0]) % inloop[0];
        for (int i = 0; i < rest; i++) {
            for (int i1 = 0; i1 < s1.length(); i1++) {
                if (s1.charAt(i1) == s2.charAt(index)){
                    index++;
                    if (index == s2.length()){
                        index = 0;
                        ans++;
                    }
                }
            }
        }
        // S1 包含 ans 个 s2，那么就包含 ans / n2 个 S2
        return ans/n2;
    }

    public int getMaxRepetitions2(String s1, int n1, String s2, int n2) {
        int num = 0,i2 = 0;
        for (int i = 0; i < n1; i++) {
            for (int i1 = 0; i1 < s1.length(); i1++) {
                if (s1.charAt(i1) == s2.charAt(i2)){
                    i2++;
                }
                if (i2 == s2.length()){
                    i2 = 0;
                    num += 1;
                }
            }
        }
       return num/n2;
    }

    public static void main(String[] args) {
        GetMaxRepetitions getMaxRepetitions = new GetMaxRepetitions();
        int maxRepetitions = getMaxRepetitions.getMaxRepetitions("acb", 4, "ab", 2);
        System.out.println(maxRepetitions);
    }

}
