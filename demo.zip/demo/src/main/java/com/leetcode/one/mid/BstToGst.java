package com.leetcode.one.mid;

import com.leetcode.TreeNode;

/**
 * @Auther:vivian
 * @Description:1038. 从二叉搜索树到更大和树
 * 给定一个二叉搜索树 root (BST)，请将它的每个节点的值替换成树中大于或者等于该节点值的所有节点值之和。
 *
 * 提醒一下， 二叉搜索树 满足下列约束条件：
 *
 * 节点的左子树仅包含键 小于 节点键的节点。
 * 节点的右子树仅包含键 大于 节点键的节点。
 * 左右子树也必须是二叉搜索树。
 * @Date:Created in 2023/12/4
 * @Modified By:
 * @since DK 1.8
 */
public class BstToGst {

    public TreeNode bstToGst(TreeNode root) {
        dfs(root);
        return root;
    }
    private int num = 0;
    private void dfs(TreeNode root){
        if (root == null){
            return;
        }
        dfs(root.right);
        num += root.val;
        root.val = num;
//        System.out.println(root.val);
//        System.out.println(num);
        dfs(root.left);
    }

    public static void main(String[] args) {
        BstToGst bstToGst = new BstToGst();

        TreeNode treeNode = new TreeNode();
        treeNode.val = 4;
        treeNode.left = new TreeNode(1, new TreeNode(0), new TreeNode(2, new TreeNode(),new TreeNode(3)));
        treeNode.right = new TreeNode(6, new TreeNode(5), new TreeNode(7, new TreeNode(), new TreeNode(8)));
        bstToGst.bstToGst(treeNode);

    }
}
