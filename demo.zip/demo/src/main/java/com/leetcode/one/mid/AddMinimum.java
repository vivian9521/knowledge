package com.leetcode.one.mid;

/**
 * @Auther:vivian
 * @Description:2645. 构造有效字符串的最少插入数
 * 给你一个字符串 word ，你可以向其中任何位置插入 "a"、"b" 或 "c" 任意次，返回使 word 有效 需要插入的最少字母数。
 *
 * 如果字符串可以由 "abc" 串联多次得到，则认为该字符串 有效 。
 * @Date:Created in 2024/1/11
 * @Modified By:
 * @since DK 1.8
 */
public class AddMinimum {
    /**
     * 考虑个数
     * 假设结果有t个abc ,则需要插入数3t-word.len个
     * 如果x < y ,则可能在一个abc里
     * 如果x >= y ,则一定不在一个abc里，所以t+1;
     * @param word
     * @return
     */
    public int addMinimum(String word) {
        int t = 1;
        int n = word.length();
        for (int i = 0; i < n - 1; i++) {
            if (word.charAt(i) >= word.charAt(i + 1)){
                t++;
            }
        }
        return 3 * t - n;
    }

}
