package com.leetcode.one.mid;

import com.leetcode.TreeNode;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:105. 从前序与中序遍历序列构造二叉树
 * 给定两个整数数组 preorder 和 inorder ，其中 preorder 是二叉树的先序遍历，
 * inorder 是同一棵树的中序遍历，请构造二叉树并返回其根节点。
 * @Date:Created in 2024/2/20
 * @Modified By:
 * @since DK 1.8
 */
public class BuildTree {

    private Map<Integer, Integer> inMap;
    private int[] preorder;
    public TreeNode buildTree(int[] preorder, int[] inorder) {
        inMap = new HashMap<>();
        this.preorder = preorder;
        for (int i = 0; i < inorder.length; i++) {
            inMap.put(inorder[i], i);
        }
        return dfs(0, 0, preorder.length-1);
    }


    private TreeNode dfs(int root, int left , int right){
        if (left > right){
            return null;
        }
        TreeNode treeNode  = new TreeNode(preorder[root]);

        Integer index = inMap.get(preorder[root]);
        treeNode.left = dfs(root + 1, left, index - 1);
        //root + index - left + 1 = 根节点+左子树长度+1
        treeNode.right = dfs(root + index - left + 1, index + 1, right);
        return treeNode;
    }

    public static void main(String[] args) {
        BuildTree buildTree = new BuildTree();
        TreeNode treeNode = buildTree.buildTree(new int[]{3, 9, 20, 15, 17}, new int[]{9, 3, 15, 20, 17});

    }
}
