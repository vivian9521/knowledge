package com.leetcode.one.hard;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:1463. 摘樱桃 II
 * 给你一个 rows x cols 的矩阵 grid 来表示一块樱桃地。 grid 中每个格子的数字表示你能获得的樱桃数目。
 *
 * 你有两个机器人帮你收集樱桃，机器人 1 从左上角格子 (0,0) 出发，机器人 2 从右上角格子 (0, cols-1) 出发。
 *
 * 请你按照如下规则，返回两个机器人能收集的最多樱桃数目：
 *
 * 从格子 (i,j) 出发，机器人可以移动到格子 (i+1, j-1)，(i+1, j) 或者 (i+1, j+1) 。
 * 当一个机器人经过某个格子时，它会把该格子内所有的樱桃都摘走，然后这个位置会变成空格子，即没有樱桃的格子。
 * 当两个机器人同时到达同一个格子时，它们中只有一个可以摘到樱桃。
 * 两个机器人在任意时刻都不能移动到 grid 外面。
 * 两个机器人最后都要到达 grid 最底下一行。
 * @Date:Created in 2024/5/7
 * @Modified By:
 * @since DK 1.8
 */
public class CherryPickup2 {
    /**
     * 递归
     * @param grid
     * @return
     */
    public int cherryPickup(int[][] grid) {
        int m = grid.length;
        int n = grid[0].length;
        int[][][] memo = new int[m][n][n];
        for (int[][] me : memo) {
            for (int[] r : me) {
                Arrays.fill(r, -1);
            }
        }
        return dfs(0, 0, n-1, grid, memo);
    }

    private int dfs(int i, int j, int k, int[][] grid, int[][][] memo){
        int m = grid.length;
        int n = grid[0].length;
        if (i == m || j >= n || k >= n || j < 0 || k < 0 ){
            return 0;
        }
        if (memo[i][j][k] != -1){
            return memo[i][j][k];
        }
        int res = 0;
        for (int r1 = j - 1; r1 <= j + 1; r1++){
            for (int r2 = k - 1; r2 <= k + 1; r2++){
                res = Math.max(res, dfs(i + 1, r1, r2, grid, memo));
            }
        }
        res += grid[i][j] + (j == k ? 0 : grid[i][k]);
        memo[i][j][k] = res;
        return res;
    }



}
