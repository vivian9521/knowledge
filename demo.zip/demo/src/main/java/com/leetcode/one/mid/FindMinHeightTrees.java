package com.leetcode.one.mid;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * @Auther:vivian
 * @Description:310. 最小高度树
 * 树是一个无向图，其中任何两个顶点只通过一条路径连接。 换句话说，一个任何没有简单环路的连通图都是一棵树。
 *
 * 给你一棵包含 n 个节点的树，标记为 0 到 n - 1 。给定数字 n 和一个有 n - 1 条无向边的 edges 列表（每一个边都是一对标签），
 * 其中 edges[i] = [ai, bi] 表示树中节点 ai 和 bi 之间存在一条无向边。
 *
 * 可选择树中任何一个节点作为根。当选择节点 x 作为根节点时，设结果树的高度为 h 。
 * 在所有可能的树中，具有最小高度的树（即，min(h)）被称为 最小高度树 。
 *
 * 请你找到所有的 最小高度树 并按 任意顺序 返回它们的根节点标签列表。
 *
 * 树的 高度 是指根节点和叶子节点之间最长向下路径上边的数量。
 * @Date:Created in 2024/3/18
 * @Modified By:
 * @since DK 1.8
 */
public class FindMinHeightTrees {
    /**
     * 拓扑排序
     * 简单分析过程：
     * 首先，我们看了样例，发现这个树并不是二叉树，是多叉树。
     * 然后，我们可能想到的解法是：根据题目的意思，就挨个节点遍历bfs，统计下每个节点的高度，
     * 然后用map存储起来，后面查询这个高度的集合里最小的就可以了。
     * 但是这样会超时的。
     * 于是我们看图（题目介绍里面的图）分析一下，发现，越是靠里面的节点越有可能是最小高度树。
     * 所以，我们可以这样想，我们可以倒着来。
     * 我们从边缘开始，先找到所有出度为1的节点，然后把所有出度为1的节点进队列，然后不断地bfs，
     * 最后找到的就是两边同时向中间靠近的节点，那么这个中间节点就相当于把整个距离二分了，那么它当然就是到两边距离最小的点啦，
     * 也就是到其他叶子节点最近的节点了。
     * @param n
     * @param edges
     * @return
     */
    public List<Integer> findMinHeightTrees(int n, int[][] edges) {
        List<Integer> res = new ArrayList<>();
        if (n == 1){
            res.add(0);
            return res;
        }
        //出度数组
        int[] degree = new int[n];
        List<Integer>[] g = new ArrayList[n];
        Arrays.setAll(g, x->new ArrayList<>());
        for (int[] edge : edges) {
            int x = edge[0];
            int y = edge[1];
            degree[x]++;
            degree[y]++;
            g[x].add(y);
            g[y].add(x);
        }
        //将出度=1 的放入队列
        Queue<Integer> queue = new LinkedList<>();
        for (int i = 0; i < n; i++) {
            if (degree[i] == 1){
                queue.offer(i);
            }
        }
        while (!queue.isEmpty()){
            res = new ArrayList<>();
            int size = queue.size();

            for (int i = 0; i < size; i++) {
                int cur = queue.poll();
                res.add(cur);
                for (int y : g[cur]) {
                    degree[y]--;
                    if (degree[y] == 1){
                        queue.offer(y);
                    }
                }
            }
        }

        return res;

    }

    public static void main(String[] args) {

        int hour = LocalDateTime.now().getMinute();
        System.out.println(hour);
    }

}
