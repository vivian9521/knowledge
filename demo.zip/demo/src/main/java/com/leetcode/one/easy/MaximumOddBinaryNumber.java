package com.leetcode.one.easy;

import com.leetcode.one.mid.ReachableNodes;

/**
 * @Auther:vivian
 * @Description:2864. 最大二进制奇数
 * 给你一个 二进制 字符串 s ，其中至少包含一个 '1' 。
 *
 * 你必须按某种方式 重新排列 字符串中的位，使得到的二进制数字是可以由该组合生成的 最大二进制奇数 。
 *
 * 以字符串形式，表示并返回可以由给定组合生成的最大二进制奇数。
 *
 * 注意 返回的结果字符串 可以 含前导零。
 * @Date:Created in 2024/3/13
 * @Modified By:
 * @since DK 1.8
 */
public class MaximumOddBinaryNumber {

    public String maximumOddBinaryNumber2(String s) {
        //1的个数
        int cnt1 = (int) s.chars().filter(c -> c == '1').count();
//        return "1".repeat(cnt1 - 1) + "0".repeat(s.length() - cnt1) + "1";
        return "";
    }
    public String maximumOddBinaryNumber(String s) {
        //找出s中1的个数和0的个数
        int num0 = 0, num1 = 0;
        char[] chars = s.toCharArray();
        for (char aChar : chars) {
            if (aChar == '1'){
                num1++;
            }else {
                num0++;
            }
        }
        //最后一位放1
        num1--;
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < num1; i++) {
            builder.append("1");
        }
        for (int i = 0; i < num0; i++) {
            builder.append("0");
        }
        builder.append("1");
        return builder.toString();
    }

    public static void main(String[] args) {
        MaximumOddBinaryNumber maximumOddBinaryNumber = new MaximumOddBinaryNumber();
        String s = maximumOddBinaryNumber.maximumOddBinaryNumber("010");
        System.out.println(s);
    }
}
