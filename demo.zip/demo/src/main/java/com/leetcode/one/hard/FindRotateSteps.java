package com.leetcode.one.hard;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:514. 自由之路
 * 电子游戏“辐射4”中，任务 “通向自由” 要求玩家到达名为 “Freedom Trail Ring” 的金属表盘，并使用表盘拼写特定关键词才能开门。
 *
 * 给定一个字符串 ring ，表示刻在外环上的编码；给定另一个字符串 key ，表示需要拼写的关键词。您需要算出能够拼写关键词中所有字符的最少步数。
 *
 * 最初，ring 的第一个字符与 12:00 方向对齐。您需要顺时针或逆时针旋转 ring 以使 key 的一个字符在 12:00 方向对齐，然后按下中心按钮，以此逐个拼写完 key 中的所有字符。
 *
 * 旋转 ring 拼出 key 字符 key[i] 的阶段中：
 *
 * 您可以将 ring 顺时针或逆时针旋转 一个位置 ，计为1步。旋转的最终目的是将字符串 ring 的一个字符与 12:00 方向对齐，并且这个字符必须等于字符 key[i] 。
 * 如果字符 key[i] 已经对齐到12:00方向，您需要按下中心按钮进行拼写，这也将算作 1 步。按完之后，您可以开始拼写 key 的下一个字符（下一阶段）, 直至完成所有拼写。
 * @Date:Created in 2024/1/29
 * @Modified By:
 * @since DK 1.8
 */
public class FindRotateSteps {
    /**
     * 结果值=移动次数+key.len(也就是需要拼写的长度)
     * @param ring
     * @param key
     * @return
     */
    public int findRotateSteps2(String ring, String key) {
        int n = ring.length(), m = key.length();
        //记录ring每个位置都在哪,例如godding里是 g在 0 6， d在 2 3
        List<Integer>[] pos = new List[26];
        for (int i = 0; i < 26; i++) {
            pos[i] = new ArrayList<>();
        }
        for (int i = 0; i < n; i++) {
            pos[ring.charAt(i) - 'a'].add(i);
        }
        //定义dp,在匹配key中第i个字母时，使用ring中第j个位置所需的操作次数
        int[][] dp = new int[m][n];
        for (int[] sudp : dp) {
            Arrays.fill(sudp, Integer.MAX_VALUE);
        }
        for (int i = 0; i < m; i++) {
            //j是key[i]字母在ring中的位置
            for (int j : pos[key.charAt(i) - 'a']) {
                //key的第一个字母，不需要考虑任何前面的次数
                //只需要计算 指针从0 转到 j 的操作次数 ， 选择当前， 就是总操作数
                if (i == 0){
                    dp[i][j] = Math.min(dp[i][j], 0 + calc(n, 0, j));
                    continue;
                }
                //当i非0的时候，需要看下之前的字母操作次数
                //k就是前一个字母位置
                for (int k : pos[key.charAt(i - 1) - 'a']) {
                    //非第一个的字母， 需要看一下从前面的字母，怎么转移来是操作数最小的。
                    //比如给的例子，dp[0][1] = 2, dp[0][8] = 3,
                    //然后匹配第二个字母的时候，dp[1][3] = min(dp[0][1] + 从1转到3 + 1, dp[0][8] + 从 8 转到3 + 1)
                    dp[i][j] = Math.min(dp[i][j], dp[i-1][k] + calc(n, k, j));
                }
            }
        }
        return Arrays.stream(dp[m - 1]).min().getAsInt() + m;
    }

    /**
     * 计算指针a到b最少需要转多少次
     * @param n
     * @param a
     * @param b
     * @return
     */
    private int calc(int n, int a, int b){
        return Math.min((n + a - b)%n, (n + b - a)%n);
    }

    public static void main(String[] args) {
        FindRotateSteps findRotateSteps = new FindRotateSteps();
        int rotateSteps2 = findRotateSteps.findRotateSteps2("godding", "gd");

    }
    public int findRotateSteps(String S, String T) {
        char[] s = S.toCharArray();
        char[] t = T.toCharArray();
        int n = s.length;
        int m = t.length;

        //先算出每个字母最后一次出现的下标
        //由于s是环形的，循环结束后的pos就刚好是left[0]
        int[] pos = new int[26];
        for (int i = 0; i < n; i++) {
            s[i] -= 'a';
            pos[s[i]] = i;
        }
        //计算每个s[i]左边的a-z的最近下标（左边没有就从n-1往左找）
        int[][] left = new int[n][26];
        for (int i = 0; i < n; i++) {
            System.arraycopy(pos, 0, left[i], 0, 26);
            pos[s[i]] = i;//更新下标
        }

        //先计算出每个字母首次出现的下标
        //由于s是环形的，循环结束后的pos就刚好是，right[n-1]
        for (int i = n - 1; i >= 0; i--) {
            pos[s[i]] = i;
        }
        //计算每个s[i]右边的a-z最近下标（右边没有就从0往右找）
        int[][] right = new int[n][26];
        for (int i = n - 1; i >= 0; i--) {
            System.arraycopy(pos, 0, right[i], 0 , 26);
            pos[s[i]] = i;
        }

        int[][] f = new int[m + 1][n];
        for (int j = m - 1; j >= 0; j--) {
            int c = t[j] - 'a';
            for (int i = 0; i < n; i++) {
                if (s[i] == c){//无需旋转
                    f[j][i] = f[j + 1][i];
                }else {//左边最近or右边最近，取最小值
                    int l = left[i][c], r = right[i][c];
                    f[j][i] = Math.min(f[j + 1][l] + ((l > i) ? n - l + i : i - l),
                            f[j + 1][r] + (r < i ? n - i + r : r - i));

                }
            }
        }
        return f[0][0] + m;
    }

}
