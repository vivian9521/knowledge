package com.leetcode.one.hard;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:2581. 统计可能的树根数目
 * Alice 有一棵 n 个节点的树，节点编号为 0 到 n - 1 。树用一个长度为 n - 1 的二维整数数组 edges 表示
 * ，其中 edges[i] = [ai, bi] ，表示树中节点 ai 和 bi 之间有一条边。
 *
 * Alice 想要 Bob 找到这棵树的根。她允许 Bob 对这棵树进行若干次 猜测 。每一次猜测，Bob 做如下事情：
 *
 * 选择两个 不相等 的整数 u 和 v ，且树中必须存在边 [u, v] 。
 * Bob 猜测树中 u 是 v 的 父节点 。
 * Bob 的猜测用二维整数数组 guesses 表示，其中 guesses[j] = [uj, vj] 表示 Bob 猜 uj 是 vj 的父节点。
 *
 * Alice 非常懒，她不想逐个回答 Bob 的猜测，只告诉 Bob 这些猜测里面 至少 有 k 个猜测的结果为 true 。
 *
 * 给你二维整数数组 edges ，Bob 的所有猜测和整数 k ，请你返回可能成为树根的 节点数目 。如果没有这样的树，则返回 0。
 * @Date:Created in 2024/2/29
 * @Modified By:
 * @since DK 1.8
 */
public class RootCount {
    /**
     * 枚举根节点会超时
     * @param edges
     * @param guesses
     * @param k
     * @return
     */
    public int rootCount(int[][] edges, int[][] guesses, int k) {
        int n = edges.length + 1;
        //每个节点路径列表
        List<Integer>[] g = new ArrayList[n];
        Arrays.setAll(g, x->new ArrayList<>());
        for (int[] edge : edges) {
            int x = edge[0], y = edge[1];
            g[x].add(y);
            g[y].add(x);
        }
        //猜测节点路径列表
        List<Integer>[] e = new ArrayList[n];
        Arrays.setAll(e, x->new ArrayList<>());
        for (int[] guesse : guesses) {
            int x = guesse[0], y = guesse[1];
            e[x].add(y);
        }
        int ans = 0;
        //各个根节点
        for (int i = 0; i < n; i++) {
            boolean[] seen = new boolean[n];
            seen[i] = true;
            //节点的连接路径
            int sum = dfs(i, -1, g, seen, e);
            if (sum >= k){
                ans++;
            }
        }
        return ans;
    }

    private int dfs(int x, int f, List<Integer>[] g, boolean[] seen, List<Integer>[] e){
        int sum = 0;
        for (int y : g[x]) {
            if (y != f && !seen[y]){
                if (e[x].contains(y)){
                    sum++;
                }
                seen[y] = true;
                sum += dfs(y, x, g, seen, e);
            }
        }
        return sum;
    }

    public static void main(String[] args) {
        RootCount rootCount = new RootCount();
        int i = rootCount.rootCount(new int[][]{{0, 1}, {1, 2}, {1, 3}, {4, 2}}, new int[][]{{1, 3}, {0, 1}, {1, 0}, {2, 4}}, 3);
        System.out.println(i);

    }
}
