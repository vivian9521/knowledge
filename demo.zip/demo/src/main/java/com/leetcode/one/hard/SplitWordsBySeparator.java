package com.leetcode.one.hard;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * @Auther:vivian
 * @Description:2788. 按分隔符拆分字符串
 * 给你一个字符串数组 words 和一个字符 separator ，请你按 separator 拆分 words 中的每个字符串。
 *
 * 返回一个由拆分后的新字符串组成的字符串数组，不包括空字符串 。
 *
 * 注意
 *
 * separator 用于决定拆分发生的位置，但它不包含在结果字符串中。
 * 拆分可能形成两个以上的字符串。
 * 结果字符串必须保持初始相同的先后顺序。
 * @Date:Created in 2024/1/22
 * @Modified By:
 * @since DK 1.8
 */
public class SplitWordsBySeparator {

    public List<String> splitWordsBySeparator(List<String> words, char separator) {
        List<String> resList = new ArrayList<>();
        Pattern.quote(String.valueOf(separator));
        for (String word : words) {
            String[] split = word.split(Pattern.quote(String.valueOf(separator)));
//            String[] split = word.split("\\" + separator);
            for (String s : split) {
                if (s.length() != 0){
                    resList.add(s);
                }
            }
        }
        return resList;
    }

    private String getReg(Character c){
        //.,|$#@
        switch (c){
            case '.':
                return "\\.";
            case ',':
                return "\\,";
            case '/':
                return "\\/";
            case '$':
                return "\\$";
            case '#':
                return "\\#";
            case '@':
                return "\\@";
        }
        return null;
    }

    public static void main(String[] args) {
        List<String> resList = new ArrayList<>();
        resList.add("one.two.three");
        resList.add("four.five");
        resList.add("six");
        SplitWordsBySeparator splitWordsBySeparator = new SplitWordsBySeparator();
        List<String> strings = splitWordsBySeparator.splitWordsBySeparator(resList, '.');
        System.out.println(strings);
    }
}
