package com.leetcode.one.mid;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:377. 组合总和 Ⅳ
 * 给你一个由 不同 整数组成的数组 nums ，和一个目标整数 target 。请你从 nums 中找出并返回总和为 target 的元素组合的个数。
 *
 * 题目数据保证答案符合 32 位整数范围。
 * @Date:Created in 2024/4/22
 * @Modified By:
 * @since DK 1.8
 */
public class CombinationSum4 {

    public int combinationSum41(int[] nums, int target) {
        int[] f = new int[target + 1];
        f[0] = 1;
        for (int i = 1; i <= target; i++) {
            for (int num : nums) {
                if (i >= num){
                    f[i] += f[i - num];
                }
            }
        }
        return f[target];
    }


    public int combinationSum4(int[] nums, int target) {
        int[] memo = new int[target + 1];
        Arrays.fill(memo, -1);
        return backtrack(target, nums, memo);
    }

    private int backtrack(int tar, int[] nums, int[] memo){
        if (tar == 0){
            return 1;
        }
        if (memo[tar] != -1){
            return memo[tar];
        }
        int res = 0;
        for (int num : nums) {
            if (tar - num < 0){
                break;
            }
            res += backtrack(tar - num, nums, memo);
        }
        return memo[tar] = res;
    }

    public static void main(String[] args) {
        CombinationSum4 combinationSum4 = new CombinationSum4();
        int i = combinationSum4.combinationSum4(new int[]{1, 2, 3}, 35);
        System.out.println(i);


    }
}
