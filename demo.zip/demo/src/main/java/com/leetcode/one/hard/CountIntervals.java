package com.leetcode.one.hard;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * @Auther:vivian
 * @Description:2276. 统计区间中的整数数目
 * 给你区间的 空 集，请你设计并实现满足要求的数据结构：
 *
 * 新增：添加一个区间到这个区间集合中。
 * 统计：计算出现在 至少一个 区间中的整数个数。
 * 实现 CountIntervals 类：
 *
 * CountIntervals() 使用区间的空集初始化对象
 * void add(int left, int right) 添加区间 [left, right] 到区间集合之中。
 * int count() 返回出现在 至少一个 区间中的整数个数。
 * 注意：区间 [left, right] 表示满足 left <= x <= right 的所有整数 x 。
 * @Date:Created in 2023/12/19
 * @Modified By:
 * @since DK 1.8
 */
public class CountIntervals {
    //用一颗平衡树维护不相交的区间，每次 add(left,right) 时，删除被该区间覆盖到的区间（部分覆盖也算），
    // 然后将被删除的区间与 [left,right]合并成一个新的大区间（并集），插入平衡树中。
    //代码实现时，为方便找到第一个被 [left,right]覆盖到的区间，我们可以用平衡树的 key 存区间右端点，value存区间左端点。
    // 我们要找的就是第一个 key≥left的区间。
    /**
     * 珂朵莉树解法或平衡树解法
     */
    private TreeMap<Integer, Integer> treeMap;//key=右，value=左
    int cnt;
    public CountIntervals() {
        treeMap = new TreeMap<>();
    }

    public void add(int left, int right) {
        //第一个大于left的右侧值
        Map.Entry<Integer, Integer> e = treeMap.ceilingEntry(left);
        while (e!= null && e.getValue() <= right){
            int l = e.getValue();
            int r = e.getKey();
            left = Math.min(left, l);
            right = Math.max(right, r);
            cnt -= r - l + 1;
            treeMap.remove(r);
            e = treeMap.ceilingEntry(left);
        }
        cnt += right - left + 1;
        treeMap.put(right, left);
    }

    public int count() {
        return cnt;
    }
}
