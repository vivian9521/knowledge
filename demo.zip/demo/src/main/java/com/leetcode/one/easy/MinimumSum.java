package com.leetcode.one.easy;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:2908. 元素和最小的山形三元组 I
 * 给你一个下标从 0 开始的整数数组 nums 。
 *
 * 如果下标三元组 (i, j, k) 满足下述全部条件，则认为它是一个 山形三元组 ：
 *
 * i < j < k
 * nums[i] < nums[j] 且 nums[k] < nums[j]
 * 请你找出 nums 中 元素和最小 的山形三元组，并返回其 元素和 。如果不存在满足条件的三元组，返回 -1 。
 * @Date:Created in 2024/3/29
 * @Modified By:
 * @since DK 1.8
 */
public class MinimumSum {

    public int minimumSum2(int[] nums) {
        int n = nums.length;
        int ans = Integer.MAX_VALUE;
        //前i-1个最小值
        int[] pre = new int[n];
        Arrays.fill(pre, Integer.MAX_VALUE);
        pre[0] = nums[0];
        for (int i = 1; i < n; i++) {
            pre[i] = Math.min(pre[i-1], nums[i]);
        }
        //i+1 到n个最小值
        int[] last = new int[n];
        Arrays.fill(last, Integer.MAX_VALUE);
        last[n - 1] = nums[n - 1];
        for (int i = n - 2; i >= 0; i--) {
            last[i] = Math.min(last[i + 1], nums[i]);
        }
        for (int i = 1; i < n - 1; i++) {
            if (nums[i] > pre[i-1] && nums[i] > last[i + 1]){
                ans = Math.min(ans, nums[i] + pre[i-1] + last[i+1]);
            }
        }
        return ans == Integer.MAX_VALUE ? -1 : ans;
    }

    public int minimumSum(int[] nums) {
        int n = nums.length;
        int ans = Integer.MAX_VALUE;
        for (int i = 1; i < n - 1; i++) {
            int pre = Integer.MAX_VALUE;
            int last = Integer.MAX_VALUE;
            for (int j = 0; j < i; j++) {
                pre = Math.min(pre, nums[j]);
            }
            for (int k = i + 1; k < n; k++) {
                last = Math.min(last, nums[k]);
            }
            if (nums[i] > pre && nums[i] > last){
                ans = Math.min(ans, nums[i] + pre + last);
            }
        }
        return ans == Integer.MAX_VALUE ? -1 : ans;
    }
}
