package com.leetcode.one.easy;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:2917. 找出数组中的 K-or 值
 * 给你一个下标从 0 开始的整数数组 nums 和一个整数 k 。
 *
 * nums 中的 K-or 是一个满足以下条件的非负整数：
 *
 * 只有在 nums 中，至少存在 k 个元素的第 i 位值为 1 ，那么 K-or 中的第 i 位的值才是 1 。
 * 返回 nums 的 K-or 值。
 *
 * 注意 ：对于整数 x ，如果 (2i AND x) == 2i ，则 x 中的第 i 位值为 1 ，其中 AND 为按位与运算符。
 * @Date:Created in 2024/3/6
 * @Modified By:
 * @since DK 1.8
 */
public class FindKOr {
    public int findKOr(int[] nums, int k) {
        int ans = 0;
        for (int i = 0; i < 31; i++) {
            int cnt = 0;
            //计算i位上的1；
            for (int num : nums) {
                cnt += num>>i & 1;
            }
            if (cnt >= k){
                ans += 1<<i;
            }
        }
        return ans;
    }

    public int findKOr2(int[] nums, int k) {
        int ans = 0;
        if (k == 1){
            for (int num : nums) {
                ans = ans|num;
            }
            return ans;
        }else {
            for (int i = 0; i <= 31; i++) {
                int k1 = 0;
                for (int num : nums) {
                    if (((int)Math.pow(2, i)&num) == Math.pow(2,i)){
                        k1++;
                    }
                }
                if (k1 >= k){
                    ans += (int)Math.pow(2, i);
                }
            }
            return ans;
        }
    }

    public static void main(String[] args) {
        FindKOr findKOr = new FindKOr();
        int kOr = findKOr.findKOr(new int[]{2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647,2147483647}, 50);
        System.out.println(kOr);
        int a = 2147483647;
    }
}
