package com.leetcode.one.easy;

import java.util.concurrent.BlockingDeque;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2024/1/23
 * @Modified By:
 * @since DK 1.8
 */
public class Thread1 {

    static class PutThread extends Thread {
        private ConcurrentLinkedQueue<Integer> clq;
        public PutThread(ConcurrentLinkedQueue<Integer> clq) {
            this.clq = clq;
        }

        public void run() {
            for (int i = 0; i < 10; i++) {
                try {
                    System.out.println("add " + i);
                    clq.add(i);
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    static class GetThread extends Thread {
        private ConcurrentLinkedQueue<Integer> clq;
        public GetThread(ConcurrentLinkedQueue<Integer> clq) {
            this.clq = clq;
        }

        public void run() {
            for (int i = 0; i < 10; i++) {
                try {
                    System.out.println("poll " + clq.poll());
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public static void main(String[] args) throws InterruptedException {
//        ConcurrentLinkedQueue<Integer> clq = new ConcurrentLinkedQueue<Integer>();
//        PutThread p1 = new PutThread(clq);
//        GetThread g1 = new GetThread(clq);
//
//        p1.start();
//        g1.start();

        BlockingDeque<String> deque = new LinkedBlockingDeque<String>();
        deque.addFirst("1");
        deque.addLast("2");

        String two = deque.takeLast();
        String one = deque.takeFirst();
        System.out.println(two);
        System.out.println(one);

//        Class<?> aClass1 = Class.forName("");
//        ClassLoader classLoader = Thread1.class.getClassLoader();
//        Class<?> aClass = classLoader.loadClass("");
//        aClass.newInstance();
    }

}
