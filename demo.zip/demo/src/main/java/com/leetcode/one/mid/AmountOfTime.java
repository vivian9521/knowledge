package com.leetcode.one.mid;

import com.leetcode.TreeNode;

import java.util.HashMap;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:2385. 感染二叉树需要的总时间
 * 给你一棵二叉树的根节点 root ，二叉树中节点的值 互不相同 。另给你一个整数 start 。
 * 在第 0 分钟，感染 将会从值为 start 的节点开始爆发。
 *
 * 每分钟，如果节点满足以下全部条件，就会被感染：
 *
 * 节点此前还没有感染。
 * 节点与一个已感染节点相邻。
 * 返回感染整棵树需要的分钟数。
 * @Date:Created in 2024/4/24
 * @Modified By:
 * @since DK 1.8
 */
public class AmountOfTime {
    /**
     * 记录父节点+dfs(求最大深度)
     */
    //开始节点
    private TreeNode startNode;
    //父节点map
    private Map<TreeNode, TreeNode> fa = new HashMap<>();
    public int amountOfTime(TreeNode root, int start) {
        dfs(root, null, start);
        return maxDepth(startNode, startNode);
    }
    private void dfs(TreeNode node, TreeNode from, int start){
        if (node == null){
            return;
        }
        fa.put(node, from);
        if (node.val == start){
            startNode = node;
        }
        dfs(node.left, node, start);
        dfs(node.right, node, start);
    }

    private int maxDepth(TreeNode node, TreeNode from){
        if (node == null){
            return -1;
        }
        int res = -1;
        //左侧树深度
        if (node.left != from){
            res = Math.max(res, maxDepth(node.left, node));
        }
        //右侧树深度
        if (node.right != from){
            res = Math.max(res, maxDepth(node.right, node));
        }
        //父节点树深度
        if (fa.get(node) != from){
            res = Math.max(res, maxDepth(fa.get(node), node));
        }
        return res;
    }
}
