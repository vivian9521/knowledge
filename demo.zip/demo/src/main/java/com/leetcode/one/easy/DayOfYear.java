package com.leetcode.one.easy;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;

/**
 * @Auther:vivian
 * @Description:1154. 一年中的第几天
 * 给你一个字符串 date ，按 YYYY-MM-DD 格式表示一个 现行公元纪年法 日期。返回该日期是当年的第几天。
 * @Date:Created in 2024/1/3
 * @Modified By:
 * @since DK 1.8
 */
public class DayOfYear {


    public int dayOfYear(String date) {
        int[] months = new int[]{31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        int res = 0;
        String[] split = date.split("-");
        int year = Integer.parseInt(split[0]);
        int month = Integer.parseInt(split[1]);
        int day = Integer.parseInt(split[2]);
        //判断平年还是闰年
        if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)){
            months[1] = months[1] + 1;
        }
        for (int i = 0; i < month-1; i++) {
            res += months[i];
        }
        res = res + day;
        return res;
    }
}
