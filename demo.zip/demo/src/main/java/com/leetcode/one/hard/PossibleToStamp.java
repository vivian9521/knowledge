package com.leetcode.one.hard;

/**
 * @Auther:vivian
 * @Description:2132. 用邮票贴满网格图
 * 给你一个 m x n 的二进制矩阵 grid ，每个格子要么为 0 （空）要么为 1 （被占据）。
 *
 * 给你邮票的尺寸为 stampHeight x stampWidth 。我们想将邮票贴进二进制矩阵中，且满足以下 限制 和 要求 ：
 *
 * 覆盖所有 空 格子。
 * 不覆盖任何 被占据 的格子。
 * 我们可以放入任意数目的邮票。
 * 邮票可以相互有 重叠 部分。
 * 邮票不允许 旋转 。
 * 邮票必须完全在矩阵 内 。
 * 如果在满足上述要求的前提下，可以放入邮票，请返回 true ，否则返回 false 。
 * @Date:Created in 2023/12/14
 * @Modified By:
 * @since DK 1.8
 */
public class PossibleToStamp {
    /**
     * 二维差分数组和二维前缀和
     * @param grid
     * @param stampHeight
     * @param stampWidth
     * @return
     */
    public boolean possibleToStamp(int[][] grid, int stampHeight, int stampWidth) {
        int m = grid.length;
        int n = grid[0].length;
        //1、计算数组二维前缀和，可以用来判断是否可贴邮票，如果前缀和=0，则可贴
        int[][] presums = new int[m+1][n+1];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                presums[i+1][j+1] = presums[i+1][j] + presums[i][j+1] - presums[i][j] + grid[i][j];
            }
        }

        //2、计算二维差分数组，如果前缀和=0， 则对差分数组四个角进行+1，-1操作，用来后面直接求前缀和进行还原计数
        //例子：原数组：1, 3,3,5, 8    +10数组：1, 13,13,15, 8
        // 原数组池差分：1 ,2,0,2, 3   +10数组差分：1, 12,0,2, -7
        // （因为连续子数组进行+1操作后，再进行差分，差分数组只有第一个元素+1,和子数组后一个-1）
        int[][] d = new int[m+2][n+2];
        for (int i2 = stampHeight; i2 <= m; i2++) {
            for (int j2 = stampWidth; j2 <= n; j2++) {
                int i1 = i2 - stampHeight + 1;
                int j1 = j2 - stampWidth + 1;
                //判断是否可贴邮票，如果前缀和=0，则可贴
                if (presums[i2][j2] - presums[i2][j1-1] - presums[i1-1][j2] + presums[i1-1][j1-1] == 0){
                    d[i1][j1]++;
                    d[i2+1][j2+1]++;
                    d[i1][j2+1]--;
                    d[i2+1][j1]--;
                }
            }
        }
        //还原数组（原地求前缀和）
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                d[i+1][j+1] += d[i+1][j] + d[i][j+1] - d[i][j];
                if (grid[i][j] == 0 && d[i + 1][j + 1] == 0){
                    return false;
                }
            }
        }
        return true;
    }
}
