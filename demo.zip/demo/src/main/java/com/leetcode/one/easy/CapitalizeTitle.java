package com.leetcode.one.easy;

/**
 * @Auther:vivian
 * @Description:2129. 将标题首字母大写
 * 给你一个字符串 title ，它由单个空格连接一个或多个单词组成，每个单词都只包含英文字母。请你按以下规则将每个单词的首字母 大写 ：
 *
 * 如果单词的长度为 1 或者 2 ，所有字母变成小写。
 * 否则，将单词首字母大写，剩余字母变成小写。
 * 请你返回 大写后 的 title 。
 * @Date:Created in 2024/3/12
 * @Modified By:
 * @since DK 1.8
 */
public class CapitalizeTitle {

    public String capitalizeTitle(String title) {
        StringBuilder builder = new StringBuilder();
        String[] s = title.split(" ");
        for (String s1 : s) {
            if (s1.length() <= 2){//小写
                builder.append(s1.toLowerCase());
            }else {//首字母大写
                builder.append(s1.substring(0, 1).toUpperCase());
                builder.append(s1.substring(1).toLowerCase());
            }
            builder.append(" ");
        }
        return builder.substring(0, builder.length() - 1);
    }

    public static void main(String[] args) {
        CapitalizeTitle capitalizeTitle = new CapitalizeTitle();
        String firstLeTTeROfEachWord = capitalizeTitle.capitalizeTitle("First leTTeR of EACH Word");
        System.out.println(firstLeTTeROfEachWord);
    }
}
