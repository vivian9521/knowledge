package com.leetcode.one.hard;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @Auther:vivian
 * @Description:2581. 统计可能的树根数目
 * Alice 有一棵 n 个节点的树，节点编号为 0 到 n - 1 。树用一个长度为 n - 1 的二维整数数组 edges 表示
 * ，其中 edges[i] = [ai, bi] ，表示树中节点 ai 和 bi 之间有一条边。
 *
 * Alice 想要 Bob 找到这棵树的根。她允许 Bob 对这棵树进行若干次 猜测 。每一次猜测，Bob 做如下事情：
 *
 * 选择两个 不相等 的整数 u 和 v ，且树中必须存在边 [u, v] 。
 * Bob 猜测树中 u 是 v 的 父节点 。
 * Bob 的猜测用二维整数数组 guesses 表示，其中 guesses[j] = [uj, vj] 表示 Bob 猜 uj 是 vj 的父节点。
 *
 * Alice 非常懒，她不想逐个回答 Bob 的猜测，只告诉 Bob 这些猜测里面 至少 有 k 个猜测的结果为 true 。
 *
 * 给你二维整数数组 edges ，Bob 的所有猜测和整数 k ，请你返回可能成为树根的 节点数目 。如果没有这样的树，则返回 0。
 * @Date:Created in 2024/2/29
 * @Modified By:
 * @since DK 1.8
 */
public class RootCount2 {

    /**
     * 换根dp
     * 本题如果只求以0为根时的猜对次数cnto, 把guesses转成哈希表, DFS一次
     * 这棵树就可以算出来。
     * 如果枚举0到n-1的每个点作为树根，就需要DFSn次,要O(n2)的时
     * 间，怎么优化呢?
     * 注意到，如果节点x和节点y相邻,那么从「以x为根的树」誠「以y为
     * 根的树」，就只有x和y的父子关系改变了，期相邻节点的父子关系没有变
     * 化。所以只有[x,y] 和[y, x]这两个猜测的正确性变了，其余猜测的正确性不
     * 变。
     * 因此，在计算出cnto 后,我们可以再次从0出发, DFS这棵树。从节点x递
     * 归到节点y时:
     * ●如果有猜测[x,y],那么猜对次数减一。，
     * ●如果有猜测[y,x], 那么猜对次数加一。
     * DFS的同时，统计猜对次数≥k的节点个数,即为答案。
     * @param edges
     * @param guesses
     * @param k
     * @return
     */
    private List<Integer>[] g;
    private Set<Long> s = new HashSet<>();
    private int k, ans, cnt0;
    public int rootCount(int[][] edges, int[][] guesses, int k) {
        int n = edges.length + 1;
        //每个节点路径列表
        this.k = k;
        g = new ArrayList[n];
        Arrays.setAll(g, x->new ArrayList<>());
        for (int[] edge : edges) {
            int x = edge[0], y = edge[1];
            g[x].add(y);
            g[y].add(x);
        }
        for (int[] guess : guesses) {//转化为hash表
            s.add((long)guess[0] << 32 | guess[1]);// 两个 4 字节 int 压缩成一个 8 字节 long
        }

        dfs(0, -1);
        reroot(0, -1, cnt0);

        return ans;
    }

    private void dfs(int x, int f){
        for (int y : g[x]) {
            if (y != f){
                if (s.contains((long)x << 32 | y)){// 以 0 为根时，猜对了
                    cnt0++;
                }
                dfs(y, x);
            }
        }
    }

    private void reroot(int x, int fa, int cnt){
        if (cnt >= k){
            ans++;
        }
        for (int y : g[x]) {
            if (y != fa){
                int c = cnt;
                if (s.contains((long)x << 32 | y)){//原来是对的，现在错了
                    c--;
                }
                if (s.contains((long)y << 32 | x)){//原来是错的，现在对了
                    c++;
                }
                reroot(y, x, c);
            }
        }
    }

    public static void main(String[] args) {
        RootCount2 rootCount = new RootCount2();
        int i = rootCount.rootCount(new int[][]{{0, 1}, {1, 2}, {1, 3}, {4, 2}}, new int[][]{{1, 3}, {0, 1}, {1, 0}, {2, 4}}, 3);
        System.out.println(i);

    }
}
