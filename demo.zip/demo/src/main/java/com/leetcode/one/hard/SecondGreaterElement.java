package com.leetcode.one.hard;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

/**
 * @Auther:vivian
 * @Description:2454. 下一个更大元素 IV
 * 给你一个下标从 0 开始的非负整数数组 nums 。对于 nums 中每一个整数，你必须找到对应元素的 第二大 整数。
 *
 * 如果 nums[j] 满足以下条件，那么我们称它为 nums[i] 的 第二大 整数：
 *
 * j > i
 * nums[j] > nums[i]
 * 恰好存在 一个 k 满足 i < k < j 且 nums[k] > nums[i] 。
 * 如果不存在 nums[j] ，那么第二大整数为 -1 。
 *
 * 比方说，数组 [1, 2, 4, 3] 中，1 的第二大整数是 4 ，2 的第二大整数是 3 ，3 和 4 的第二大整数是 -1 。
 * 请你返回一个整数数组 answer ，其中 answer[i]是 nums[i] 的第二大整数。
 * @Date:Created in 2023/12/13
 * @Modified By:
 * @since DK 1.8
 */
public class SecondGreaterElement {
    /**
     * 双单调栈
     * @param nums
     * @return
     */
    public int[] secondGreaterElement3(int[] nums) {
        List<Integer> t1 = new ArrayList<>();
        List<Integer> t2 = new ArrayList<>();
        int[] res = new int[nums.length];
        Arrays.fill(res, - 1);
        for (int i = 0; i < nums.length; i++) {
            while (!t2.isEmpty() && nums[t2.get(t2.size() - 1)] < nums[i]){
                res[t2.get(t2.size() - 1)] = nums[i];
                t2.remove(t2.size() - 1);
            }
            int j = t1.size();
            while (j>0 && nums[t1.get(j - 1)] < nums[i]){
               j--;
            }
            //放值进t2,并且清空t1不符合条件数据
            List<Integer> list = t1.subList(j, t1.size());
            t2.addAll(list);
            list.clear();
            //放值进t1
            t1.add(i);
        }
        return res;
    }
    //单调栈和优先队列
    public int[] secondGreaterElement2(int[] nums) {
        //如果当前元素比栈顶元素大，则弹出栈顶元素，并把其放入优先队列里
        //如果当前元素大于优先队列第一个元素，则找到目标值
        //优先队列是为了方便遍历找比当前元素小的目标值
        PriorityQueue<int[]> pq = new PriorityQueue<>(Comparator.comparingInt(o -> o[0]));
        Deque<Integer> stack = new LinkedList<>();
        int[] res = new int[nums.length];
        Arrays.fill(res, - 1);
        for (int i = 0; i < nums.length; i++) {
            while (!pq.isEmpty() && pq.peek()[0] < nums[i]){
                res[pq.peek()[1]] = nums[i];
                pq.poll();
            }
            while (!stack.isEmpty() && nums[stack.peek()] < nums[i]){
                pq.offer(new int[]{nums[stack.peek()], stack.peek()});
                stack.pop();
            }
            stack.push(i);
        }
        return res;
    }
    //超时
    public int[] secondGreaterElement(int[] nums) {
        int[] res = new int[nums.length];
        Arrays.fill(res, -1);
        if (nums.length < 3){
            return res;
        }
        for (int i = 0; i < nums.length; i++) {
            boolean existK = false;
            for (int j = i + 1; j < nums.length; j++) {
                if (nums[j] > nums[i]){
                    if (!existK){
                        existK = true;
                    }else {
                        res[i] = nums[j];
                        break;
                    }
                }
            }
        }
        return res;
    }

    public static void main(String[] args) {
        int[] nums = new int[]{2,4,0,9,6};
        SecondGreaterElement secondGreaterElement = new SecondGreaterElement();
        int[] ints = secondGreaterElement.secondGreaterElement(nums);
        for (int anInt : ints) {
            System.out.println(anInt);
        }
    }
}
