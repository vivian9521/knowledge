package com.leetcode.one.mid;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:216. 组合总和 III
 * 找出所有相加之和为 n 的 k 个数的组合，且满足下列条件：
 *
 * 只使用数字1到9
 * 每个数字 最多使用一次
 * 返回 所有可能的有效组合的列表 。该列表不能包含相同的组合两次，组合可以以任何顺序返回。
 * @Date:Created in 2024/4/22
 * @Modified By:
 * @since DK 1.8
 */
public class CombinationSum3 {

    public List<List<Integer>> combinationSum3(int k, int n) {
        List<List<Integer>> res = new ArrayList<>();
        List<Integer> list = new ArrayList<>();
        backtrack(1, k, n, list, res);
        return res;
    }

    private void backtrack(int index, int k, int tar, List<Integer> list, List<List<Integer>> res){
        if (tar == 0 && list.size() == k){
            res.add(new ArrayList<>(list));
            return;
        }
        int N = 9;
        for (int i = index; i <= N; i++) {
            if (tar - i < 0 || list.size() >= k){
                break;
            }
            list.add(i);
            backtrack(i + 1, k, tar - i, list, res);
            list.remove(list.size() - 1);
        }
    }

    public static void main(String[] args) {
        CombinationSum3 combinationSum3 = new CombinationSum3();
        List<List<Integer>> lists = combinationSum3.combinationSum3(3, 7);
        for (List<Integer> list : lists) {
            System.out.println(list);
        }
    }
}
