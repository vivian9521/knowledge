package com.leetcode.one.hard;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:2009. 使数组连续的最少操作数
 * 给你一个整数数组 nums 。每一次操作中，你可以将 nums 中 任意 一个元素替换成 任意 整数。
 *
 * 如果 nums 满足以下条件，那么它是 连续的 ：
 *
 * nums 中所有元素都是 互不相同 的。
 * nums 中 最大 元素与 最小 元素的差等于 nums.length - 1 。
 * 比方说，nums = [4, 2, 5, 3] 是 连续的 ，但是 nums = [1, 2, 3, 5, 6] 不是连续的 。
 *
 * 请你返回使 nums 连续 的 最少 操作次数。
 * @Date:Created in 2024/4/8
 * @Modified By:
 * @since DK 1.8
 */
public class MinOperations {
    /**
     * 正难则反+滑动窗口
     * 正难则反，考虑最多保留多少个元素不变。
     * 设 a 为 nums排序去重后的数组。把 a[i]画在一条数轴上，本题相当于有一个长度为 n 的滑动窗口，
     * 我们需要计算窗口内最多可以包含多少个数轴上的点。
     *
     * 为了算出窗口内有多少个点，我们需要知道窗口包含的最左边的点在哪，设这个点的位置是 a[left]，则它必须大于等于窗口的左边界，即
     *
     * a[left]≥a[i]−n+1
     * 此时窗口内有 i−left+1个点。
     * @param nums
     * @return
     */
    public int minOperations(int[] nums) {
        int n = nums.length;
        //排序+去重
        Arrays.sort(nums);
        int j = 1;
        for (int i = 1; i < n; i++) {
            if (nums[i] != nums[i - 1]) {
                nums[j++] = nums[i];
            }
        }
        //a[left]≥a[i]−n+1, 最多保留多少个元素不变
        int left = 0;
        int ans = 0;
        for (int i = 0; i < j; i++) {
            while (nums[left] < nums[i] - n + 1){
                left++;
            }
            ans = Math.max(ans, i - left + 1);
        }
        return n - ans;
    }


    public static void main(String[] args) {
        MinOperations minOperations = new MinOperations();
        minOperations.minOperations(new int[]{1,2,2,3});
    }

}
