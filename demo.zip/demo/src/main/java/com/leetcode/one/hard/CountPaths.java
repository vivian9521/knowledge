package com.leetcode.one.hard;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:2867. 统计树中的合法路径数目
 * 给你一棵 n 个节点的无向树，节点编号为 1 到 n 。给你一个整数 n 和一个长度为 n - 1 的二维整数数组 edges
 * ，其中 edges[i] = [ui, vi] 表示节点 ui 和 vi 在树中有一条边。
 *
 * 请你返回树中的 合法路径数目 。
 *
 * 如果在节点 a 到节点 b 之间 恰好有一个 节点的编号是质数，那么我们称路径 (a, b) 是 合法的 。
 *
 * 注意：
 *
 * 路径 (a, b) 指的是一条从节点 a 开始到节点 b 结束的一个节点序列，序列中的节点 互不相同 ，且相邻节点之间在树上有一条边。
 * 路径 (a, b) 和路径 (b, a) 视为 同一条 路径，且只计入答案 一次 。
 * @Date:Created in 2024/2/27
 * @Modified By:
 * @since DK 1.8
 */
public class CountPaths {
    /**
     * 枚举每个质数节点。
     * 从质数的邻居开始DFS,
     * 统计在不经过质数的前提下，能访问到多少个非质数。
     * 如左图，假设质数2的邻居能访问到3, 4, 5个非质数。
     * 4和左边这3个点，两两之间的路径都只包含质数2。
     * 5和左边这3 + 4个点,两两之间的路径都只包含质数2。
     * 根据乘法原理，把4.3+ 5.7加到答案中。
     * 注:只考虑左边是避免重复统计。
     * 最后，从2出发到下面这3+4 +5 = 12个点的路径
     * 也只包含质数2,把12加到答案中。
     * @param n
     * @param edges
     * @return
     */

    private final static int MX = (int)1e5;
    private final static boolean[] np = new boolean[MX + 1];//质数=false


    static {
        np[0] = true;
        np[1] = true;
        for (int i = 2; i * i < MX; i++) {
            if (!np[i]){
                for (int j = i * i; j < MX; j+=i) {
                    np[j] = true;
                }
            }
        }
    }

    public long countPaths(int n, int[][] edges) {
        List<Integer>[] g = new ArrayList[n + 1];
        Arrays.setAll(g, x->new ArrayList<>());
        for (int[] edge : edges) {
            int x = edge[0], y = edge[1];
            g[x].add(y);
            g[y].add(x);
        }

        long ans = 0;
        List<Integer> nodes = new ArrayList<>();
        int[] size = new int[n + 1];
        for (int x = 1; x <= n; x++) {
            if (np[x]){ //跳过非质数
                continue;
            }
            int sum = 0;
            for (int y : g[x]) { //质数x把这棵树分成若干个连通块
                if (!np[y]){ //跳过质数，只计算非质数数量
                    continue;
                }
                if (size[y] == 0){ //尚未计算过
                    nodes.clear();
                    dfs(y, - 1, g, nodes);//遍历y所在连通块，在不经过质数的前提下，统计有多少个非质数
                    for (Integer z : nodes) {
                        size[z] = nodes.size();
                    }
                }
                // 这 size[y] 个非质数与之前遍历到的 sum 个非质数，两两之间的路径只包含质数 x
                ans+= (long) size[y] * sum;
                sum+= size[y];
            }
            ans+= sum;//从x出发的路径

        }
        return ans;
    }

    private void dfs(int x, int fa, List<Integer>[] g, List<Integer> nodes){
        nodes.add(x);
        for (int y : g[x]) {
            if (y != fa && np[y]){
                dfs(y, x, g, nodes);
            }
        }
    }

    public boolean isPrime(int n) {
        if (n < 2) {
            return false;
        }
        boolean[] isPrime = new boolean[n + 1];
        Arrays.fill(isPrime, true);
        isPrime[0] = false;
        isPrime[1] = false;
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (isPrime[i]) {
                for (int j = i * i; j <= n; j += i) {
                    isPrime[j] = false;
                }
            }
        }
        return isPrime[n];
    }

    public static void main(String[] args) {
        CountPaths countPaths = new CountPaths();
        countPaths.isPrime(5);
    }
}
