package com.leetcode.one.mid;

import java.time.Year;
import java.util.Deque;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

/**
 * @Auther:vivian
 * @Description:365. 水壶问题
 * 有两个水壶，容量分别为 jug1Capacity 和 jug2Capacity 升。水的供应是无限的。
 *
 * 确定是否有可能使用这两个壶准确得到 targetCapacity 升。
 *
 * 如果可以得到 targetCapacity 升水，最后请用以上水壶中的一或两个来盛放取得的 targetCapacity 升水。
 *
 * 你可以：
 *
 * 装满任意一个水壶
 * 清空任意一个水壶
 * 从一个水壶向另外一个水壶倒水，直到装满或者倒空
 * @Date:Created in 2024/1/29
 * @Modified By:
 * @since DK 1.8
 */
public class CanMeasureWater {
    /**
     * 首先对题目进行建模。观察题目可知，在任意一个时刻，此问题的状态可以由两个数字决定: X壶
     * 中的水量，以吸Y中的水量。
     * 在任意-个时刻，我们可以且仅可以采取以下几种操作:
     * ●把X壶的水灌进Y壶，直至灌满或倒空;
     * ●把Y壶的水灌进X壶，直至灌满或倒空;
     * ●把X壶灌满;
     * ●把Y壶灌满;
     * ●把X壶倒空;
     * ●把Y壶倒空。
     * 因此，本题可以使用深度优先搜索来解决。搜索中的每一步以
     * remain_ x，remain_ y
     * 作为状态，即表
     * 示X壶和Y中的水量。在每步搜索时， 我们会依次尝试所有的操作，递归地搜索下去。这可能
     * 导致我们陷入无止境的递归，因此我们还需要使用一个哈希结合(HashSet) 存储所有已经搜索过
     * 的
     * remain. x, remain. y状态,保证每个状态至多只被搜索-次。
     * @param x
     * @param y
     * @param z
     * @return
     *
     */
    public boolean canMeasureWater2(int x, int y, int z) {
        Deque<int[]> stack = new LinkedList<int[]>();
        stack.push(new int[]{0, 0});
        Set<Long> seen = new HashSet<Long>();
        while (!stack.isEmpty()) {
            if (seen.contains(hash(stack.peek()))) {
                stack.pop();
                continue;
            }
            seen.add(hash(stack.peek()));

            int[] state = stack.pop();
            int remain_x = state[0], remain_y = state[1];
            if (remain_x == z || remain_y == z || remain_x + remain_y == z) {
                return true;
            }
            // 把 X 壶灌满。
            stack.push(new int[]{x, remain_y});
            // 把 Y 壶灌满。
            stack.push(new int[]{remain_x, y});
            // 把 X 壶倒空。
            stack.push(new int[]{0, remain_y});
            // 把 Y 壶倒空。
            stack.push(new int[]{remain_x, 0});
            // 把 X 壶的水灌进 Y 壶，直至灌满或倒空。
            stack.push(new int[]{remain_x - Math.min(remain_x, y - remain_y), remain_y + Math.min(remain_x, y - remain_y)});
            // 把 Y 壶的水灌进 X 壶，直至灌满或倒空。
            stack.push(new int[]{remain_x + Math.min(remain_y, x - remain_x), remain_y - Math.min(remain_y, x - remain_x)});
        }
        return false;
    }

    public long hash(int[] state) {
        return (long) state[0] * 1000001 + state[1];
    }
    /**
     * 最大公约数,裴蜀定理
     * ax+by=z 有解当且仅当 z 是 x,y的最大公约数的倍数。因此我们只需要找到 x,y的最大公约数并判断 z 是否是它的倍数即可。
     *
     * @param jug1Capacity
     * @param jug2Capacity
     * @param targetCapacity
     * @return
     */
    public boolean canMeasureWater(int jug1Capacity, int jug2Capacity, int targetCapacity) {
        if (jug1Capacity + jug2Capacity < targetCapacity){
            return false;
        }
        if (jug1Capacity == 0 || jug2Capacity == 0){
            return targetCapacity == 0 || jug2Capacity + jug2Capacity == targetCapacity;
        }
        return targetCapacity % gcd(jug1Capacity, jug2Capacity) == 0;
    }

    private int gcd(int x, int y){
        return x % y == 0 ? y : gcd(y,x%y);
    }
}
