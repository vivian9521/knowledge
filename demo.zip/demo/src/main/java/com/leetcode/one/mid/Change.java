package com.leetcode.one.mid;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:518. 零钱兑换 II
 * 给你一个整数数组 coins 表示不同面额的硬币，另给一个整数 amount 表示总金额。
 *
 * 请你计算并返回可以凑成总金额的硬币组合数。如果任何硬币组合都无法凑出总金额，返回 0 。
 *
 * 假设每一种面额的硬币有无限个。
 *
 * 题目数据保证结果符合 32 位带符号整数。
 * @Date:Created in 2024/3/26
 * @Modified By:
 * @since DK 1.8
 */
public class Change {
    private int[][] memo;
    private int[] coins;
    public int change(int[] coins, int amount) {
        this.coins = coins;
        int n = coins.length;
        memo = new int[n][amount + 1];
        for (int[] row : memo) {
            Arrays.fill(row, -1);//-1代表未访问过
        }
        return dfs(n - 1, amount);
    }
    private int dfs(int i, int c){
        if (i < 0){
            if (c == 0){
                return 1;
            }else {
                return 0;
            }
        }
        if (memo[i][c] != -1){
            return memo[i][c];
        }
        if (c < coins[i]){
            return memo[i][c] = dfs(i-1, c);
        }
        memo[i][c] = dfs(i - 1, c) + dfs(i, c- coins[i]) + 1;
        return memo[i][c];
    }

    /**
     * 动态规划
     * @param coins
     * @param amount
     * @return
     */
    public int coinChange2(int[] coins, int amount) {
        int[] dp = new int[amount + 1];
        Arrays.fill(dp, amount + 1);
        dp[0] = 0;
        for (int i = 1; i <= amount; i++) {
            for (int coin : coins) {
                if (i >= coin){
                    dp[i] = Math.min(dp[i], dp[i - coin] + 1);
                }
            }
        }
        return dp[amount] >= amount + 1 ? -1 : dp[amount];
    }
}
