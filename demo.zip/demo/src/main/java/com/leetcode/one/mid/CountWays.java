package com.leetcode.one.mid;

import java.util.Arrays;
import java.util.Comparator;

/**
 * @Auther:vivian
 * @Description:2580. 统计将重叠区间合并成组的方案数
 * 给你一个二维整数数组 ranges ，其中 ranges[i] = [starti, endi]
 * 表示 starti 到 endi 之间（包括二者）的所有整数都包含在第 i 个区间中。
 *
 * 你需要将 ranges 分成 两个 组（可以为空），满足：
 *
 * 每个区间只属于一个组。
 * 两个有 交集 的区间必须在 同一个 组内。
 * 如果两个区间有至少 一个 公共整数，那么这两个区间是 有交集 的。
 *
 * 比方说，区间 [1, 3] 和 [2, 5] 有交集，因为 2 和 3 在两个区间中都被包含。
 * 请你返回将 ranges 划分成两个组的 总方案数 。由于答案可能很大，将它对 109 + 7 取余 后返回。
 * @Date:Created in 2024/3/27
 * @Modified By:
 * @since DK 1.8
 */
public class CountWays {
    /**
     * 合并区间
     * @param ranges
     * @return
     */
    public int countWays(int[][] ranges) {
        int ans = 1;
        //左索引排序
        Arrays.sort(ranges, Comparator.comparingInt(a -> a[0]));
        int m = ranges.length;
        int maxR = 0;
        for (int i = 0; i < m; i++) {
            int l = ranges[i][0], r = ranges[i][1];
            //新区间
            if (l > maxR){
                ans = ans * 2 % 1000000007;
            }
            maxR = Math.max(maxR, r);
        }
        return ans;
    }

}
