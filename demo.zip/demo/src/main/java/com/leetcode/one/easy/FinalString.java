package com.leetcode.one.easy;

import java.time.LocalDateTime;
import java.util.Deque;
import java.util.LinkedList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import static net.sf.jsqlparser.util.validation.metadata.NamedObject.index;

/**
 * @Auther:vivian
 * @Description:2810. 故障键盘
 * 你的笔记本键盘存在故障，每当你在上面输入字符 'i' 时，它会反转你所写的字符串。而输入其他字符则可以正常工作。
 *
 * 给你一个下标从 0 开始的字符串 s ，请你用故障键盘依次输入每个字符。
 *
 * 返回最终笔记本屏幕上输出的字符串。
 * @Date:Created in 2024/4/1
 * @Modified By:
 * @since DK 1.8
 */
public class FinalString {

    public String finalString(String s) {
        StringBuilder builder = new StringBuilder();
        char[] chars = s.toCharArray();
        for (char c : chars) {
            if (c == 'i'){
                builder.reverse();
            }else {
                builder.append(c);
            }
        }
        return builder.toString();
    }

    public String finalString2(String s) {
        //双端队列
        Deque<Character> q = new LinkedList<>();
        boolean tail = true;
        char[] chars = s.toCharArray();
        for (char c : chars) {
            if (c == 'i'){
                tail = !tail;
            }else if (tail){
                q.addLast(c);
            }else if (!tail){
                q.addFirst(c);
            }
        }
        StringBuilder ans = new StringBuilder();
        while (!q.isEmpty()){
            ans.append(q.poll());
        }
        if (!tail){
            return ans.reverse().toString();
        }
        return ans.toString();
    }

    public static void main(String[] args) {
        String s = "poiinter";
        FinalString finalString = new FinalString();
        String s1 = finalString.finalString(s);
        System.out.println(s1);

//        schedule();


    }
    public static void schedule() {
        ScheduledExecutorService executor = Executors.newScheduledThreadPool(1);
        executor.schedule(
                new Runnable() {
                    @Override
                    public void run() {
                        System.out.println(String.format("run schedule @ {%s}", LocalDateTime.now()));
                    }
                },
                1000,
                TimeUnit.MILLISECONDS);
        // waiting to process(sleep to mock)
//            Thread.sleep(10000);

        // stop
        executor.shutdown();
    }
}
