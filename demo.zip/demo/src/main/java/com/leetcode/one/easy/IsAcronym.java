package com.leetcode.one.easy;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:2828. 判别首字母缩略词
 * 给你一个字符串数组 words 和一个字符串 s ，请你判断 s 是不是 words 的 首字母缩略词 。
 *
 * 如果可以按顺序串联 words 中每个字符串的第一个字符形成字符串 s ，则认为 s 是 words 的首字母缩略词。
 * 例如，"ab" 可以由 ["apple", "banana"] 形成，但是无法从 ["bear", "aardvark"] 形成。
 *
 * 如果 s 是 words 的首字母缩略词，返回 true ；否则，返回 false 。
 * @Date:Created in 2023/12/20
 * @Modified By:
 * @since DK 1.8
 */
public class IsAcronym {

    public boolean isAcronym(List<String> words, String s) {
        if (words.size() == 0 || words.size() != s.length()){
            return false;
        }
        for (int i = 0; i < words.size(); i++) {
            String s1 = words.get(i);
            if (s1.charAt(0) != s.charAt(i)){
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        List<String> words = new ArrayList<>();
        words.add("alice");
        words.add("bob");
        words.add("charlie");

        IsAcronym isAcronym = new IsAcronym();
        boolean abc = isAcronym.isAcronym(words, "abc");
        System.out.println(abc);
    }
}
