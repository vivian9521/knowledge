package com.leetcode.one.hard;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:1766. 互质树
 * 给你一个 n 个节点的树（也就是一个无环连通无向图），节点编号从 0 到 n - 1 ，且恰好有 n - 1 条边，每个节点有一个值。树的 根节点 为 0 号点。
 *
 * 给你一个整数数组 nums 和一个二维数组 edges 来表示这棵树。nums[i] 表示第 i 个点的值，edges[j] = [uj, vj] 表示节点 uj 和节点 vj 在树中有一条边。
 *
 * 当 gcd(x, y) == 1 ，我们称两个数 x 和 y 是 互质的 ，其中 gcd(x, y) 是 x 和 y 的 最大公约数 。
 *
 * 从节点 i 到 根 最短路径上的点都是节点 i 的祖先节点。一个节点 不是 它自己的祖先节点。
 *
 * 请你返回一个大小为 n 的数组 ans ，其中 ans[i]是离节点 i 最近的祖先节点且满足 nums[i] 和 nums[ans[i]] 是 互质的 ，如果不存在这样的祖先节点，ans[i] 为 -1 。
 * @Date:Created in 2024/4/11
 * @Modified By:
 * @since DK 1.8
 */
public class GetCoprimes {

    private final int MAX = 51;
    public int[] getCoprimes(int[] nums, int[][] edges) {
        int n = nums.length;
        //设置节点所有方向节点
        List<Integer>[] g = new ArrayList[n];
        Arrays.setAll(g, x->new ArrayList<>());
        for (int[] edge : edges) {
            int x = edge[0];
            int y = edge[1];
            g[x].add(y);
            g[y].add(x);
        }

        //预处理出每个数的所有互质数，记录在数组 f 中，其中 f[i] 表示 i 的所有互质数。
        List<Integer>[] f = new ArrayList[MAX];
        Arrays.setAll(f, x->new ArrayList<>());
        for (int i = 1; i < MAX; i++) {
            for (int j = 1; j < MAX; j++) {
                if (gcd(i, j) == 1){
                    f[i].add(j);
                }
            }
        }
        //这里我们可以用一个长度为 51 的栈数组 stks来获取每个出现过的值 v的节点以及其深度。每个栈 stks[v]的栈顶元素就是最近的深度最大的祖先节点。
        Deque<int[]>[] stks= new Deque[MAX];
        Arrays.setAll(stks, k -> new ArrayDeque<>());
        int[] ans = new int[n];
        ans[0] = -1;
        dfs(0, -1,1, g,f, nums,stks, ans);
        return ans;
    }

    private void dfs(int x, int par, int depth, List<Integer>[] g, List<Integer>[] f, int[] nums, Deque<int[]>[] stks, int[] ans){
        //遍历该节点值的所有质数，求出最大深度
        int node = -1, h = -1;
        for (int value : f[nums[x]]) {
            Deque<int[]> stk = stks[value];
            if (!stk.isEmpty() && stk.peek()[1] > h){
                node = stk.peek()[0];
                h = stk.peek()[1];
            }
        }
        ans[x] = node;

        for (int y : g[x]) {
            if (y != par){
                stks[nums[x]].push(new int[]{x, depth});
                dfs(y, x, depth+1, g, f, nums, stks, ans);
                stks[nums[x]].pop();
            }
        }

    }
    private int gcd(int a, int b){
        return a % b == 0 ? b : gcd(b, a % b);
    }

    private int isgcd(int a, int b, int[] nums, int[] pars){
        if (b < 0){
            return -1;
        }
        if (gcd(nums[a], nums[b]) == 1){
            return b;
        }else {
            return isgcd(a, pars[b], nums, pars);
        }
    }


    public static void main(String[] args) {
        GetCoprimes getCoprimes = new GetCoprimes();
        int[] coprimes = getCoprimes.getCoprimes(new int[]{2, 3, 3, 2}, new int[][]{{0, 1}, {1, 2}, {1, 3}});
        for (int coprime : coprimes) {
            System.out.println(coprime);
        }
    }

}
