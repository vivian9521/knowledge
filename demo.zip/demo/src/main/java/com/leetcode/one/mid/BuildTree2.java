package com.leetcode.one.mid;

import com.leetcode.TreeNode;

import java.util.HashMap;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:106. 从中序与后序遍历序列构造二叉树
 * 给定两个整数数组 inorder 和 postorder ，其中 inorder 是二叉树的中序遍历， postorder 是同一棵树的后序遍历，
 * 请你构造并返回这颗 二叉树 。
 * @Date:Created in 2024/2/21
 * @Modified By:
 * @since DK 1.8
 */
public class BuildTree2 {
    private Map<Integer, Integer> inMap;
    private int[] postorder;
    public TreeNode buildTree(int[] inorder, int[] postorder) {
        this.postorder = postorder;
        inMap = new HashMap<>();
        for (int i = 0; i < inorder.length; i++) {
            inMap.put(inorder[i], i);
        }
        return recur(postorder.length - 1, 0, inorder.length - 1);
    }

    private TreeNode recur(int root, int left, int right){
        if (left > right){
            return null;
        }
        TreeNode treeNode = new TreeNode(postorder[root]);
        Integer index = inMap.get(postorder[root]);
        treeNode.left = recur(root - (right - index) - 1, left, index - 1);
        treeNode.right = recur(root - 1, index + 1, right);

        return treeNode;
    }
}
