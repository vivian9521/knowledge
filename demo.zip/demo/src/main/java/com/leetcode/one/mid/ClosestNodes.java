package com.leetcode.one.mid;

import com.leetcode.TreeNode;
import jdk.nashorn.internal.ir.annotations.Ignore;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:2476. 二叉搜索树最近节点查询
 * 给你一个 二叉搜索树 的根节点 root ，和一个由正整数组成、长度为 n 的数组 queries 。
 *
 * 请你找出一个长度为 n 的 二维 答案数组 answer ，其中 answer[i] = [mini, maxi] ：
 *
 * mini 是树中小于等于 queries[i] 的 最大值 。如果不存在这样的值，则使用 -1 代替。
 * maxi 是树中大于等于 queries[i] 的 最小值 。如果不存在这样的值，则使用 -1 代替。
 * 返回数组 answer 。
 * @Date:Created in 2024/2/26
 * @Modified By:
 * @since DK 1.8
 */
public class ClosestNodes {

    public List<List<Integer>> closestNodes(TreeNode root, List<Integer> queries) {
        //中序遍历
        List<Integer> list = new ArrayList<>();
        dfs(root, list);
        int[] a = new int[list.size()];
        for (int i = 0; i < list.size(); i++) {
            a[i] = list.get(i);
        }
        //二分法
        List<List<Integer>> res = new ArrayList<>();
        int n = a.length;
        for (Integer target : queries) {
            int j = sub(a, target);
            int max = j == n ? -1 : a[j];
            if (j == n || a[j] != target){
                j--;
            }
            int min = j < 0 ? -1 : a[j];
            res.add(Arrays.asList(min, max));
        }
        return res;
    }

    private static int sub(int[] a, Integer target) {
        int left = 0;
        int right = a.length - 1;
        while (left <= right){
            int mid = left + (right - left)/2;
            //查找大于等于query的数
            if (a[mid] < target){
                left = mid + 1;
            }else {
                right = mid - 1;
            }
        }
        return left;
    }

    private void dfs(TreeNode root, List<Integer> list){
        if (root == null){
            return;
        }
        dfs(root.left, list);
        list.add(root.val);
        dfs(root.right, list);
    }

    public static void main(String[] args) {
        ClosestNodes closestNodes = new ClosestNodes();
//        closestNodes.dfs();
    }
}
