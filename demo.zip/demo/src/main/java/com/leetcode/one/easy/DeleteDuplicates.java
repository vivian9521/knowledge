package com.leetcode.one.easy;

import com.leetcode.ListNode;

/**
 * @Auther:vivian
 * @Description:83. 删除排序链表中的重复元素
 * 给定一个已排序的链表的头 head ， 删除所有重复的元素，使每个元素只出现一次 。返回 已排序的链表 。
 * @Date:Created in 2024/1/15
 * @Modified By:
 * @since DK 1.8
 */
public class DeleteDuplicates {

    public ListNode deleteDuplicates(ListNode head) {
        if (head == null){
            return null;
        }
        ListNode cur = head;
        while (cur.next != null){
            if (cur.val == cur.next.val){
                int x = cur.val;
                while (cur.next != null && cur.next.val == x){
                    cur.next = cur.next.next;
                }
            }else {
                cur = cur.next;
            }
        }
        return head;
    }
}
