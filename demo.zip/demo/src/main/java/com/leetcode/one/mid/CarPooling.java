package com.leetcode.one.mid;

/**
 * @Auther:vivian
 * @Description:1094. 拼车
 * 车上最初有 capacity 个空座位。车 只能 向一个方向行驶（也就是说，不允许掉头或改变方向）
 *
 * 给定整数 capacity 和一个数组 trips ,  trip[i] = [numPassengersi, fromi, toi] 表示第 i 次旅行有 numPassengersi 乘客，接他们和放他们的位置分别是 fromi 和 toi 。这些位置是从汽车的初始位置向东的公里数。
 *
 * 当且仅当你可以在所有给定的行程中接送所有乘客时，返回 true，否则请返回 false。
 * 1 <= trips.length <= 1000
 * trips[i].length == 3
 * 1 <= numPassengersi <= 100
 * 0 <= fromi < toi <= 1000
 * 1 <= capacity <= 105
 * @Date:Created in 2023/12/14
 * @Modified By:
 * @since DK 1.8
 */
public class CarPooling {
    /**
     * 差分数组
     * @param trips
     * @param capacity
     * @return
     */
    public boolean carPooling(int[][] trips, int capacity) {
        int[] d = new int[1001];
        for (int[] trip : trips) {
            int num = trip[0],from = trip[1], to = trip[2];
            d[from]+=num;
            d[to]-=num;
        }
        int total = 0;
        for (int num : d) {
            total+=num;
            if (total>capacity){
                return false;
            }
        }
        return true;
    }
}
