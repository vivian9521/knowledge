package com.leetcode.one.easy;

import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Calendar;

/**
 * @Auther:vivian
 * @Description:1185. 一周中的第几天
 * 给你一个日期，请你设计一个算法来判断它是对应一周中的哪一天。
 *
 * 输入为三个整数：day、month 和 year，分别表示日、月、年。
 *
 * 您返回的结果必须是这几个值中的一个 {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"}。
 * @Date:Created in 2024/1/3
 * @Modified By:
 * @since DK 1.8
 */
public class DayOfTheWeek {
    public String dayOfTheWeek2(int day, int month, int year) {
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month-1, day);
        SimpleDateFormat format = new SimpleDateFormat("EEEE");
        return format.format(calendar.getTime());
    }
    public String dayOfTheWeek(int day, int month, int year) {
        String[] week = new String[]{"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};
        LocalDate date = LocalDate.of(year, month, day);
        DayOfWeek dayOfWeek = date.getDayOfWeek();
        return week[dayOfWeek.getValue()-1];
    }

    public static void main(String[] args) {
        DayOfTheWeek dayOfTheWeek = new DayOfTheWeek();
        String s = dayOfTheWeek.dayOfTheWeek2(2011, 6, 5);
        System.out.println(s);
    }
}
