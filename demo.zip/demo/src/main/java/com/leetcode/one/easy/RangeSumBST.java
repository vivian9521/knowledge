package com.leetcode.one.easy;

import com.leetcode.TreeNode;

import java.util.Deque;
import java.util.LinkedList;

/**
 * @Auther:vivian
 * @Description:938. 二叉搜索树的范围和
 * 给定二叉搜索树的根结点 root，返回值位于范围 [low, high] 之间的所有结点的值的和。
 * @Date:Created in 2024/2/26
 * @Modified By:
 * @since DK 1.8
 */
public class RangeSumBST {

    public int rangeSumBST(TreeNode root, int low, int high) {
        if (root == null){
            return 0;
        }
        int res = 0;
        Deque<TreeNode> q = new LinkedList<>();
        q.add(root);
        while (!q.isEmpty()){
            TreeNode node = q.poll();
            if (node.val >= low && node.val <= high){
                res += node.val;
            }
            if (node.left != null){
                q.add(node.left);
            }
            if (node.right != null){
                q.add(node.right);
            }
        }
        return res;
    }
}
