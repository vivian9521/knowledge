package com.leetcode.one.hard;

/**
 * @Auther:vivian
 * @Description:2312. 卖木头块
 * 给你两个整数 m 和 n ，分别表示一块矩形木块的高和宽。同时给你一个二维整数数组 prices
 * ，其中 prices[i] = [hi, wi, pricei] 表示你可以以 pricei 元的价格卖一块高为 hi 宽为 wi 的矩形木块。
 *
 * 每一次操作中，你必须按下述方式之一执行切割操作，以得到两块更小的矩形木块：
 *
 * 沿垂直方向按高度 完全 切割木块，或
 * 沿水平方向按宽度 完全 切割木块
 * 在将一块木块切成若干小木块后，你可以根据 prices 卖木块。你可以卖多块同样尺寸的木块。
 * 你不需要将所有小木块都卖出去。你 不能 旋转切好后木块的高和宽。
 *
 * 请你返回切割一块大小为 m x n 的木块后，能得到的 最多 钱数。
 *
 * 注意你可以切割木块任意次。
 * @Date:Created in 2024/3/15
 * @Modified By:
 * @since DK 1.8
 */
public class SellingWood {
    /**
     * 看示例 1，对于一个高为 3 宽为 5 的木块，第一步一共有 6 种切割方案：
     *
     * 竖着切开，有 4种切法。
     * 横着切开，有 2种切法。
     * 比如横着切开，第一步可以分成一个高为 2 宽为 5 的木块，和一个高为 1 宽为 5 的木块。
     *
     * 这俩都是更小的木块，可以分别处理，接着切割（比如第一个横切，第二个竖切），这意味着我们要处理的问题都是「高为 i 宽为 j的木块」。
     *
     * @param m
     * @param n
     * @param prices
     * @return
     */
    public long sellingWood(int m, int n, int[][] prices) {
        int[][] pr = new int[m + 1][n + 1];
        for (int[] p : prices) {
            pr[p[0]][p[1]] = p[2];
        }
        long[][] f = new long[m + 1][n + 1];
        for (int i = 1; i <= m; i++) {
            for (int j = 1; j <= n; j++) {
                f[i][j] = pr[i][j];
                //竖切
                for (int k = 1; k <= j; k++) {
                    f[i][j] = Math.max(f[i][j], f[i][k] + f[i][j - k]);
                }
                //横切
                for (int k = 1; k <= i; k++) {
                    f[i][j] = Math.max(f[i][j], f[k][j] + f[i - k][j]);
                }
            }
        }
        return f[m][n];
    }
}
