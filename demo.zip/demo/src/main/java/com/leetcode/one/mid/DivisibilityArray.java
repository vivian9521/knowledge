package com.leetcode.one.mid;

/**
 * @Auther:vivian
 * @Description:2575. 找出字符串的可整除数组
 * 给你一个下标从 0 开始的字符串 word ，长度为 n ，由从 0 到 9 的数字组成。另给你一个正整数 m 。
 *
 * word 的 可整除数组 div  是一个长度为 n 的整数数组，并满足：
 *
 * 如果 word[0,...,i] 所表示的 数值 能被 m 整除，div[i] = 1
 * 否则，div[i] = 0
 * 返回 word 的可整除数组。
 * @Date:Created in 2024/3/7
 * @Modified By:
 * @since DK 1.8
 */
public class DivisibilityArray {

    public int[] divisibilityArray(String word, int m) {
        int n = word.length();
        int[] div = new int[n];
        long sum = 0;
        for (int i = 0; i < n; i++) {
            int digit = word.charAt(i)-'0';
            sum = (sum * 10 + digit)%m;
            div[i] = sum == 0 ? 1 : 0;
        }
        return div;
    }

    private int gcd(int a, int b){
        return a % b == 0 ? b : gcd(b, a % b);
    }

    public static void main(String[] args) {
        double a = 91221181269244172125025075166510211202115152121212341281327d;
        DivisibilityArray divisibilityArray = new DivisibilityArray();
        int[] ints = divisibilityArray.divisibilityArray("91221181269244172125025075166510211202115152121212341281327", 21);
        for (int anInt : ints) {
            System.out.println(anInt);
        }
    }
}
