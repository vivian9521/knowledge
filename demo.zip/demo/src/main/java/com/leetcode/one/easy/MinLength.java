package com.leetcode.one.easy;

import java.util.Deque;
import java.util.LinkedList;
import java.util.Stack;

/**
 * @Auther:vivian
 * @Description:2696. 删除子串后的字符串最小长度
 * 给你一个仅由 大写 英文字符组成的字符串 s 。
 *
 * 你可以对此字符串执行一些操作，在每一步操作中，你可以从 s 中删除 任一个 "AB" 或 "CD" 子字符串。
 *
 * 通过执行操作，删除所有 "AB" 和 "CD" 子串，返回可获得的最终字符串的 最小 可能长度。
 *
 * 注意，删除子串后，重新连接出的字符串可能会产生新的 "AB" 或 "CD" 子串。
 * @Date:Created in 2024/1/10
 * @Modified By:
 * @since DK 1.8
 */
public class MinLength {

    public int minLength(String s) {
        Deque<Character> stack = new LinkedList<>();
        stack.push(' ');
        for (int i = 0; i < s.length(); i++) {
            if ((stack.peek() == 'A' && s.charAt(i) == 'B') || (stack.peek() == 'C' && s.charAt(i) == 'D')){
                stack.pop();
            }else {
                stack.push(s.charAt(i));
            }
        }
        return stack.size() - 1;
    }
    public int minLength2(String s) {
        Stack<Character> stack = new Stack<>();
        for (int i = 0; i < s.length(); i++) {
            while (!stack.isEmpty() && stack.size() >= 2 && ((stack.peek() == 'B' && stack.elementAt(stack.size() - 2) == 'A') || (stack.peek() == 'D' && stack.elementAt(stack.size() - 2) == 'C'))){
                stack.pop();
                stack.pop();
            }
            stack.push(s.charAt(i));
        }

        while (!stack.isEmpty() && stack.size() >= 2 && ((stack.peek() == 'B' && stack.elementAt(stack.size() - 2) == 'A') || (stack.peek() == 'D' && stack.elementAt(stack.size() - 2) == 'C'))){
            stack.pop();
            stack.pop();
        }
        return stack.size();
    }

    public static void main(String[] args) {
        MinLength minLength = new MinLength();
        int c = minLength.minLength("ABFCACDB");
        System.out.println(c);

//        Stack<Character> stack = new Stack();
//        stack.push('A');
////        stack.push('B');
////        stack.push('C');
////        stack.push('D');
////        stack.push('E');
//        Character character = stack.elementAt(stack.size() - 2);
//        System.out.println(character);
//        Character peek = stack.peek();
//        System.out.println(peek);
//        Character peek1 = stack.peek();
//        System.out.println(peek1);
    }
}
