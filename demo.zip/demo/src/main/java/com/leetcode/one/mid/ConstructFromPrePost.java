package com.leetcode.one.mid;

import com.leetcode.TreeNode;
import org.antlr.v4.runtime.dfa.DFASerializer;

import java.util.HashMap;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:889. 根据前序和后序遍历构造二叉树
 * 给定两个整数数组，preorder 和 postorder ，其中 preorder 是一个具有 无重复 值的二叉树的前序遍历，
 * postorder 是同一棵树的后序遍历，重构并返回二叉树。
 *
 * 如果存在多个答案，您可以返回其中 任何 一个。
 * @Date:Created in 2024/2/22
 * @Modified By:
 * @since DK 1.8
 */
public class ConstructFromPrePost {
    private Map<Integer, Integer> postMap;
    private int[] preorder;

    public TreeNode constructFromPrePost(int[] preorder, int[] postorder) {
        this.preorder = preorder;
        postMap = new HashMap<>();
        int n = postorder.length;
        for (int i = 0; i < n; i++) {
            postMap.put(postorder[i], i);
        }

        return recur(0, n-1, 0, n-1);

    }

    private TreeNode recur(int preL, int preR, int postL, int postR){
        if (preL > preR){
            return null;
        }
        TreeNode treeNode = new TreeNode(preorder[preL]);
        if (preL == preR){
            return treeNode;
        }
        int leftsize = postMap.get(preorder[preL + 1]) - postL + 1;
        treeNode.left = recur(preL + 1, preL + leftsize, postL, postL + leftsize - 1);
        treeNode.right = recur(preL + leftsize + 1, preR, postL + leftsize, postR - 1);
        return treeNode;
    }
}
