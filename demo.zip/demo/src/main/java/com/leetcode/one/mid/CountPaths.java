package com.leetcode.one.mid;

import cn.hutool.core.lang.Pair;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

/**
 * @Auther:vivian
 * @Description:1976. 到达目的地的方案数
 * 你在一个城市里，城市由 n 个路口组成，路口编号为 0 到 n - 1 ，某些路口之间有 双向 道路。
 * 输入保证你可以从任意路口出发到达其他任意路口，且任意两个路口之间最多有一条路。
 *
 * 给你一个整数 n 和二维整数数组 roads ，其中 roads[i] = [ui, vi, timei]
 * 表示在路口 ui 和 vi 之间有一条需要花费 timei 时间才能通过的道路。你想知道花费 最少时间 从路口 0 出发到达路口 n - 1 的方案数。
 *
 * 请返回花费 最少时间 到达目的地的 路径数目 。由于答案可能很大，将结果对 109 + 7 取余 后返回。
 * @Date:Created in 2024/3/5
 * @Modified By:
 * @since DK 1.8
 */
public class CountPaths {
    /**
     * dijkstra最短路径算法
     * 定义f[i] 示节点0到节点i的最短路个数。
     * 在用dis[x] 更新dis[y] 时:
     * ●如果dis[x]+ g[x][y]< dis[y], 说明从0到x再到y的路径是目前最短
     * 的，所以更新f[y]为f[x]。
     * ●
     * 如果dis[x] + g[x][y]= dis[y], 说明从0到x再到y的路径与之前找到的
     * 路径-样短, 所以把f[y] 增加f[x]。
     * 初始值: f[0]=1, 因为0到0只有一种方案,即原地不动。
     * 答案: f[n- 1]。
     * @param n
     * @param roads
     * @return
     */
    public int countPaths(int n, int[][] roads) {
        List<int[]>[] g = new ArrayList[n];
        Arrays.setAll(g, x-> new ArrayList<>());
        for (int[] road : roads) {
            int x = road[0], y = road[1], d = road[2];
            g[x].add(new int[]{y, d});
            g[y].add(new int[]{x, d});
        }
        //优先队列  索引，距离
        PriorityQueue<Pair<Integer, Long>> queue = new PriorityQueue<>(Comparator.comparingLong(Pair::getValue));
        queue.add(new Pair<>(0, 0L));
        //dist距离数组, 距离
        long[] dist = new long[n];
        Arrays.fill(dist,Long.MAX_VALUE);

        int[] f = new int[n];
        f[0] = 1;
        while (!queue.isEmpty()){
            Pair<Integer, Long> pair = queue.poll();
            int index = pair.getKey();
            long len = pair.getValue();
            if (index == n - 1){
                // 不可能找到比 dis[n-1] 更短，或者一样短的最短路了（注意本题边权都是正数）
                return f[n-1];
            }
            if (len > dist[index]){
                continue;
            }
            for (int[] t2 : g[index]) {
                int y = t2[0], d = t2[1];
                long l = len + d;
                if (y != index && dist[y] > l){
                    f[y] = f[index];
                    dist[y] = l;
                    queue.add(new Pair<>(y, l));
                }else if (y != index && dist[y] == l){
                    f[y] = (int) ((f[index] + f[y])%(Math.pow(10, 9) + 7));
                }
            }
        }
        return f[n-1];
    }

    public static void main(String[] args) {
        CountPaths countPaths = new CountPaths();
        int i = countPaths.countPaths(7, new int[][]{{0, 6, 7}, {0, 1, 2}, {1, 2, 3}, {1, 3, 3}, {6, 3, 3}, {3, 5, 1}, {6, 5, 1}, {2, 5, 1}, {0, 4, 5}, {4, 6, 2}});
        System.out.println(i);
    }
}
