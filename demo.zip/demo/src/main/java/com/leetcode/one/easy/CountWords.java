package com.leetcode.one.easy;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:2085. 统计出现过一次的公共字符串\
 * 给你两个字符串数组 words1 和 words2 ，请你返回在两个字符串数组中 都恰好出现一次 的字符串的数目。
 * @Date:Created in 2024/1/12
 * @Modified By:
 * @since DK 1.8
 */
public class CountWords {
    public int countWords2(String[] words1, String[] words2) {
        int ans = 0;
        Map<String, Integer> map1 = new HashMap<>();
        for (String s : words1) {
            map1.put(s, map1.getOrDefault(s, 0) + 1);
        }
        Map<String, Integer> map2 = new HashMap<>();
        for (String s : words2) {
            map2.put(s, map2.getOrDefault(s, 0) + 1);
        }

        for (String key1 : map1.keySet()) {
            if (map1.get(key1) == 1 && map2.getOrDefault(key1, 0) == 1){
                ans ++;
            }
        }
        return ans;
    }

    public int countWords(String[] words1, String[] words2) {
        int ans = 0;
        Map<String, Integer> map = new HashMap<>();
        for (String s : words1) {
            map.put(s, map.getOrDefault(s, 0) + 1);
        }
        Iterator<Map.Entry<String, Integer>> iterator = map.entrySet().iterator();
        while (iterator.hasNext()){
            Map.Entry<String, Integer> entry = iterator.next();
            if (map.get(entry.getKey()) > 1){
                iterator.remove();
            }
        }
        for (String s : words2) {
            if (!map.containsKey(s)){
                continue;
            }
            map.put(s, map.getOrDefault(s, 0) + 1);
        }
        for (Integer value : map.values()) {
            if (value == 2){
                ans++;
            }
        }
        return ans;
    }

}
