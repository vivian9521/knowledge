package com.leetcode.one.hard;

/**
 * @Auther:vivian
 * @Description:410. 分割数组的最大值
 * 给定一个非负整数数组 nums 和一个整数 k ，你需要将这个数组分成 k 个非空的连续子数组。
 *
 * 设计一个算法使得这 k 个子数组各自和的最大值最小。
 * @Date:Created in 2024/1/22
 * @Modified By:
 * @since DK 1.8
 */
public class SplitArray {
    /**
     * 二分法
     * 挖掘单调性：使用二分查找的一个前提是「数组具有单调性」，我们就去想想有没有单调性可以挖掘，不难发现：
     *
     * 如果设置「数组各自和的最大值」很大，那么必然导致分割数很小；
     * 如果设置「数组各自和的最大值」很小，那么必然导致分割数很大。
     * @param nums
     * @param k
     * @return
     */
    public int splitArray(int[] nums, int k) {
        int sum = 0, max = 0;
        // 计算「子数组各自的和的最大值」的上下界
        for (int num : nums) {
            sum += num;
            max = Math.max(max, num);
        }
        // "最大的子数组和"用maxSubArraySum表示，它的取值范围是[max_nums, sum_nums]
        // 当nums分割成len(nums)个子数组时，maxSubArraySum == max_nums
        // 当nums分割成1个子数组时，maxSubArraySum == sum_nums
        // 使用「二分查找」确定一个恰当的「子数组各自的和的最大值」，
        // 使得它对应的「子数组的分割数」恰好等于 m
        int left = max;
        int right = sum;
        while (left < right){
            int mid = left + (right - left)/2;
            int splits = split(nums, mid);
            if (splits > k){
                // 如果分割数太多，说明「子数组各自的和的最大值」太小，此时需要将「子数组各自的和的最大值」调大
                // 下一轮搜索的区间是 [mid + 1, right]
                left = mid + 1;
            }else {
                // 下一轮搜索的区间是上一轮的反面区间 [left, mid]
                right = mid;
            }
        }

        return left;
    }

    /**
     * 获取切割数
     * @param nums
     * @param mid
     * @return
     */
    private int split(int[] nums, int maxIntervalSum) {
        // 当前区间的和
        int curNum = 0;
        // 至少是一个分割
        int split = 1;
        for (int num : nums) {
            // 尝试加上当前遍历的这个数，如果加上去超过了「子数组各自的和的最大值」，就不加这个数，另起炉灶
            if (num + curNum > maxIntervalSum){
                curNum = 0;
                split++;
            }
            curNum += num;
        }
        return split;
    }
}
