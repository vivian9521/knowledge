package com.leetcode.one.mid;

/**
 * @Auther:vivian
 * @Description:1017. 负二进制转换
 * 给你一个整数 n ，以二进制字符串的形式返回该整数的 负二进制（base -2）表示。
 *
 * 注意，除非字符串就是 "0"，否则返回的字符串中不能含有前导零。
 * @Date:Created in 2024/4/28
 * @Modified By:
 * @since DK 1.8
 */
public class BaseNeg2 {
    /**
     * // 【十进制转x进制】：--------------------------------------------------------------------------------
     * //  本质：
     * //      n = a * (x)^5 + b * (x)^4 + c * (x)^3 + d * (x)^2 + e * (x)^1 + f * (x)^0
     * //      求 n 的 x 进制表示，本质上就是得到这里的系数 abcdef
     * //  对于一个数字 n 的 x 进制的表达式 abcdef 来说，更本质的x进制求法应该为：
     * //      1.  得到最低位的值f；
     * //          a.  对于二/负二进制来说，判断奇偶性即可判断f是1还是0  （除了最低位以外，其余位的权重都是偶数）
     * //          b.  对于其它进制来说，
     * //                  i.  若x为正数，则 f = n % x；
     * //                  ii. 但若x为负数，则这里还是需要针对不同语言的除法特性去分析，可能需要在 n % x 的基础上再进行一些运算操作得到 f
     * //      2.  先让 n -= f， 再让 n /= x ：
     * //          实际上是 先将n的最低位抹为0，之后再向右移一位， 最后 n = abcde（x进制表示）
     * //          （n -= f 是为了使得之后的 n /= x 是整除，避开不同语言在无法整除时存在向上向下取整的区别）
     * //  （由于该方法在进行 /= 运算时已经保证了是整除，因此对于任何语言都适用）
     *
     * @param n
     * @return
     */
    public String baseNeg2(int n) {
        if (n == 0 || n == 1){
            return String.valueOf(n);
        }
        StringBuilder builder = new StringBuilder();
        while (n != 0){
            int remain = n & 1;
            builder.append(remain);
            n -= remain;
            n /= -2;
        }
        return builder.reverse().toString();
    }

    public static void main(String[] args) {
        BaseNeg2 baseNeg2 = new BaseNeg2();
        String s = baseNeg2.baseNeg2(3);
        System.out.println(s);
    }
}
