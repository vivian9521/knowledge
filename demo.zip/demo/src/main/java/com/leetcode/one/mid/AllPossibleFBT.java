package com.leetcode.one.mid;

import com.leetcode.TreeNode;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:894. 所有可能的真二叉树
 * 给你一个整数 n ，请你找出所有可能含 n 个节点的 真二叉树 ，并以列表形式返回。答案中每棵树的每个节点都必须符合 Node.val == 0 。
 *
 * 答案的每个元素都是一棵真二叉树的根节点。你可以按 任意顺序 返回最终的真二叉树列表。
 *
 * 真二叉树 是一类二叉树，树中每个节点恰好有 0 或 2 个子节点。
 * @Date:Created in 2024/4/2
 * @Modified By:
 * @since DK 1.8
 */
public class AllPossibleFBT {
    /**
     * 分治法
     * @param n
     * @return
     */
    public List<TreeNode> allPossibleFBT(int n) {
        List<TreeNode> fullList = new ArrayList<>();
        if (n % 2 == 0){
            return fullList;
        }
        //从底至上(1,n-2)、（3，n-4）、（5，n-6）、（i,n-i-1）
        if (n == 1){
            fullList.add(new TreeNode(0));
            return fullList;
        }
        for (int i = 1; i < n; i+=2) {
            List<TreeNode> leftList = allPossibleFBT(i);
            List<TreeNode> rightList = allPossibleFBT(n - i - 1);
            for (TreeNode left : leftList) {
                for (TreeNode right : rightList) {
                    TreeNode treeNode = new TreeNode(0, left, right);
                    fullList.add(treeNode);
                }
            }
        }
        return fullList;
    }


    public static void main(String[] args) {
        AllPossibleFBT allPossibleFBT = new AllPossibleFBT();
        List<TreeNode> treeNodes = allPossibleFBT.allPossibleFBT(3);
        System.out.println(treeNodes.size());
//
//        // 本地文件
//        File localFile = new File(uploadPath + File.separator + file.getOriginalFilename());
//        MultipartFile file ;
//        // transfer to local
//        file.transferTo(localFile);

    }
}
