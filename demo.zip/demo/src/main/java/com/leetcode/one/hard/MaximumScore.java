package com.leetcode.one.hard;

import com.sun.jmx.remote.internal.ArrayQueue;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

/**
 * @Auther:vivian
 * @Description:1793. 好子数组的最大分数
 * 给你一个整数数组 nums （下标从 0 开始）和一个整数 k 。
 *
 * 一个子数组 (i, j) 的 分数 定义为 min(nums[i], nums[i+1], ..., nums[j]) * (j - i + 1) 。
 * 一个 好 子数组的两个端点下标需要满足 i <= k <= j 。
 *
 * 请你返回 好 子数组的最大可能 分数 。
 * @Date:Created in 2024/3/20
 * @Modified By:
 * @since DK 1.8
 */
public class MaximumScore {
    /**
     * 单调栈求最大矩形面积
     * 假设h = nums[p]是矩形的高度,那么矩形的宽度是多少?我们需要知道:
     * ●在p左侧的小于h的最近元素的下标left
     * ●在p右侧的小于h的最近元素的下标right
     * @param nums
     * @param k
     * @return
     */
    public int maximumScore(int[] nums, int k) {
        int n = nums.length;
        //左侧索引
        int[] left = new int[n];
        Deque<Integer> stack = new ArrayDeque<>();
        for (int i = 0; i < n; i++) {
            int x = nums[i];
            //把大于当前高度的，全部弹出，用来获取比当前高度矮且离当前高度最近的索引
            while (!stack.isEmpty() && x <= nums[stack.peek()]){
                stack.pop();
            }
            left[i] = stack.isEmpty() ? -1 : stack.peek();
            stack.push(i);
        }
        //右侧索引
        stack.clear();
        int[] right = new int[n];
        for (int i = n - 1; i >= 0; i--) {
            int x = nums[i];
            //把大于当前高度的，全部弹出，用来获取比当前高度矮且离当前高度最近的索引
            while (!stack.isEmpty() && x <= nums[stack.peek()]){
                stack.pop();
            }
            right[i] = stack.isEmpty() ? n : stack.peek();
            stack.push(i);
        }

        int ans = 0;
        for (int i = 0; i < n; i++) {
            int h = nums[i];
            int l = left[i];
            int r = right[i];
            if (l < k && k < r){
                ans = Math.max(ans, h * (r-l-1));
            }
        }
        return ans;
    }
}
