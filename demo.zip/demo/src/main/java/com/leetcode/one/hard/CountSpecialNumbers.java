package com.leetcode.one.hard;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:2376. 统计特殊整数
 * 如果一个正整数每一个数位都是 互不相同 的，我们称它是 特殊整数 。
 *
 * 给你一个 正 整数 n ，请你返回区间 [1, n] 之间特殊整数的数目。
 * @Date:Created in 2024/1/17
 * @Modified By:
 * @since DK 1.8
 */
public class CountSpecialNumbers {
    char[] s;
    int[][] memo;
    public int countSpecialNumbers(int n) {
        s = String.valueOf(n).toCharArray();
        int m = s.length;

        memo = new int[m][1<<10];
        for (int i = 0; i < m; i++) {
            Arrays.fill(memo[i], -1);//-1代表没有计算过
        }
        return f(0, 0, true, false);
    }

    private int f(int i, int mask, boolean isLimit, boolean isNum){
        if (i == s.length){
            return isNum ? 1 : 0; //isNum=true代表得到一个合法数字
        }
        if (!isLimit && isNum && memo[i][mask] != -1){
            return memo[i][mask];
        }
        int res = 0;
        if (!isNum){
            res = f(i + 1, mask, false, false);//跳过当前数位
        }
        int up = isLimit ? s[i] - '0' : 9;// 如果前面填的数字都和 n 的一样，那么这一位至多填数字 s[i]（否则就超过 n 啦）
        for (int d = isNum ? 0 : 1; d <= up; d++) {
            if (((mask >> d)&1) ==0){ //d不在mask中
                res+= f(i + 1, mask | (1<<d), isLimit && d == up, true);
            }
        }
        if (!isLimit && isNum){
            memo[i][mask] = res;
        }
        return res;
    }

    public static void main(String[] args) {
        CountSpecialNumbers countSpecialNumbers = new CountSpecialNumbers();
        int i = countSpecialNumbers.countSpecialNumbers(12);
        System.out.println(i);
    }
}
