package com.leetcode.one.easy;

/**
 * @Auther:vivian
 * @Description:2529. 正整数和负整数的最大计数
 * 给你一个按 非递减顺序 排列的数组 nums ，返回正整数数目和负整数数目中的最大值。
 *
 * 换句话讲，如果 nums 中正整数的数目是 pos ，而负整数的数目是 neg ，返回 pos 和 neg二者中的最大值。
 * 注意：0 既不是正整数也不是负整数。
 * @Date:Created in 2024/4/9
 * @Modified By:
 * @since DK 1.8
 */
public class MaximumCount {
    //1 -2 3 4
    public int maximumCount(int[] nums) {
        int n = nums.length;
        int pos = 0, neg = n - 1;
        int pn = 0, nn = 0;
        if (nums[pos] > 0 || nums[neg] < 0){
            return n;
        }
        while (nums[pos] < 0 || nums[neg] > 0){
            if (nums[pos] < 0){
                pos++;
                pn++;
            }
            if (nums[neg] > 0){
                neg--;
                nn++;
            }
        }
        return Math.max(pn, nn);

    }

    public static void main(String[] args) {
        MaximumCount maximumCount = new MaximumCount();
        int i = maximumCount.maximumCount(new int[]{-1563,-236,-114,-55,427,447,687,752,1021,1636});
        System.out.println(i);
    }
}
