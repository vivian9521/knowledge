package com.leetcode.one.mid;

import com.leetcode.ListNode;

/**
 * @Auther:vivian
 * @Description:82. 删除排序链表中的重复元素 II
 * 给定一个已排序的链表的头 head ， 删除原始链表中所有重复数字的节点，只留下不同的数字 。返回 已排序的链表 。
 * @Date:Created in 2024/1/15
 * @Modified By:
 * @since DK 1.8
 */
public class DeleteDuplicates2 {

    private  volatile  int a;

    public ListNode deleteDuplicates2(ListNode head) {
        if (head == null){
            return null;
        }
        ListNode dumpy = new ListNode(0, head);
        ListNode cur = dumpy;
        while (cur.next != null && cur.next.next != null){
            if (cur.next.val == cur.next.next.val){
                int x = cur.next.val;
                while (cur.next != null && cur.next.val == x){
                    cur.next = cur.next.next;
                }
            }else {
                cur = cur.next;
            }
        }
        return dumpy.next;
    }

    public ListNode deleteDuplicates(ListNode head) {
        int[] vals = new int[200];
        ListNode cur = head;
        while (cur != null){
            vals[cur.val+100]++;
            cur = cur.next;
        }
        ListNode res = new ListNode(0);
        cur = res;
        for (int i = 0; i < vals.length; i++) {
            if (vals[i] == 1){
                cur.next = new ListNode(i-100);
                cur = cur.next;
            }
        }
        return res.next;
    }

    public static void main(String[] args) {
        DeleteDuplicates2 deleteDuplicates2 = new DeleteDuplicates2();
        deleteDuplicates2.deleteDuplicates(new ListNode(1, new ListNode(1)));
    }
}
