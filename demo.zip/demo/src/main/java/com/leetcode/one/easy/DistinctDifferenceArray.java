package com.leetcode.one.easy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @Auther:vivian
 * @Description:2670. 找出不同元素数目差数组
 * 给你一个下标从 0 开始的数组 nums ，数组长度为 n 。
 * nums 的 不同元素数目差 数组可以用一个长度为 n 的数组 diff 表示，
 * 其中 diff[i] 等于前缀 nums[0, ..., i] 中不同元素的数目 减去 后缀 nums[i + 1, ..., n - 1] 中不同元素的数目。
 * 返回 nums 的 不同元素数目差 数组。
 * 注意 nums[i, ..., j] 表示 nums 的一个从下标 i 开始到下标 j 结束的子数组（包含下标 i 和 j 对应元素）。
 * 特别需要说明的是，如果 i > j ，则 nums[i, ..., j] 表示一个空子数组
 * @Date:Created in 2024/1/31
 * @Modified By:
 * @since DK 1.8
 */
public class DistinctDifferenceArray {
    public int[] distinctDifferenceArray2(int[] nums) {
        int n = nums.length;
        int[] diff = new int[n];

        Set<Integer> set = new HashSet<>();
        int[] suffix = new int[n + 1];
        for (int i = n - 1; i >= 0; i--) {
            set.add(nums[i]);
            suffix[i] = set.size();
        }
        set.clear();
        for (int i = 0; i < n; i++) {
            set.add(nums[i]);
            diff[i] = set.size() - suffix[i + 1];
        }
        return diff;
    }

    public int[] distinctDifferenceArray(int[] nums) {
        int n = nums.length;
        int[] diff = new int[n];
        Map<Integer, List> map = new HashMap<>();
        for (int i = 0; i < n; i++) {
            map.computeIfAbsent(nums[i], k -> new ArrayList()).add(i);
        }
        int[] prefix = new int[n];
        prefix[0] = 1;
        for (int i = 1; i < n; i++) {
            List<Integer> list = map.get(nums[i]);
            int index = list.indexOf(i);
            prefix[i] = prefix[i-1] + (index == 0 ? 1 : 0);
        }
        int[] suffix = new int[n + 1];
        suffix[n-1] = 1;
        for (int i = n - 2; i >= 0; i--) {
            List<Integer> list = map.get(nums[i]);
            int index = list.indexOf(i);
            suffix[i] = suffix[i+1] + (index == list.size() - 1 ? 1 : 0);
        }

        for (int i = 0; i < n; i++) {
            diff[i] = prefix[i] - suffix[i + 1];
        }
        return diff;
    }

    public static void main(String[] args) {
        DistinctDifferenceArray distinctDifferenceArray = new DistinctDifferenceArray();
        int[] ints = distinctDifferenceArray.distinctDifferenceArray(new int[]{3,2,3,4,2});
        for (int anInt : ints) {
            System.out.println(anInt);
        }
    }
}
