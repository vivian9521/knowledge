package com.leetcode.one.easy;

import com.leetcode.TreeNode;

import java.util.LinkedList;
import java.util.Queue;

/**
 * @Auther:vivian
 * @Description:1379. 找出克隆二叉树中的相同节点
 * 给你两棵二叉树，原始树 original 和克隆树 cloned，以及一个位于原始树 original 中的目标节点 target。
 *
 * 其中，克隆树 cloned 是原始树 original 的一个 副本 。
 *
 * 请找出在树 cloned 中，与 target 相同 的节点，并返回对该节点的引用（在 C/C++ 等有指针的语言中返回 节点指针，其他语言返回节点本身）。
 *
 *
 *
 * 注意：你 不能 对两棵二叉树，以及 target 节点进行更改。只能 返回对克隆树 cloned 中已有的节点的引用。
 * @Date:Created in 2024/4/3
 * @Modified By:
 * @since DK 1.8
 */
public class GetTargetCopy {

    public final TreeNode getTargetCopy(final TreeNode original, final TreeNode cloned, final TreeNode target) {
        if (original == null || original == target){
            return cloned;
        }
        TreeNode leftClone = getTargetCopy(original.left, cloned.left, target);
        if (leftClone != null){ //找到target
            return leftClone;
        }
        return getTargetCopy(original.right, cloned.right, target);
    }

//    private TreeNode res;
//    public final TreeNode getTargetCopy2(final TreeNode original, final TreeNode cloned, final TreeNode target) {
//        dfs(original, cloned, target);
//        return res;
//    }
//
//    private void dfs(final TreeNode original, final TreeNode cloned, final TreeNode target){
//        if (original == null){
//            return;
//        }
//        if (original == target){
//            res = cloned;
//            return;
//        }
//        dfs(original.left, cloned.left, target);
//        dfs(original.right, cloned.right, target);
//    }

    public final TreeNode getTargetCopy2(final TreeNode original, final TreeNode cloned, final TreeNode target) {
        if (target == original){
            return cloned;
        }
        Queue<TreeNode>  oq = new LinkedList<>();
        Queue<TreeNode> cq = new LinkedList<>();
        oq.add(original);
        cq.add(cloned);

        while (!oq.isEmpty()){
            TreeNode on = oq.poll();
            TreeNode cn = cq.poll();
            if (on.left != null){
                if (on.left == target){
                    return cn.left;
                }
                oq.add(on.left);
                cq.add(cn.left);
            }
            if (on.right != null){
                if (on.right == target){
                    return cn.right;
                }
                oq.add(on.right);
                cq.add(cn.right);
            }
        }
        return null;
    }
}
