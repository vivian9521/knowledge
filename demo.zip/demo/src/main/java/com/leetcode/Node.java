package com.leetcode;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/9/6
 * @Modified By:
 * @since DK 1.8
 */
public class Node {
    public int val;
    public Node next;
    public Node random;

    public Node(int val) {
        this.val = val;
        this.next = null;
        this.random = null;
    }
}
