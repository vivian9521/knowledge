package com.leetcode.easy;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/29
 * @Modified By:
 * @since DK 1.8
 */
public class ClimbStairs {

    public static void main(String[] args) {
//爬楼梯
        System.out.println(climbStairs(44));
        System.out.println(climbStairs2(44));
    }
    public static int climbStairs2(int n) {
        int[] arr = new int[n + 1];
        arr[1] = 1;
        arr[2] = 2;
        for (int i = 3; i <= n; i++) {
            arr[i] = arr[i-1] + arr[i-2];
        }
        return arr[n];
    }

    //假设你正在爬楼梯。需要 n 阶你才能到达楼顶。
    //每次你可以爬 1 或 2 个台阶。你有多少种不同的方法可以爬到楼顶呢？
    public static int climbStairs(int n) {
        //递归算法 f(n)=f(n-1)+f(n-2)
        //缺点，太耗时
        /*if (n==1){
            return 1;
        }
        else if (n==2){
            return 2;
        }
        else {
            return climbStairs(n-1)+climbStairs(n-2);
        }*/
        //动态规划
        //f(1)=1 f(2)=2 f(3)=3=f(1)+f(2) f(4)=f(2)+f(3)...
        //  q       p       r
        //          q       p               r
        int p=0; int q; int r=1;
        for (int i = 1; i <=n; i++) {
            q=p;
            p=r;
            r=p+q;
        }
        return r;
    }

}
