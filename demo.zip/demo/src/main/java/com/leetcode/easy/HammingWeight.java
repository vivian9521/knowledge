package com.leetcode.easy;

import java.util.LinkedList;

/**
 * @Auther:vivian
 * @Description:LCR 133. 位 1 的个数
 * 编写一个函数，输入是一个无符号整数（以二进制串的形式），
 * 返回其二进制表达式中数字位数为 '1' 的个数（也被称为 汉明重量).）。
 * @Date:Created in 2023/10/16
 * @Modified By:
 * @since DK 1.8
 */
public class HammingWeight {
    /**
     * 逐位判断
     * @param n
     * @return
     */
    public int hammingWeight2(int n) {
        int res = 0;
        while (n != 0){
            res += n & 1;
            n >>>= 1;
        }
        return res;
    }
    /**
     * 方法二：巧用 n&(n−1)
     * (n−1) 解析： 二进制数字 n最右边的 1 变成 00，此 1 右边的 0 都变成 1 。
     * n&(n−1) 解析： 二进制数字 n最右边的 1 变成 0 ，其余不变。
     * @param n
     * @return
     */
    public int hammingWeight3(int n) {
        int res = 0;
        while (n != 0){
            res++;
            n &= (n-1);
        }
        return res;
    }

    public int hammingWeight(int n) {
        String s = Integer.toBinaryString(n);
        int res = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == '1'){
                res += 1;
            }
        }
        return res;
    }

    public static void main(String[] args) {
        HammingWeight hammingWeight = new HammingWeight();
        int i = hammingWeight.hammingWeight2(11);

        System.out.println(i);

    }
}
