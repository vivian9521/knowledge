package com.leetcode.easy;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/9/22
 * @Modified By:
 * @since DK 1.8
 */
public class MinValue {
    public static void main(String[] args) {
        int[] a = {-5, -3, -2, -1, 4, 7};
        System.out.println(solution(a));
        System.out.println(get(a));
    }
    public static int solution(int[] nums) {
        if (nums == null || nums.length == 0) {
            throw new IllegalArgumentException();
        }
        int l = 0;
        int r = nums.length - 1;
        while (l < r) {
            int mid = l + ((r - l) >> 1);
            if (nums[mid] == 0) {
                return nums[mid];
            } else if (nums[mid] > 0) {
                r = mid;
            } else {
                l = mid + 1;
            }
        }
        return l == 0 || Math.abs(nums[l]) <= Math.abs(nums[l-1]) ? nums[l] : nums[l-1];
    }
    /**
     * 有一个已经排好序的整数序列（升序，无重复项），序列中可能有正整数、负整数或者 0，请用你认为
     * 最优的方法求序列中绝对值最小的数。要求不能使用顺序比较的方法（时间复杂度需要小于 O(n)），
     * 不能使用内置查找函数，可以用任何语言实现。
     * 输入：一个有序的整数序列。
     * 输出：绝对值最小的数。
     * @return
     */
    private static int get(int[] nums){
        //二分法
        int L = 0;
        int R = nums.length - 1;
        //使其一直逼近0
        while (L < R){
            int mid = (L + R)/2;
            if (nums[mid] == 0){
                return 0;
            }
            if (nums[mid] > 0){
                R = mid;
            }else {
                L = mid + 1;
            }
        }
        return L == 0 || Math.abs(nums[L-1]) > Math.abs(nums[L]) ? nums[L] : nums[L-1];
    }
}
