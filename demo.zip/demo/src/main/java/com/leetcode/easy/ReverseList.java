package com.leetcode.easy;

import com.leetcode.ListNode;

import java.awt.*;
import java.util.List;
import java.util.Stack;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/8/2
 * @Modified By:
 * @since DK 1.8
 */
public class ReverseList {
    public static void main(String[] args) {
        ListNode head = new ListNode(1, new ListNode(2,new ListNode(3,new ListNode(4,new ListNode(5)))));
        ListNode listNode = reverseList(head);
        ListNode.foreachListNode(listNode);
//        ListNode listNode2 = reverse2(head);
//        ListNode.foreachListNode(listNode2);


    }

    public static ListNode res3(ListNode head){
        if (head == null){
            return head;
        }
        ListNode cur = head;
        ListNode res = null;

        while (cur != null){
            ListNode temp = cur.next;

            cur.next = res;
            res = cur;
            cur= temp;
        }

        return res;
    }

    public static  ListNode reverse2(ListNode head){
        if (head == null){
            return head;
        }
        ListNode cur = head;
        ListNode rs = null;
        // 1 2 3 4
        // 2 1
        //假设链表为 1 2  3  1→2→3→∅，我们想要把它改成 1  2 3   ∅←1←2←3。
        //在遍历链表时，将当前节点的 next 指针改为指向前一个节点。
        // 由于节点没有引用其前一个节点，因此必须事先存储其前一个节点。在更改引用之前，
        // 还需要存储后一个节点。最后返回新的头引用。
        while (cur != null){
            ListNode temp = cur.next;
            cur.next = rs;
            rs = cur;
            cur = temp;
        }
        // 1 2 3 4
        // cur 1 null
        // rs   1 null
        // cur 2 3 4

        // cur 2 1
        // rs 2 1
        // cur 3 4
//        ListNode rs = null;
//        ListNode cur = head;
//        while (cur != null){
//            ListNode temp = cur.next;
//            cur.next = rs;
//            rs = cur;
//            cur = temp;
//        }
        return rs;
    }

    /**
     * 给你单链表的头节点 head ，请你反转链表，并返回反转后的链表。
     * @param head
     * @return
     */
    public static ListNode reverseList(ListNode head) {
        if (head == null){
            return null;
        }
        ListNode res = null;
        ListNode cur = head;

        while (cur != null){
            ListNode temp = cur.next;
            cur.next = res;
            res = cur;
            cur = temp;
        }
        return res;








        /*ListNode cur = head;
        ListNode res = null;
        ListNode r1 = null;
        Stack<Integer> stack = new Stack<>();
        while (cur != null){
            stack.push(cur.val);
            cur = cur.next;
        }
        while (head != null){
            Integer pop = stack.pop();
            if (res == null){
                res = new ListNode(pop);
                r1 = res;
            }else {
                res.next = new ListNode(pop);
                res = res.next;
            }
            head = head.next;
        }
        return r1;*/
//        ListNode p = null;
//        ListNode q = head;
//        while (q != null){
//            ListNode temp = q.next;
//            q.next = p;
//            p = q;
//            q = temp;
//        }
//        return p;
//方法一：递归
//        if (head == null || head.next == null) {
//            return head;
//        }
//        // 想象递归已经层层返回，到了最后一步
//        // 以链表 1->2->3->4->5 为例，现在链表变成了 5->4->3->2->null，1->2->null（是一个链表，不是两个链表）
//        // 此时 newHead是5，head是1
//        ListNode newHead = reverseList(head.next);
//        // 最后的操作是把链表 1->2->null 变成 2->1->null
//        // head是1，head.next是2，head.next.next = head 就是2指向1，此时链表为 2->1->2
//        head.next.next = head;
//        // 防止链表循环，1指向null，此时链表为 2->1->null，整个链表为 5->4->3->2->1->null
//        head.next = null;
//        return newHead;


//方法三
//        ListNode ans = null;
//        for (ListNode x = head; x != null; x = x.next) {
//            ans = new ListNode(x.val,ans);
//        }
//        return ans;
    }
}
