package com.leetcode.easy;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/29
 * @Modified By:
 * @since DK 1.8
 */
public class Transpose {
    public static void main(String[] args) {
        //转置矩阵
        int[][] b={{1,2,3},{4,5,6},{7,8,9},{8,9,0}};
        int[][] transpose =transpose(b);
    }
    //转置矩阵
    //给你一个二维整数数组 matrix， 返回 matrix 的 转置矩阵 。
    //矩阵的 转置 是指将矩阵的主对角线翻转，交换矩阵的行索引与列索引。
    //输入：matrix = [[1,2,3],[4,5,6],[7,8,9]]
    //输出：[[1,4,7],[2,5,8],[3,6,9]]
    //输入：matrix = [[1,2,3],[4,5,6]]
    //输出：[[1,4],[2,5],[3,6]]
    public static int[][] transpose(int[][] matrix) {
        //外面数组长度
        int outLen = matrix.length;
        //里面长度
        int inLen = matrix[0].length;
        //结果数据
        int[][] result=new int[inLen][outLen];
        for (int i=0;i<inLen;i++){
            int[] newArr=new int[outLen];
            for (int j = 0; j < outLen; j++) {
                newArr[j]=matrix[j][i];
            }
            result[i]=newArr;
        }
        return result;

//        int m = matrix.length, n = matrix[0].length;
//        int[][] transposed = new int[n][m];
//        for (int i = 0; i < m; i++) {
//            for (int j = 0; j < n; j++) {
//                transposed[j][i] = matrix[i][j];
//            }
//        }
//        return transposed;
    }
}
