package com.leetcode.easy;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/9/22
 * @Modified By:
 * @since DK 1.8
 */
public class AnalysisStr {
    public static void main(String[] args) {
        String str = "2020-05-16 19:20:34|user.login|name=Charles&location=Beijing&device=iPhone";
        System.out.println(exec(str));
    }

    /**
     * 定义一个日志解析函数，接收一个字符串类型的参数，能够把字符串按如下格式返回。可以用任何语
     * 言实现。
     * 输入：2020-05-16 19:20:34|user.login|name=Charles&location=Beijing&device=iPhone
     * 输出：
     * {name:”Charles”, location:”Beijing”, device:”iPhone” }
     */
    private static String  exec (String str){
        StringBuilder builder = new StringBuilder();
        builder.append("{");
        String[] split = str.split("\\|");
        String a = split[split.length - 1];
        String[] split1 = a.split("&");
        for (String s : split1) {
            String[] split2 = s.split("=");
            builder.append(split2[0]).append(":").append("“").append(split2[1]).append("“").append("，");
        }
        builder.delete(builder.length() - 1, builder.length());
        builder.append("}");
        return builder.toString();
    }
}
