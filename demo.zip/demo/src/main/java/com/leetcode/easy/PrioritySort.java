package com.leetcode.easy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.PriorityQueue;

/**
 * @Auther:vivian
 * @Description:小根堆排序
 * @Date:Created in 2022/8/10
 * @Modified By:
 * @since DK 1.8
 */
public class PrioritySort {
    public static void main(String[] args) {
        int[] arr={7,4,6,2,21,73,21,65,84};
        sort(arr,4);
        System.out.println(Arrays.toString(arr));
    }

    /**
     * 移动距离不超过k的几乎有序的数组进行排序
     * @param arr
     */
    public static void sort(int[] arr,int k){
        PriorityQueue<Integer> queue=new PriorityQueue<>();
        int min = Math.min(arr.length, k);
        //将最小移动距离大小数组放进queue中
        int index=0;
        for (; index < min; index++) {
            queue.add(arr[index]);
        }
        int i=0;
        for (; index<arr.length ; i++, index++){
            queue.add(arr[index]);
            arr[i]=queue.poll();
        }
        while (!queue.isEmpty()){
            arr[i++]=queue.poll();
        }

    }
}
