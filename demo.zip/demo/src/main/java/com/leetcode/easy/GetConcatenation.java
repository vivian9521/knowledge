package com.leetcode.easy;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/29
 * @Modified By:
 * @since DK 1.8
 */
public class GetConcatenation {
    public static void main(String[] args) {
        int[] concatenation = getConcatenation(new int[]{1, 2, 1});
        System.out.println(Arrays.toString(concatenation));
    }

    /**
     * 给你一个长度为 n 的整数数组 nums 。请你构建一个长度为 2n 的答案数组 ans ，
     * 数组下标 从 0 开始计数 ，对于所有 0 <= i < n 的 i ，满足下述所有要求：
     * ans[i] == nums[i]
     * ans[i + n] == nums[i]
     * 具体而言，ans 由两个 nums 数组 串联 形成。
     * 返回数组 ans
     */
    public static int[] getConcatenation(int[] nums) {
        int length = nums.length;
        int[] newArr=new int[length *2];
        for (int i = 0; i < length; i++) {
            newArr[i]=nums[i];
            newArr[i+length]=nums[i];
        }
        return newArr;
//        int n = nums.length;
//        int[] ans = new int[2 * n];
//        for (int i = 0; i < 2 * n; i++) {
//            ans[i] = nums[i % n];
//        }
//        return ans;
    }
}
