package com.leetcode.easy;

import sun.swing.StringUIClientPropertyKey;

/**
 * @Auther:vivian
 * @Description:二进制求和
 * @Date:Created in 2022/8/8
 * @Modified By:
 * @since DK 1.8
 */
public class AddBinary {
    public static void main(String[] args) {
        String binary = addBinary("11", "11");
        System.out.println(binary);
    }

    /**
     * 给你两个二进制字符串，返回它们的和（用二进制表示）。
     * 输入为 非空 字符串且只包含数字 1 和 0。
     * @param a
     * @param b
     * @return
     */
    public static String addBinary(String a, String b){
        int len = Math.max(a.length(), b.length());

        int carry=0;
        StringBuilder ans=new StringBuilder();
        for (int i = 0; i < len; i++) {
            carry += a.length() > i ? a.charAt(a.length()-1-i)-'0' : 0;
            carry += b.length() > i ? b.charAt(b.length()-1-i)-'0' : 0;
            ans.append((char)(carry%2+'0'));
            carry /=2;
        }
        if (carry > 0){
            ans.append('1');
        }
        ans.reverse();
        return ans.toString();
    }
}
