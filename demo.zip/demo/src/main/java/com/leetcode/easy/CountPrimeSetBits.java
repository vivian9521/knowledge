package com.leetcode.easy;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/8/2
 * @Modified By:
 * @since DK 1.8
 */
public class CountPrimeSetBits {
    public static void main(String[] args) {
        int i = countPrimeSetBits(6, 10);
        System.out.println(i);
    }

    /**
     * 给你两个整数 left 和 right ，在闭区间 [left, right] 范围内，统计并返回 计算置位位数为质数 的整数个数。
     * 计算置位位数 就是二进制表示中 1 的个数。
     * 提示：1 <= left <= right <= 106
     *      0 <= right - left <= 104
     * @param left
     * @param right
     * @return
     */
    public static int countPrimeSetBits(int left, int right) {
        int count=0;
        //质数
        int[] arr={2,3,5,7,11,13,17,19};
        for (int i=left;i<=right;i++){
            //二进制数
            int bitCount = Integer.bitCount(i);
            for (int j : arr) {
                if (bitCount ==j){
                    count++;
                    break;
                }
            }
        }
        return count;
    }
}
