package com.leetcode.easy;

import com.leetcode.ListNode;
import com.leetcode.Solution;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Stack;

/**
 * @Auther:vivian
 * @Description:回文链表
 * @Date:Created in 2022/8/17
 * @Modified By:
 * @since DK 1.8
 */
public class IsPalindromeLink {

    public static void main(String[] args) {
        ListNode node1 = new ListNode(2, new ListNode(2, new ListNode(2, new ListNode(1))));
        ListNode node2 = new ListNode(1, new ListNode(2, new ListNode(3, new ListNode(2, new ListNode(1)))));
        boolean palindrome = isPalindrome2(node1);
        System.out.println(palindrome);
    }
    /**
     * 给定一个链表的 头节点 head ，请判断其是否为回文链表。
     * 如果一个链表是回文，那么链表节点序列从前往后看和从后往前看是相同的。
     * @param head
     * @return
     */
    public static boolean isPalindrome3(ListNode head){
        if (head == null){
            return false;
        }
        //放入数组中，头尾对比
        List<Integer> list = new ArrayList<>();
        ListNode cur = head;
        while (cur != null){
            list.add(cur.val);
            cur = cur.next;
        }
        int h = 0;
        int t = list.size()-1;
        while (h < t){
            if (!list.get(h).equals(list.get(t))){
                return false;
            }
            h++;
            t--;
        }
        return true;
    }
    /**
     * 给定一个链表的 头节点 head ，请判断其是否为回文链表。
     * 如果一个链表是回文，那么链表节点序列从前往后看和从后往前看是相同的。
     * @param head
     * @return
     */
    public static boolean isPalindrome1(ListNode head) {
        //方法一：栈
        Stack<ListNode> stack = new Stack<>();
        ListNode cur = head;
        while (cur != null){
            stack.push(cur);
            cur = cur.next;
        }
        while (head != null){
            if (head.val != stack.pop().val){
                return false;
            }
            head = head.next;
        }
        return true;
    }

    /**
     * 给定一个链表的 头节点 head ，请判断其是否为回文链表。
     * 如果一个链表是回文，那么链表节点序列从前往后看和从后往前看是相同的。
     * @param head
     * @return
     */
    public static boolean isPalindrome2(ListNode head) {
        //方法二：快慢指针
        //快慢指针获取中点位置，然后对中点后半部分进行反转链表操作，
        //head和反转后的列表进行比较
        //如果相等，将链表反转到原来位置
        //慢指针走一步，快指针走两步
        if(head == null){
            return false;
        }
        ListNode s = head;
        ListNode f = head;
        while (f.next !=null && f.next.next != null){
            s = s.next;
            f = f.next.next;
        }
        //此时s指针位于中点位置,进行后半部分反转链表操作
        ListNode s1 = s.next;
        ListNode reverse = reverse(s1);
        while (reverse != null){
            if (reverse.val != head.val){
                return false;
            }
            reverse = reverse.next;
            head = head.next;
        }
        return true;
    }

    /**
     * 反转链表
     * @param head
     * @return
     */
    private static ListNode reverse(ListNode head){
        ListNode p = null;
        ListNode q = head;
        while (q != null){
            ListNode temp = q.next;
            q.next = p;
            p = q;
            q = temp;
        }
        return p;
    }
}
