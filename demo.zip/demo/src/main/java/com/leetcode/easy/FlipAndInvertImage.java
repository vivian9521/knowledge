package com.leetcode.easy;

import jdk.nashorn.internal.ir.annotations.Ignore;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:翻转图像
 * @Date:Created in 2022/8/10
 * @Modified By:
 * @since DK 1.8
 */
public class FlipAndInvertImage {
    public static void main(String[] args) {
        //输入：image = [[1,1,0],[1,0,1],[0,0,0]]
        //输出：[[1,0,0],[0,1,0],[1,1,1]]
        //解释：首先翻转每一行: [[0,1,1],[1,0,1],[0,0,0]]；
        //然后反转图片: [[1,0,0],[0,1,0],[1,1,1]]
        int[][] image = {{1,1,0}, {1,0,1}, {0,0,0}};
        int[][] invertImage = flipAndInvertImage(image);
        for (int[] arr : invertImage) {
            System.out.println(Arrays.toString(arr));
        }
    }

    /**
     * 给定一个 n x n 的二进制矩阵 image ，先 水平 翻转图像，然后 反转 图像并返回 结果 。
     * 水平翻转图片就是将图片的每一行都进行翻转，即逆序。
     * 例如，水平翻转 [1,1,0] 的结果是 [0,1,1]。
     * 反转图片的意思是图片中的 0 全部被 1 替换， 1 全部被 0 替换。
     * 例如，反转 [0,1,1] 的结果是 [1,0,0]。
     */
    public static int[][] flipAndInvertImage(int[][] image) {
        //模拟优化 + 双指针
        //具体而言，考虑以下四种情况。
        //●情况一: image[i[left] = 0, image[i][right]=0。 对第i行进行水平翻转之后，image[i][left =0, image[i][right]= 0。进行反转之后，image[i[left] = 1, image[i][right] = 1。
        //●情况二: image[i][left = 1, image[i][right]= 1。对第i行进行水平翻转之后，image[i[left] =1, imageli][right]= 1。进行反转之后，image[i[left = 0, imagel[i[right] = 0。
        //●情况三: image[i][left] = 0, image[i][right= 1。对第i行进行水平翻转之后，image[i][left[ =1, image[i][right] = 0。进行反转之后，imageli][left] = 0, imageli][right] = 1。
        //●情况四: image[i][left = 1, image[i][right]=0。 对第i行进行水平翻转之后，image[i[left] =0, image[i][right]= 1。进行反转之后，imageli][lft] = 1, imageli][right]= 0。
        for (int i = 0; i < image.length; i++) {
            int left = 0;
            int right = image.length-1;
            while (left < right){
                if (image[i][left] == image[i][right]){
                    image[i][left] = image[i][left]^1;
                    image[i][right] = image[i][right]^1;
                }
                left++;
                right--;
            }
            if (left == right){
                image[i][left] = image[i][left]^1;
            }
        }
        return image;
//        int[][] res=new int[image.length][image.length];
//        for (int i = 0; i < image.length; i++) {
//            int[] arr = image[i];
//            int len=arr.length-1;
//            int[] temp = new int[arr.length];
//            for (int j = 0; j < arr.length; j++) {
//                temp[len--] = (arr[j] == 1 ? 0 : 1);
//            }
//            res[i]=temp;
//        }
//        return res;
    }
}
