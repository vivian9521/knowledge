package com.leetcode.easy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/29
 * @Modified By:
 * @since DK 1.8
 */
public class GenerateYangHuiTriangle2 {
    public static void main(String[] args) {
        //杨辉三角
        List<Integer> rowList = getRow(4);
        System.out.println(rowList);
    }
    /**
     给定一个非负索引 rowIndex，返回「杨辉三角」的第 rowIndex 行。
     在「杨辉三角」中，每个数是它左上方和右上方的数的和。

     * @param numRows
     * @return
     */
    public static List<Integer> getRow(int numRows) {
        /*List<Integer> pre = new ArrayList<Integer>();
        for (int i = 0; i <= numRows; ++i) {
            List<Integer> cur = new ArrayList<Integer>();
            for (int j = 0; j <= i; ++j) {
                if (j == 0 || j == i) {
                    cur.add(1);
                } else {
                    cur.add(pre.get(j - 1) + pre.get(j));
                }
            }
            pre = cur;
        }
        return pre;*/

        //滑动数组
        List<Integer> row = new ArrayList<Integer>();
        row.add(1);
        for (int i = 1; i <= numRows; ++i) {
            row.add(0);
            for (int j = i; j > 0; --j) {
                row.set(j, row.get(j) + row.get(j - 1));
            }
        }
        return row;
//        List<List<Integer>> list=new ArrayList<>();
//        for (int i = 0; i <= numRows; i++){
//            List<Integer> res=new ArrayList<>();
//            for (int j = 0; j <= i; j++) {
//                if (j==0 || j==i){
//                    res.add(1);
//                }else {
//                    res.add(list.get(i - 1).get(j - 1) + list.get(i - 1).get(j));
//                }
//            }
//            list.add(res);
//        }
//        return list.get(numRows);
    }
}
