package com.leetcode.easy;

/**
 * @Auther:vivian
 * @Description: 验证回文串
 * @Date:Created in 2022/9/1
 * @Modified By:
 * @since DK 1.8
 */
public class isPalindromeStr {
    public static void main(String[] args) {
        //输入: "A man, a plan, a canal: Panama"
        //输出：true
        //解释："amanaplanacanalpanama" 是回文串。
        boolean palindrome = isPalindrome("0P");
        System.out.println(palindrome);
    }

    /**
     * 如果在将所有大写字符转换为小写字符、并移除所有非字母数字字符之后，短语正着读和反着读都一样。
     * 则可以认为该短语是一个回文串。
     * 字母和数字都属于字母数字字符。
     * 给你一个字符串 s，如果它是回文串，返回 true ；否则，返回 false 。
     * @param s
     * @return
     */
    public static boolean isPalindrome(String s) {
        String s1 = s.toLowerCase();
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < s1.length(); i++) {
            boolean letter = Character.isLetterOrDigit(s.charAt(i));
            if (letter){
                builder.append(s1.charAt(i));
            }
        }
        if (builder.length() == 0 || builder.length() == 1){
            return true;
        }
        int p = 0;
        int q = builder.length() - 1;
        while (p < q){
            if (builder.charAt(p) != builder.charAt(q)){
                return false;
            }
            p++;
            q--;
        }
        return true;
    }
}
