package com.leetcode.easy;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/8/10
 * @Modified By:
 * @since DK 1.8
 */
public class DefangIPaddr {
    public static void main(String[] args) {
        String addr="1.1.1.1";
        String iPaddr = defangIPaddr(addr);
        System.out.println(iPaddr);
    }

    /**
     * 给你一个有效的 IPv4 地址 address，返回这个 IP 地址的无效化版本。
     * 所谓无效化 IP 地址，其实就是用 "[.]" 代替了每个 "."。
     * @param address
     * @return
     */
    public static String defangIPaddr(String address) {
        return address.replace(".", "[.]");
    }
}
