package com.leetcode.easy;

import com.leetcode.ListNode;

/**
 * @Auther:vivian
 * @Description:相交链表
 * @Date:Created in 2022/8/25
 * @Modified By:
 * @since DK 1.8
 */
public class GetIntersectionNode {
    public static void main(String[] args) {

    }
    /**
     * 给你两个单链表的头节点 headA 和 headB ，请你找出并返回两个单链表相交的起始节点。
     * 如果两个链表不存在相交节点，返回 null 。
     * @param headA
     * @param headB
     * @return
     */
    public static ListNode getIntersectionNode(ListNode headA, ListNode headB) {
        if (headA == null || headB == null){
            return null;
        }
        //两个链表相差长度
        int lena = 0;
        int lenb = 0;
        ListNode a = headA;
        ListNode b = headB;
        while (a != null){
            a = a.next;
            lena++;
        }
        while (b !=null){
            b = b.next;
            lenb++;
        }
        int step = Math.abs(lena - lenb);
        a = headA;
        b = headB;
        for (int i = 0; i < step; i++) {
            if (lena > lenb){
                //链表a先走step步，与链表b同步
                a = a.next;
            }else {
                //链表b先走step步，与链表a同步
                b = b.next;
            }
        }
        while (a != null){
            if (a == b){
                return a;
            }
            a = a.next;
            b = b.next;
        }
        return null;
    }
}
