package com.leetcode.easy;

import javax.sound.midi.Soundbank;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/29
 * @Modified By:
 * @since DK 1.8
 */
public class Beer {
    public static void main(String[] args) {
        //啤酒问题
        beer(10);
        System.out.println(sum);
        System.out.println(LastRemainGz);
        System.out.println(LastRemainPz);
    }
    /**
     * 啤酒2元1瓶，4个盖子可以换一瓶．2个空瓶可以换一瓶
     * ，问10元可以喝多少瓶，剩余多少盖子和瓶子！！
     */
    private static int sum; //可以喝多少瓶
    private static int LastRemainGz; //剩余多少盖子
    private static int LastRemainPz;//剩余多少瓶子
    public static void beer(int money){
        //可以买多少瓶啤酒
        int pj=money/2;
        sum=sum+pj;

        //现有啤酒瓶数
        int allPz=LastRemainPz + pj;
        //现有盖子数
        int allGz=LastRemainGz+pj;

        int sumMoney=0;
        //空瓶可以换几瓶酒
        if (allPz>=2){
            sumMoney+=((allPz) / 2)*2;
        }
        //剩余啤酒空瓶数
        LastRemainPz=allPz%2;

        //盖子可以换几瓶酒
        if (allGz>=4){
            sumMoney+=((allGz)/4)*2;
        }
        //剩余盖子数
        LastRemainGz=allGz%4;

        if (sumMoney>=2){
            beer(sumMoney);
        }
    }
}
