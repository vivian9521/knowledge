package com.leetcode.easy;

import com.leetcode.TreeNode;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:二叉树前序遍历
 * @Date:Created in 2022/8/31
 * @Modified By:
 * @since DK 1.8
 */
public class PreorderTraversal {
    public static void main(String[] args) {

        TreeNode head = new TreeNode(5);
        head.left = new TreeNode(3);
        head.right = new TreeNode(8) ;
        head.left.left = new TreeNode(2);
        head.left.right = new TreeNode(4);
        head.left.left.left = new TreeNode(1);
        head.right.left = new TreeNode(7);
        head. right.left.left = new TreeNode(6);
        head.right.right = new TreeNode(10);
        head.right.right.left = new TreeNode(9);
        head.right.right.right = new TreeNode(11);

        List<Integer> list = preorderTraversal(head);
        System.out.println(list);
    }
    public static List<Integer> preorderTraversal(TreeNode root) {
        List<Integer> list = new ArrayList<>();
        order(root, list);
        return list;
    }

    public static void order (TreeNode node , List<Integer> list){
        if (node == null){
            return;
        }
        list.add(node.val);
        order(node.left, list);
        order(node.right, list);
    }
}
