package com.leetcode.easy;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/7/29
 * @Modified By:
 * @since DK 1.8
 */
public class Xor {
    public static void main(String[] args) {
          //异或
        int[] a=new int[]{1,3,3,3,1,2,2,1,1,9,9,9};
        xor(a);
    }
    /**
     * 异或
     * 两种数各有偶数个
     * 两种数各有奇数个
     * 求奇数个的两种数
     */
    public static void xor(int[] arr){
        //数组相互异或，最后两个奇数一定是a^b
        int eor=0;
        for (int i : arr) {
            eor=eor^i;
        }
        //eor=a^b,不等于0，
        // 代表一定二进制某一位上不相等，1个为0，一个为1
        //求出a^b上最右侧的1,代表最右侧的1要么是上的，要么是b上的
        int rightOne=eor&(~eor+1);
        //将总数分为两个部分，一个为最右侧为1的，一个为0的，其余数都是偶数个，所以都可以异或为0，最后只剩下a或b
        //所以a和b分别在一个部分
        int eor1=0;
        for (int i : arr) {
            //(rightOne&i)==rightOne也可
            if ((rightOne&i)==0){
                eor1=eor1^i;
            }
        }
        System.out.println("数字1:"+eor1);
        System.out.println("数字2:"+(eor^eor1));
    }
}
