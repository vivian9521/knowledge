package com.leetcode.easy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:6 和 9 组成的最大数字
 * @Date:Created in 2022/8/11
 * @Modified By:
 * @since DK 1.8
 */
public class Maximum69Number {
    public static void main(String[] args) {
        int number = maximum69Number(6699);
        System.out.println(number);
    }

    /**
     * 给你一个仅由数字 6 和 9 组成的正整数 num。
     * 你最多只能翻转一位数字，将 6 变成 9，或者把 9 变成 6 。
     * 请返回你可以得到的最大数字。
     * @param num
     * @return
     */
    public static int maximum69Number (int num) {
        char[] chars = String.valueOf(num).toCharArray();
        for (int i = 0; i < chars.length; i++) {
            if (chars[i] == '9'){
                continue;
            }
            chars[i]='9';
            break;
        }
        return Integer.parseInt(String.valueOf(chars));
//        int rax = num;
//        int remain;
//        List<Integer> data = new ArrayList<>();
//        while (rax > 0){
//            remain = rax%10;
//            rax = rax/10;
//            data.add(remain);
//        }
//        for (int i = data.size() - 1; i >= 0; i--) {
//            if (data.get(i)==9){
//                continue;
//            }
//            data.set(i,9);
//            break;
//        }
//        int res=0;
//        for (int i = data.size() - 1; i >= 0; i--) {
//            res = res*10 + data.get(i);
//        }
//        return res;
    }
}
