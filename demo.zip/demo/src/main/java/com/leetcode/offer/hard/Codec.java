package com.leetcode.offer.hard;

import com.leetcode.TreeNode;

import java.util.LinkedList;

/**
 * @Auther:vivian
 * @Description:LCR 156. 序列化与反序列化二叉树
 * 序列化是将一个数据结构或者对象转换为连续的比特位的操作，进而可以将转换后的数据存储在一个文件或者内存中，
 * 同时也可以通过网络传输到另一个计算机环境，采取相反方式重构得到原数据。
 *
 * 请设计一个算法来实现二叉树的序列化与反序列化。这里不限定你的序列 / 反序列化算法执行逻辑，
 * 你只需要保证一个二叉树可以被序列化为一个字符串并且将这个字符串反序列化为原始的树结构。
 * @Date:Created in 2023/9/28
 * @Modified By:
 * @since DK 1.8
 */
public class Codec {

    // Encodes a tree to a single string.
    public String serialize(TreeNode root) {
        StringBuilder builder = new StringBuilder();
        builder.append("[");

        if (root != null){
            LinkedList<TreeNode> queue = new LinkedList<>();
            queue.add(root);
            while (!queue.isEmpty()){
                TreeNode node = queue.poll();
                if (node != null){
                    builder.append(node.val).append(",");
                    queue.add(node.left);
                    queue.add(node.right);
                }else {
                    builder.append("null,");
                }

            }
            builder.delete(builder.length() - 1, builder.length());
        }

        builder.append("]");
        return builder.toString();
    }

    // Decodes your encoded data to tree.
    public TreeNode deserialize(String data) {
        if (data.equals("[]")){
            return null;
        }
        String[] arr = data.substring(1, data.length() - 1).split(",");
        if (arr.length == 0){
            return null;
        }
        LinkedList<TreeNode> queue = new LinkedList<>();
        TreeNode head = new TreeNode(Integer.parseInt(arr[0]));
        queue.add(head);
        int i = 1;
        while (!queue.isEmpty()){
            TreeNode node = queue.poll();
            if (!arr[i].equals("null")){
                node.left = new TreeNode(Integer.parseInt(arr[i]));
                queue.add(node.left);
            }
            i++;
            if (!arr[i].equals("null")){
                node.right = new TreeNode(Integer.parseInt(arr[i]));
                queue.add(node.right);
            }
            i++;
        }

        return head;
    }

    public static void main(String[] args) {
        Codec codec = new Codec();
        String serialize = codec.serialize(new TreeNode(1, new TreeNode(2, null, null), new TreeNode(3, new TreeNode(4), new TreeNode(5))));
        System.out.println(serialize);
        TreeNode deserialize = codec.deserialize(serialize);
    }
}
