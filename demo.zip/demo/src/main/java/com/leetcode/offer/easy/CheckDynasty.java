package com.leetcode.offer.easy;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * @Auther:vivian
 * @Description:LCR 186. 文物朝代判断
 * 展览馆展出来自 13 个朝代的文物，每排展柜展出 5 个文物。
 * 某排文物的摆放情况记录于数组 places，其中 places[i] 表示处于第 i 位文物的所属朝代编号。
 * 其中，编号为 0 的朝代表示未知朝代。请判断并返回这排文物的所属朝代编号是否连续（如遇未知朝代可算作连续情况）。
 * @Date:Created in 2023/10/9
 * @Modified By:
 * @since DK 1.8
 */
public class CheckDynasty  {
    /**
     * 示例 1：
     *
     * 输入: places = [0, 6, 9, 0, 7]
     * 输出: True
     * 示例 2：
     *
     * 输入: places = [7, 8, 9, 10, 11]
     * 输出: True
     * [0, 0, 2, 2, 5]
     * false
     * @param places
     * @return
     */
    /**
     * 不重复（0除外）
     * 最大-最小<5
     * @param places
     * @return
     */
    public boolean checkDynasty(int[] places) {
        Set<Integer> set = new HashSet<>();
        int min = 14;
        int max = 0;
        for (int place : places) {
            if (place == 0){
                continue;
            }
            max = Math.max(max, place);
            min = Math.min(min, place);
            if (set.contains(place)){
                return false;
            }
            set.add(place);
        }
        return max - min < 5;
    }

    public static void main(String[] args) {
        CheckDynasty checkDynasty = new CheckDynasty();
        boolean b = checkDynasty.checkDynasty(new int[]{6, 7, 8, 9, 10});
        System.out.println(b);
    }
}
