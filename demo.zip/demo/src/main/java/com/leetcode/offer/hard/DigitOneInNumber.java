package com.leetcode.offer.hard;

/**
 * @Auther:vivian
 * @Description:LCR 162. 数字 1 的个数
 * 给定一个整数 num，计算所有小于等于 num 的非负整数中数字 1 出现的个数。
 * @Date:Created in 2023/10/19
 * @Modified By:
 * @since DK 1.8
 */
public class DigitOneInNumber {
    /**
     * 示例 1：
     *
     * 输入：num = 0
     * 输出：0
     * 示例 2：
     *
     * 输入：num = 13
     * 1
     * 10 11 12 13 14 15 16 17 18 19
     * 21 31 ... 91
     * 101 102...109 110 111 113....119
     * 121 131 141 ....191
     * 201 210 211...219
     * 221
     * 输出：6
     * @param num
     * @return
     */
    public int digitOneInNumber(int num) {
        //举例 num =  3101566
        //1、cur > 1情况
        //先算百位上1的个数 cur = 5, base = 100;
        //int a = 3101 = num/base/10, int b = 66 = num%base
        // 百位1的个数 = 0~3101个 * 0~99个= (a + 1)*base
        //2、cur = 1情况
        // 计算千位1的个数 cur = 1, base = 1000;
        // int a = 310 = num/base/10, int b = 566 = num%base
        //千位1的个数 = 0~309个 * 0~999 个+ 1 * (0~566)个 = a*base + b + 1
        //3、cur = 0情况
        //计算万位个数 cur = 0,base = 10000
        // int a = 31 = num/base/10, int b = 1566 = num%base
        //万位个数 = 0~30个 * 0~9999个 = a * base
        int res = 0;
        long base = 1;
        long b;
        long a;
        long cur;
        while (base <= num){
            b = num%base;
            a = num/base;
            cur = a%10;
            a = a/10;
            if (cur > 1){
                res += (a + 1) * base;
            }else if (cur == 1){
                res += a * base + b + 1;
            }else {
                res += a * base;
            }
            base *= 10;
        }
        return res;
    }
}
