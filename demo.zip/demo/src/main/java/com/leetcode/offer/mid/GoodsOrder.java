package com.leetcode.offer.mid;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:LCR 157. 套餐内商品的排列顺序
 * 某店铺将用于组成套餐的商品记作字符串 goods，其中 goods[i] 表示对应商品。请返回该套餐内所含商品的 全部排列方式 。
 *
 * 返回结果 无顺序要求，但不能含有重复的元素。
 * @Date:Created in 2023/9/28
 * @Modified By:
 * @since DK 1.8
 */
public class GoodsOrder {
    /**
     * 示例 1:
     *
     * 输入：goods = "agew"
     * 输出：["aegw","aewg","agew","agwe","aweg","awge","eagw","eawg","egaw","egwa","ewag","ewga",
     * "gaew","gawe","geaw","gewa","gwae","gwea","waeg","wage","weag","wega","wgae","wgea"]
     * @param goods
     * @return
     */

    //n×(n−1)×(n−2)…×2×1
    char[] c;
    List<String> res = new ArrayList<>();
    public String[] goodsOrder(String goods) {
        c = goods.toCharArray();
        dfs(0);
        return res.toArray(new String[res.size()]);
    }
    private void dfs(int index){
        if (index == c.length - 1){
           res.add(String.valueOf(c));
           return;
        }
        HashSet<Character> set = new HashSet<>();
        for (int i = index; i < c.length; i++) {
            if (set.contains(c[i])){ //存在重复，剪枝
                continue;
            }
            set.add(c[i]);
            swap(i, index);         // 交换，将 c[i] 固定在第 x 位
            dfs(index + 1);        //开启固定第 x + 1 位字符
            swap(i, index);         // 恢复交换
        }
    }

//    List<String> res = new LinkedList<>();
//    char[] c;
//    public String[] permutation(String s) {
//        c = s.toCharArray();
//        dfs(0);
//        return res.toArray(new String[res.size()]);
//    }
//    void dfs(int x) {
//        if(x == c.length - 1) {
//            res.add(String.valueOf(c));      // 添加排列方案
//            return;
//        }
//        HashSet<Character> set = new HashSet<>();
//        for(int i = x; i < c.length; i++) {
//            if(set.contains(c[i])) continue; // 重复，因此剪枝
//            set.add(c[i]);
//            swap(i, x);                      // 交换，将 c[i] 固定在第 x 位
//            dfs(x + 1);                      // 开启固定第 x + 1 位字符
//            swap(i, x);                      // 恢复交换
//        }
//    }
    void swap(int a, int b) {
        char tmp = c[a];
        c[a] = c[b];
        c[b] = tmp;
    }
}
