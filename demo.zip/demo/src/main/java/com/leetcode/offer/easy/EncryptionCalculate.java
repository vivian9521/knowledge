package com.leetcode.offer.easy;

/**
 * @Auther:vivian
 * @Description:LCR 190. 加密运算
 * 计算机安全专家正在开发一款高度安全的加密通信软件，需要在进行数据传输时对数据进行加密和解密操作。
 * 假定 dataA 和 dataB 分别为随机抽样的两次通信的数据量：
 *
 * 正数为发送量
 * 负数为接受量
 * 0 为数据遗失
 * 请不使用四则运算符的情况下实现一个函数计算两次通信的数据量之和（三种情况均需被统计），
 * 以确保在数据传输过程中的高安全性和保密性。
 * @Date:Created in 2023/10/17
 * @Modified By:
 * @since DK 1.8
 */
public class EncryptionCalculate {
    /**
     * 观察发现，无进位和 与 异或运算 规律相同，进位 和 与运算 规律相同（并需左移一位）。
     * 因此，无进位和 n 与进位 c的计算公式如下；
     *
     * {n=dataA⊕dataB  非进位和：异或运算
     * {c=dataA & dataB<<1  进位：与运算+左移一位
     *
     * （和 s ）=（非进位和 n ）+（进位 c ）。即可将 s=dataA+dataB转化为：
     * s=dataA+dataB ⇒ s=n+c
     * 循环求 n 和 c ，直至进位 c=0 ；此时 s=n，返回 n 即可。
     * @param dataA
     * @param dataB
     * @return
     */
    public int encryptionCalculate(int dataA, int dataB) {
        while (dataB != 0){
            int c = (dataA & dataB) << 1;//c进位
            dataA ^= dataB; // dataA = 非进位和
            dataB = c; //dataB进位
        }
        return dataA;
    }
}
