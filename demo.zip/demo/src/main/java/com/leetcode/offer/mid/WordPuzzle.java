package com.leetcode.offer.mid;

import groovy.transform.builder.InitializerStrategy;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @Auther:vivian
 * @Description:LCR 129. 字母迷宫
 * 字母迷宫游戏初始界面记作 m x n 二维字符串数组 grid，请判断玩家是否能在 grid 中找到目标单词 target。
 * 注意：寻找单词时 必须 按照字母顺序，通过水平或垂直方向相邻的单元格内的字母构成，同时，同一个单元格内的字母
 * 不允许被重复使用 。
 * @Date:Created in 2023/9/25
 * @Modified By:
 * @since DK 1.8
 */
public class WordPuzzle {
    /**
     * 示例 1：
     *
     * 输入：grid = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], target = "ABCCED"
     * 输出：true
     * 示例 2：
     *
     * 输入：grid = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], target = "SEE"
     * 输出：true
     * 示例 3：
     *
     * 输入：grid = [["A","B","C","E"],["S","F","C","S"],["A","D","E","E"]], target = "ABCB"
     * 输出：false
     * @param grid
     * @param target
     * @return
     */
    public boolean wordPuzzle(char[][] grid, String target) {
        char[] tarChars = target.toCharArray();

    //先查找第一个target字母位置
        for (int i = 0; i < grid.length; i++) {
        for (int j = 0; j < grid[i].length; j++) {
            if (grid[i][j] == tarChars[0]){
                if (check(grid, i, j, tarChars, 0)){
                    return true;
                }
            }
        }
    }
        return false;
}

    private boolean check(char[][] grid, int i, int j, char[] tarChars, int k) {
        if (i < 0 || i >= grid.length || j < 0 || j >= grid[i].length ||  grid[i][j] != tarChars[k] ){
            return false;
        }
        if (k == tarChars.length - 1){
            return true;
        }
        //代表元素已访问过
        grid[i][j] = ' ';
        boolean res  = check(grid, i - 1, j, tarChars, k + 1) || check(grid, i + 1, j, tarChars, k + 1)
                || check(grid, i , j - 1, tarChars, k + 1) || check(grid, i, j + 1, tarChars, k + 1);
        //还原元素
        grid[i][j] = tarChars[k];
        return res;
    }

    public static void main(String[] args) {
        WordPuzzle puzzle = new WordPuzzle();
        //'C','A','A'
        //'A','A','A'
        //'B','C','D'

        //'A','B','C','E'
        //'S','F','E','S'
        //'A','D','E','E'
//        char[][] arr = new char[][]{new char[]{'C','A','A'}, new char[]{'A','A','A'}, new char[]{'B','C','D'}};
//        char[][] arr = new char[][]{new char[]{'A','B','C','E'}, new char[]{'S','F','C','S'}, new char[]{'A','D','E','E'}};
        char[][] arr = new char[][]{new char[]{'A','B','C','E'}, new char[]{'S','F','E','S'}, new char[]{'A','D','E','E'}};

        String target = "ABCESEEEFS";
        boolean b = puzzle.wordPuzzle(arr, target);
        System.out.println(b);
    }
}
