package com.leetcode.offer.easy;

import com.leetcode.ListNode;
import jdk.nashorn.internal.objects.annotations.Where;

/**
 * @Auther:vivian
 * @Description:剑指 Offer 22. 链表中倒数第k个节点
 * 输入一个链表，输出该链表中倒数第k个节点。为了符合大多数人的习惯，本题从1开始计数，即链表的尾节点是倒数第1个节点。
 * 例如，一个链表有 6 个节点，从头节点开始，它们的值依次是 1、2、3、4、5、6。这个链表的倒数第 3 个节点是值为 4 的节点。
 * @Date:Created in 2023/9/11
 * @Modified By:
 * @since DK 1.8
 */
public class GetKthFromEnd {
    /**
     * 双指针解法
     * @param head
     * @param k
     * @return
     */
    public static ListNode getKthFromEnd1(ListNode head, int k) {
        //同时向前移动k-1步
        ListNode former = head;
        ListNode latter = head;
        //latter往前走k步
        for (int i =0; i<k; i++){
            latter = latter.next;
        }
        //然后两个指针同时走
        while (latter != null){
            former = former.next;
            latter = latter.next;
        }
        return former;
    }
    /**
     * 给定一个链表: 1->2->3->4->5, 和 k = 2.
     * 返回链表 4->5.
     * @param head
     * @param k
     * @return
     */
    public static ListNode getKthFromEnd(ListNode head, int k) {
        ListNode cur = head;
        int length = 0;
        while (cur != null){
            length ++;
            cur = cur.next;
        }

        cur = head;
        int size = length - k + 1;
        for (int i = 1; i <= length; i++) {
            if (size == i){
                return cur;
            }
            cur = cur.next;
        }
        return cur;
    }

    public static void main(String[] args) {
        ListNode node = new ListNode(4, new ListNode(5, new ListNode(1, new ListNode(9))));
        ListNode kthFromEnd = getKthFromEnd1(node, 4);
        ListNode.foreachListNode(kthFromEnd);
    }
}
