package com.leetcode.offer.mid;

import com.design.B;
import com.leetcode.TreeNode;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

/**
 * @Auther:vivian
 * @Description:LCR 143. 子结构判断
 * 给定两棵二叉树 tree1 和 tree2，判断 tree2 是否以 tree1 的某个节点为根的子树具有 相同的结构和节点值 。
 * 注意，空树 不会是以 tree1 的某个节点为根的子树具有 相同的结构和节点值 。
 * @Date:Created in 2023/9/21
 * @Modified By:
 * @since DK 1.8
 */
public class IsSubStructure {
    /**
     * 输入：tree1 = [1,7,5], tree2 = [6,1]
     * 输出：false
     * 解释：tree2 与 tree1 的一个子树没有相同的结构和节点值。
     *
     * 输入：tree1 = [3,6,7,1,8], tree2 = [6,1]
     * 输出：true
     * 解释：tree2 与 tree1 的一个子树拥有相同的结构和节点值。即 6 - > 1。
     * @param A
     * @param B
     * @return
     */

    /**
     * recur(A, B) 函数：
     *
     * 终止条件：
     * 当节点 B 为空：说明树 B 已匹配完成（越过叶子节点），因此返回 true ；
     * 当节点 A 为空：说明已经越过树 A 叶子节点，即匹配失败，返回 false ；
     * 当节点 A 和 B 的值不同：说明匹配失败，返回 false ；
     * 返回值：
     * 判断 A 和 B 的左子节点是否相等，即 recur(A.left, B.left) ；
     * 判断 A 和 B 的右子节点是否相等，即 recur(A.right, B.right) ；
     * isSubStructure(A, B) 函数：
     *
     * 特例处理： 当 树 A 为空 或 树 B 为空 时，直接返回 false ；
     * 返回值： 若树 B 是树 A 的子结构，则必满足以下三种情况之一，因此用或 || 连接；
     * 以 节点 A 为根节点的子树 包含树 B ，对应 recur(A, B)；
     * 树 B 是 树 A 左子树 的子结构，对应 isSubStructure(A.left, B)；
     * 树 B 是 树 A右子树 的子结构，对应 isSubStructure(A.right, B)；
     * 以上 2. 3. 实质上是在对树 A 做 先序遍历 。
     * @param A
     * @param B
     * @return
     */
    public boolean isSubStructure(TreeNode A, TreeNode B) {
       if (A == null || B == null){
           return false;
       }
       return recur(A, B) || isSubStructure(A.left, B) || isSubStructure(A.right, B);
    }
    private boolean recur(TreeNode A, TreeNode B) {
        if (B == null){
            return true;
        }
        if (A == null || A.val != B.val){
            return false;
        }
        return recur(A.left, B.left) && recur(A.right, B.right);
    }



    public static void main(String[] args) {
        TreeNode A = new TreeNode(1, new TreeNode(2, new TreeNode(4), null), new TreeNode(3));
        TreeNode B = new TreeNode(3);
        IsSubStructure subStructure = new IsSubStructure();
        boolean subStructure2 = subStructure.isSubStructure(A, B);
        System.out.println(subStructure2);
    }
}
