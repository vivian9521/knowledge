package com.leetcode.offer.mid;

/**
 * @Auther:vivian
 * @Description:LCR 134. Pow(x, n)
 * 实现 pow(x, n) ，即计算 x 的 n 次幂函数（即，xn）。
 * @Date:Created in 2023/10/9
 * @Modified By:
 * @since DK 1.8
 */
public class MyPow {
    /**
     * 示例 2：
     *
     * 输入：x = 2.10000, n = 3
     * 输出：9.26100
     * @param x
     * @param n
     * @return
     */
    public double myPow(double x, int n) {
        if (n == 0){
            return 1;
        }
        double half = myPow(x, n/2);
        return n % 2 == 0 ? half * half : half * half * (n > 0 ? x : 1/x);
    }


    public static void main(String[] args) {
        MyPow myPow = new MyPow();
        double v = myPow.myPow(2.1, 3);
        System.out.println(v);
    }
}
