package com.leetcode.offer.easy;

/**
 * @Auther:vivian
 * @Description:LCR 127. 跳跃训练
 * 今天的有氧运动训练内容是在一个长条形的平台上跳跃。平台有 num 个小格子，每次可以选择跳 一个格子 或者 两个格子。
 * 请返回在训练过程中，学员们共有多少种不同的跳跃方式。
 *
 * 结果可能过大，因此结果需要取模 1e9+7（1000000007），如计算初始结果为：1000000008，请返回 1。
 * @Date:Created in 2023/10/13
 * @Modified By:
 * @since DK 1.8
 */
public class TrainWays {
    /**
     * 示例 1：
     *
     * 输入：n = 2
     * 输出：2
     * 示例 2：
     *
     * 输入：n = 5
     * 输出：8
     * @param num
     * @return
     */
    public int trainWays(int num) {
        if (num == 0){
            return 1;
        }
        int res = 0;
        int i1 = 0;
        int i2 = 0;
        for (int i = 1; i <= num; i++) {
            if (i == 1){
                i1 = 1;
                i2 = 0;
            }
            if (i == 2){
                i1 = 1;
                i2 = 1;
            }
            res = (i1 + i2)%1000000007;
            i2 = i1;
            i1 = res;
        }
        return res;
    }

    public static void main(String[] args) {
        TrainWays trainWays = new TrainWays();
        int i = trainWays.trainWays(5);
        System.out.println(i);
    }
}
