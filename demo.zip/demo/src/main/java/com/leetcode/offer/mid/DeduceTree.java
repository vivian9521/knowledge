package com.leetcode.offer.mid;

import com.leetcode.TreeNode;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:LCR 124. 推理二叉树
 * 某二叉树的先序遍历结果记录于整数数组 preorder，它的中序遍历结果记录于整数数组 inorder。
 * 请根据 preorder 和 inorder 的提示构造出这棵二叉树并返回其根节点。

 * 注意：preorder 和 inorder 中均不含重复数字。
 * @Date:Created in 2023/10/8
 * @Modified By:
 * @since DK 1.8
 */
public class DeduceTree {
    /**
     * 输入: preorder = [3,9,20,15,7], inorder = [9,3,15,20,7]
     *
     * 输出: [3,9,20,null,null,15,7]
     * @param preorder
     * @param inorder
     * @return
     */
    /**
     * 回溯法
     * @param preorder
     * @param inorder
     * @return
     */
    Map<Integer, Integer> map = new HashMap<>();
    int[] preorder;
    public TreeNode deduceTree(int[] preorder, int[] inorder) {
        this.preorder = preorder;
        for (int i = 0; i < inorder.length; i++) {
            map.put(inorder[i], i);
        }
        return recur(0, 0, inorder.length - 1);
    }

    /**
     *
     * @param root 先序数组根节点
     * @param left 中序数组左边界
     * @param right 中序数组右边界
     * @return
     */
    private TreeNode recur(int root, int left, int right){
        if (left > right){
            return null;
        }
        TreeNode node = new TreeNode(preorder[root]);
        Integer i = map.get(preorder[root]);
        node.left = recur(root + 1, left, i - 1);
        //根节点索引= 根节点索引+左子树长度+1
        node.right = recur(root + (i - left) + 1, i + 1, right);
        return node;
    }

}
