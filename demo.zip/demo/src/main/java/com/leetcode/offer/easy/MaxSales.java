package com.leetcode.offer.easy;

/**
 * @Auther:vivian
 * @Description:LCR 161. 连续天数的最高销售额
 * 某公司每日销售额记于整数数组 sales，请返回所有 连续 一或多天销售额总和的最大值。
 *
 * 要求实现时间复杂度为 O(n) 的算法。
 * @Date:Created in 2023/10/13
 * @Modified By:
 * @since DK 1.8
 */
public class MaxSales {
    /**
     * 示例 1:
     *
     * 输入：sales = [-2,1,-3,4,-1,2,1,-5,4]
     * 第一天         【-2,1,-3,4】
     * 第二天         【-2+1,1+-3，-3+4】
     * 第三天         【-2+1+-3,1+-3+4】
     * 输出：6
     * 解释：[4,-1,2,1] 此连续四天的销售总额最高，为 6。
     * 示例 2:
     *
     * 输入：sales = [5,4,-1,7,8]
     * 输出：23
     * 解释：[5,4,-1,7,8] 此连续五天的销售总额最高，为 23。
     * @param sales
     * @return
     */
    public int maxSales(int[] sales) {
        int res = sales[0];
        int pre = 0;
        for (int sale : sales) {
            pre = Math.max(pre + sale, sale);
            res = Math.max(res, pre);
        }
        return res;
    }
}
