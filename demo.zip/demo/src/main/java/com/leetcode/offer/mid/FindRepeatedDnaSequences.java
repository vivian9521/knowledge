package com.leetcode.offer.mid;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @Auther:vivian
 * @Description:187. 重复的DNA序列
 * DNA序列 由一系列核苷酸组成，缩写为 'A', 'C', 'G' 和 'T'.。
 * 例如，"ACGAATTCCG" 是一个 DNA序列 。
 * 在研究 DNA 时，识别 DNA 中的重复序列非常有用。
 * 给定一个表示 DNA序列 的字符串 s ，返回所有在 DNA 分子中出现不止一次的 长度为 10 的序列(子字符串)。
 * 你可以按 任意顺序 返回答案。
 * @Date:Created in 2023/9/18
 * @Modified By:
 * @since DK 1.8
 */
public class FindRepeatedDnaSequences {
    /**
     * 示例 1：
     *
     * 输入：s = "AAAAACCCCCAAAAACCCCCCAAAAAGGGTTT"
     * 输出：["AAAAACCCCC","CCCCCAAAAA"]
     * 示例 2：
     *
     * 输入：s = "AAAAAAAAAAAAA"
     * 输出：["AAAAAAAAAA"]
     * @param s
     * @return
     */
    public static List<String> findRepeatedDnaSequences(String s) {
        if (s.length() <= 10){
            return new ArrayList<>();
        }
        List<String> res = new ArrayList<>();
        int k = 10;
        Set<String> set = new HashSet<>();
        //先切割前10个
        String s1 = s.substring(0, k);
        set.add(s1);
        //从第11个开始遍历
        for (int i = k; i < s.length(); i++) {
            s1 = s.substring(i - k, i);
            if (set.contains(s1)){
                if (!res.contains(s1)){
                    res.add(s1);
                }
            }else {
                set.add(s1);
            }
        }
        return res;
    }

    public static void main(String[] args) {
//        String s = "AAAAACCCCCAAAAACCCCCCAAAAAGGGTTT";
        String s = "AAAAAAAAAAAAA";
        List<String> repeatedDnaSequences = findRepeatedDnaSequences(s);
        System.out.println(repeatedDnaSequences);
    }
}
