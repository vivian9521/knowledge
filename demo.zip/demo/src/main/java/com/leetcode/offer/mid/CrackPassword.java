package com.leetcode.offer.mid;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:LCR 164. 破解闯关密码
 * 闯关游戏需要破解一组密码，闯关组给出的有关密码的线索是：
 *
 * 一个拥有密码所有元素的非负整数数组 password
 * 密码是 password 中所有元素拼接后得到的最小的一个数
 * 请编写一个程序返回这个密码。
 * @Date:Created in 2023/10/12
 * @Modified By:
 * @since DK 1.8
 */
public class CrackPassword {
    /**
     * 示例 1:
     *
     * 输入: password = [15, 8, 7]
     * 输出: "1578"
     * 示例 2:
     *0,30,3,34,5,9
     * 输入: password = [0, 3, 30, 34, 5, 9]
     * 输出: "03033459"
     *
     * 此题求拼接起来的最小数字，本质上是一个排序问题。设数组 password 中任意两数字的字符串为 x 和 y
     * 则规定 排序判断规则 为：
     * 若拼接字符串 x+y>y+x ，则 x “大于” y ；
     * 反之，若 x+y<y+x ，则 x “小于” y ；
     * x “小于” y 代表：排序完成后，数组中 x 应在 y 左边；“大于” 则反之。
     * @param password
     * @return
     */
    public String crackPassword(int[] password) {
        if (password == null || password.length ==0){
            return "";
        }
        quickSort(password, 0, password.length - 1);
        StringBuilder builder = new StringBuilder();
        for (int i : password) {
            builder.append(i);
        }
        return builder.toString();
    }

    private void quickSort(int[] password, int left, int right){
        if (left > right){
            return;
        }
        int l = left;
        int r = right;
        while (l < r){
            while (l < r && (password[left] + "" + password[r]).compareTo(password[r] + "" + password[left]) <= 0){
                r--;
            }
            while (l < r && (password[left] + "" + password[l]).compareTo(password[l] + "" + password[left]) >= 0){
                l++;
            }
            swap(password, l, r);
        }
        swap(password, l, left);
        quickSort(password, left, l - 1);
        quickSort(password, l + 1, right);
    }
    private void swap(int[] stock, int left, int right){
        int temp = stock[left];
        stock[left] = stock[right];
        stock[right] = temp;
    }
    public int getMiddle(String[] strs, int low, int high) {
        //数组的第一个数为基准元素
        String temp = strs[low];
        while (low < high) {
            //从后向前找比基准小的数
            while (low < high && (strs[high] + temp).compareTo(temp + strs[high]) >= 0)
                high--;
            //把比基准小的数移到低端
            strs[low] = strs[high];
            //从前向后找比基准大的数
            while (low < high && (strs[low] + temp).compareTo(temp + strs[low]) <= 0)
                low++;
            //把比基准大的数移到高端
            strs[high] = strs[low];
        }
        strs[low] = temp;
        return low;
    }
    public static void main(String[] args) {
        CrackPassword crackPassword = new CrackPassword();
        String s = crackPassword.crackPassword(new int[]{0, 3, 30, 34, 5, 9});
        System.out.println(s);
    }
}
