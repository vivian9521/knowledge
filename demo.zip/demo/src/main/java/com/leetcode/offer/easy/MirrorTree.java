package com.leetcode.offer.easy;

import com.leetcode.TreeNode;

/**
 * @Auther:vivian
 * @Description:LCR 144. 翻转二叉树
 * 给定一棵二叉树的根节点 root，请左右翻转这棵二叉树，并返回其根节点。
 * @Date:Created in 2023/9/22
 * @Modified By:
 * @since DK 1.8
 */
public class MirrorTree {

    /**
     * 递归
     * 输入：root = [5,7,9,8,3,2,4]
     * 输出：[5,9,7,4,2,3,8]
     * @param root
     * @return
     */
    public TreeNode mirrorTree(TreeNode root) {
        if (root == null){
            return null;
        }
        TreeNode temp = mirrorTree(root.left);
        root.left = mirrorTree(root.right);
        root.right = temp;
        return root;
    }

    public static void main(String[] args) {
        String age = "16岁";
        if (age.contains("岁")){
            String[] arr = age.split("岁");
            System.out.println(Integer.parseInt(arr[0]));
        }
    }
}
