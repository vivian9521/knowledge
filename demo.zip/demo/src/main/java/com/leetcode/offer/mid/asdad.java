package com.leetcode.offer.mid;

import java.util.Random;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/9/26
 * @Modified By:
 * @since DK 1.8
 */
public class asdad {
    public static void main(String[] args) {
//        boolean b = new Random().nextBoolean();
//        System.out.println(b);

        String famlyName = "赵钱孙李周吴郑王冯陈楮卫蒋沈韩杨朱秦尤许何吕施张孔曹严华金魏陶姜戚谢邹喻柏水窦章云苏潘葛奚范彭郎滕殷罗毕郝邬安常乐于时傅皮卞齐康";
        String seniorityName = "福慧智子觉了本圆可悟周洪普广宗道请同玄祖清净真如海湛寂淳贞素德行永延恒妙体常坚固心朗照幽深性明鉴宗祚衷正善喜祥谨悫原济度雪庭为导师引汝归铉路";
        String firstName = "复誉浚瑜孝波靖明震旭金琦基书越岩倚均祥利浪远致圆道嘉秋飞西任唯松腾海照桦治博铁民言柯笃景尘戈标山宵烨乐柳淘琪百瞻折豪容承福柏坚挚畅昌载岳睿栋杭临喻浅玮尚忆壮达玄材洋乔奋影昊易龙秉冠维雨鸣天顷初益丰铭乾质拂恒宁物毅漾城众飘鑫廉晓知青清德暖鉴";
        Random random = new Random();
        StringBuilder nameBuilder = new StringBuilder();
        nameBuilder.append(famlyName.charAt(random.nextInt(famlyName.length())));
        nameBuilder.append(seniorityName.charAt(random.nextInt(seniorityName.length())));
        nameBuilder.append(firstName.charAt(random.nextInt(firstName.length())));
        String name = nameBuilder.toString();
        System.out.println(name);
    }
}
