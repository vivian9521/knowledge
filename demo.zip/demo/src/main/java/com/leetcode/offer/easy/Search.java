package com.leetcode.offer.easy;

import java.util.HashSet;
import java.util.Set;

/**
 * @Auther:vivian
 * @Description:剑指 Offer 53 - I. 在排序数组中查找数字 I
 * 统计一个数字在排序数组中出现的次数。
 * @Date:Created in 2023/9/19
 * @Modified By:
 * @since DK 1.8
 */
public class Search {
    /**
     * 示例 1:
     * 输入: nums = [5,7,7,8,8,10], target = 8
     * 输出: 2
     * 示例 2:
     * 输入: nums = [5,7,7,8,8,10], target = 6
     * 输出: 0
     * @param nums
     * @param target
     * @return
     */
    public static int search(int[] nums, int target) {
        if (nums.length == 0){
            return 0;
        }
        int i = 0;
        for (int num : nums) {
            if (num > target){
                return i;
            }
            if (num == target){
                i++;
            }
        }
        return i;
    }

    /**
     * 二分法
     * @param nums
     * @param target
     * @return
     */
    public static int search2(int[] nums, int target) {
        if (nums.length == 0){
            return 0;
        }
        // 搜索右边界 right
        int i = 0, j = nums.length - 1;
        while(i <= j) {
            int m = (i + j) / 2;
            if(nums[m] <= target){
                i = m + 1;
            } else {
                j = m - 1;
            }
        }
        int right = i;
        // 若数组中无 target ，则提前返回
        if(j >= 0 && nums[j] != target) return 0;
        // 搜索左边界 right
        i = 0; j = nums.length - 1;
        while(i <= j) {
            int m = (i + j) / 2;
            if(nums[m] < target) {
                i = m + 1;
            } else {
                j = m - 1;
            }
        }
        int left = j;
        return right - left - 1;
    }
    public static void main(String[] args) {
        int search = search(new int[]{5, 7, 7, 8, 8, 10}, 8);
        System.out.println(search);
    }
}
