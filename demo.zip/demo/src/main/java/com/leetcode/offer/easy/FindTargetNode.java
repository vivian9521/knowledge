package com.leetcode.offer.easy;

import com.leetcode.TreeNode;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:LCR 174. 寻找二叉搜索树中的目标节点
 * 某公司组织架构以二叉搜索树形式记录，节点值为处于该职位的员工编号。请返回第 cnt 大的员工编号。
 * @Date:Created in 2023/9/27
 * @Modified By:
 * @since DK 1.8
 */
public class FindTargetNode {

    /**
     * root = [7, 3, 9, 1, 5], cnt = 2
     * 输出：7
     * @param root
     * @param cnt
     * @return
     */
    public int findTargetNode(TreeNode root, int cnt) {
        if (root == null){
            return 0;
        }
        List<Integer> list = new ArrayList<>();
        dfs(root, list);
        return list.get(list.size() - cnt);
    }
    private void dfs(TreeNode cur, List<Integer> list){
        if (cur == null){
            return;
        }
        dfs(cur.left, list);
        list.add(cur.val);
        dfs(cur.right, list);
    }

    /**
     * 倒序遍历
     * @param root
     * @param cnt
     * @return
     */
    int res, cnt;
    public int findTargetNode2(TreeNode root, int cnt) {
        this.cnt = cnt;
        dfs1(root);
        return res;
    }

    private void dfs1(TreeNode node){
        if (node == null){
            return;
        }
        dfs1(node.right);
        if (cnt == 0){
            return;
        }
        if (--cnt == 0){
            res = node.val;
        }
        dfs1(node.left);
    }


    public static void main(String[] args) {
        FindTargetNode targetNode = new FindTargetNode();
//        targetNode.findTargetNode()


    }

}
