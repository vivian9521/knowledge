package com.leetcode.offer.mid;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @Auther:vivian
 * @Description:LCR 177. 撞色搭配
 *整数数组 sockets 记录了一个袜子礼盒的颜色分布情况，其中 sockets[i] 表示该袜子的颜色编号。
 * 礼盒中除了一款撞色搭配的袜子，每种颜色的袜子均有两只。请设计一个程序，
 * 在时间复杂度 O(n)，空间复杂度O(1) 内找到这双撞色搭配袜子的两个颜色编号。
 * @Date:Created in 2023/10/17
 * @Modified By:
 * @since DK 1.8
 */
public class SockCollocation {
    /**
     * 示例 1：
     *
     * 输入：sockets = [4, 5, 2, 4, 6, 6]
     * 输出：[2,5] 或 [5,2]
     *      a    00010
     *      b    00101
     *     a^b   00111
     a^b^a = b   00101

     * 示例 2：
     *
     * 输入：sockets = [1, 2, 4, 1, 4, 3, 12, 3]
     * 输出：[2,12] 或 [12,2]
     * @param sockets
     * @return
     */
    /**
     * 1、设整型数组 sockets=[a,a,b,b,...,x,y]，对 sockets中所有数字执行异或，得到的结果为 x⊕y，
     * 2、根据异或运算定义，若整数 x⊕y某二进制位为 1 ，则 x和 y 的此二进制位一定不同。换言之，找到 x⊕y某为1 的二进制位，
     * 即可将数组 sockets 拆分为上述的两个子数组。根据与运算特点，可知对于任意整数 a 有：
     * 若 a&0001≠0 则 a 的第一位为 1 ；
     * 若 a&0010≠0则 a 的第二位为 111 ；
     * 以此类推……
     * 因此，初始化一个辅助变量 m=1 ，通过与运算从右向左循环判断，可 获取整数 x⊕y首位 1 ，记录于 m 中，
     * 3、通过遍历判断 sockets 中各数字和 m 做与运算的结果，可将数组拆分为两个子数组，
     * 并分别对两个子数组遍历求异或，则可得到两个只出现一次的数字
     *
     * @param sockets
     * @return
     */
    public int[] sockCollocation2(int[] sockets) {
        //计算a^b
        int ab = 0;
        for (int socket : sockets) {
            ab ^= socket;
        }
        //求a^b 最右侧进制为1的数m
        int m = 1;
        while ((ab&m) == 0){
            m<<=1;
        }
        //m与数组进行按位与，拆分为两个数组, 两个数组分别进行异或，求出结果
        int a = 0; int b = 0;
        for (int socket : sockets) {
            if ((socket & m) == m){
                a ^= socket;
            }else {
                b ^= socket;
            }
        }
        return new int[]{a, b};
    }
    public int[] sockCollocation(int[] sockets) {
        if (sockets == null || sockets.length == 0){
            return new int[0];
        }
        Set<Integer> set = new HashSet<>();
        for (int socket : sockets) {
            if (!set.add(socket)){
                set.remove(socket);
            }
        }
        int[] res = new int[2];
        int i = 0;
        for (Integer integer : set) {
            res[i++] = integer;
        }
        return res;
    }

    public static void main(String[] args) {
        SockCollocation sockCollocation = new SockCollocation();
        int[] ints = sockCollocation.sockCollocation2(new int[]{4, 5, 2, 4, 6, 6});
        Arrays.stream(ints).forEach(System.out::println);
    }
}
