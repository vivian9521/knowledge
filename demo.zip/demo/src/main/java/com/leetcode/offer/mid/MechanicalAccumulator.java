package com.leetcode.offer.mid;

/**
 * @Auther:vivian
 * @Description:LCR 189. 设计机械累加器
 * 请设计一个机械累加器，计算从 1、2... 一直累加到目标数值 target 的总和。
 * 注意这是一个只能进行加法操作的程序，不具备乘除、if-else、switch-case、for 循环、while 循环，
 * 及条件判断语句等高级功能。
 * @Date:Created in 2023/9/28
 * @Modified By:
 * @since DK 1.8
 */
public class MechanicalAccumulator {

    /**
     * 示例 1：
     * <p>
     * 输入: target = 5
     * 输出: 15
     * 示例 2：
     * <p>
     * 输入: target = 7
     * 输出: 28
     *
     * @param n
     * @return
     */
    public int sumNums(int n) {
        boolean x = n > 1 && (n += sumNums(n - 1)) > 0;
        return n;

//        int res = n == 1 ? 1 : n + sumNums(n - 1);
//        return res;
    }



    int res = 0, target;

    public int mechanicalAccumulator(int target) {
        this.target = target;
        recu(target);
        return res;
    }

    private void recu(int target) {
        if (target == 0) {
            return;
        }
        res += target;
        recu(--target);
    }
    public static void main(String[] args) {
        MechanicalAccumulator accumulator = new MechanicalAccumulator();
//        int i = accumulator.mechanicalAccumulator(7);
        int i = accumulator.sumNums(7);
        System.out.println(i);
    }
}
