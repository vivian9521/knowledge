package com.leetcode.offer.mid;

import com.sun.org.apache.regexp.internal.RE;

/**
 * @Auther:vivian
 * @Description:LCR 188. 买卖芯片的最佳时机
 * 数组 prices 记录了某芯片近期的交易价格，其中 prices[i] 表示的 i 天该芯片的价格。
 * 你只能选择 某一天 买入芯片，并选择在 未来的某一个不同的日子 卖出该芯片。
 * 请设计一个算法计算并返回你从这笔交易中能获取的最大利润。
 *
 * 如果你不能获取任何利润，返回 0。
 * @Date:Created in 2023/10/13
 * @Modified By:
 * @since DK 1.8
 */
public class BestTiming {
    /**
     * 示例 1：
     *
     * 输入：prices = [3, 6, 2, 9, 8, 5]
     * 输出：7
     * 解释：在第 3 天（芯片价格 = 2）买入，在第 4 天（芯片价格 = 9）卖出，最大利润 = 9 - 2 = 7。
     * 示例 2：
     *
     * 输入：prices = [8, 12, 15, 7, 3, 10]
     * 输出：7
     * 解释：在第 5 天（芯片价格 = 3）买入，在第 6 天（芯片价格 = 10）卖出，最大利润 = 10 - 3 = 7。
     * @param prices
     * @return
     */
    public int bestTiming(int[] prices) {
        //前n天最小值
        int min = Integer.MAX_VALUE;
        int profit = 0;
        for (int price : prices) {
            min = Math.min(price, min);
            //前n天最大利润=前n-1天最大利润 与 第n天最大利润的最大值
            profit = Math.max(profit, price - min);
        }
        return profit;
    }


    public static void main(String[] args) {
        BestTiming bestTiming = new BestTiming();
        int i = bestTiming.bestTiming(new int[]{8, 12, 15, 7, 3, 10});
        System.out.println(i);
    }
}
