package com.leetcode.offer.easy;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * @Auther:vivian
 * @Description:剑指 Offer 50. 第一个只出现一次的字符
 * 在字符串 s 中找出第一个只出现一次的字符。如果没有，返回一个单空格。 s 只包含小写字母。
 * @Date:Created in 2023/9/20
 * @Modified By:
 * @since DK 1.8
 */
public class FirstUniqChar {
    /**
     * 示例 1:
     * 输入：s = "abaccdeff"
     * 输出：'b'
     *
     * 示例 2:
     * 输入：s = ""
     * 输出：' '
     *
     * 限制：
     * 0 <= s 的长度 <= 50000
     * @param s
     * @return
     */
    public static char firstUniqChar(String s) {
        if (s.equals("")){
            return ' ';
        }
        LinkedHashMap<Character, Integer> map = new LinkedHashMap<>();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (map.containsKey(c)){
                map.put(c, map.get(c) + 1);
            }else {
                map.put(c, 1);
            }
        }
        for (Map.Entry<Character, Integer> entry : map.entrySet()) {
            if (entry.getValue() == 1){
                return entry.getKey();
            }
        }
        return ' ';
    }
    public static char firstUniqChar2(String s){
        if (s.equals("")){
            return ' ';
        }
        Map<Character, Boolean> map = new HashMap<>();
        char[] chars = s.toCharArray();
        for (char aChar : chars) {
            map.put(aChar, !map.containsKey(aChar));
        }
        for (char aChar : chars) {
            if (map.get(aChar)){
                return aChar;
            }
        }
        return ' ';
    }

    public static char firstUniqChar3(String s){
        int[] arr = new int[26];
        char[] chars = s.toCharArray();
        for (char ch : chars){
            arr[ch -'a'] ++;
        }
        for (char c:chars){
            if (arr[c-'a'] == 1){
                return c;
            }
        }
        return ' ';
    }

    public static void main(String[] args) {
        char c = firstUniqChar3("leetcode");
        System.out.println(c);


        System.out.println('c'-'a');
    }
}
