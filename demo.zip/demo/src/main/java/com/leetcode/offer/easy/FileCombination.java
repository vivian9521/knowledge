package com.leetcode.offer.easy;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * @Auther:vivian
 * @Description:LCR 180. 文件组合
 * 待传输文件被切分成多个部分，按照原排列顺序，每部分文件编号均为一个 正整数（至少含有两个文件）。
 * 传输要求为：连续文件编号总和为接收方指定数字 target 的所有文件。请返回所有符合该要求的文件传输组合列表。
 *
 * 注意，返回时需遵循以下规则：
 * 每种组合按照文件编号 升序 排列；
 * 不同组合按照第一个文件编号 升序 排列。
 * @Date:Created in 2023/10/18
 * @Modified By:
 * @since DK 1.8
 */
public class FileCombination {
    /**
     * 示例 1：
     *
     * 输入：target = 12
     * 输出：[[3, 4, 5]]
     * 解释：在上述示例中，存在一个连续正整数序列的和为 12，为 [3, 4, 5]。
     * 示例 2：
     *
     * 输入：target = 18
     * 输出：[[3,4,5,6],[5,6,7]]
     * 解释：在上述示例中，存在两个连续正整数序列的和分别为 18，分别为 [3, 4, 5, 6] 和 [5, 6, 7]。
     *
     * @param target
     * @return
     */
    /**
     * 滑动窗口
     * @param target
     * @return
     */
    public int[][] fileCombination2(int target) {
        int i = 1, j = 2, s = 3;
        List<int[]> list = new ArrayList<>();
        while (i < j){
            if (s == target){
                int[] arr = new int[j - i + 1];
                for (int i1 = 0; i1 < j - i + 1; i1++) {
                    arr[i1] = i + i1;
                }
                list.add(arr);
            }
            if (s < target){
                j++;
                s +=j;
            }else if (s >= target){
                s -= i;
                i++;
            }
        }
        return list.toArray(new int[0][]);
    }
    /**
     * 数字计算
     * @param target
     * @return
     */
    public int[][] fileCombination(int target) {
        int count = 1, c = 0, x = 0, total = 0;
        Map<Integer,Integer> map = new TreeMap<>();
        while (total < target){
            int remain = (target - total) % count;
            int start = (target - total) / count;
            if (remain == 0 && count != 1){
                map.put(start, count);
                c++;
            }
            x += 1;
            total += x;
            count++;
        }
        int[][] res = new int[c][];
        int i = 0;
        for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
            int[] arr = new int[entry.getValue()];
            for (int j = 0; j < entry.getValue(); j++) {
                arr[j] = entry.getKey() + j;
            }
            res[i] = arr;
            i++;
        }
        return res;
    }

    public static void main(String[] args) {
        FileCombination fileCombination = new FileCombination();
        int[][] ints = fileCombination.fileCombination2(18);
        for (int[] anInt : ints) {
            for (int i : anInt) {
                System.out.print(i);
            }
            System.out.println();
        }

    }

}
