package com.leetcode.offer.hard;

import java.util.Arrays;
import java.util.Deque;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

/**
 * @Auther:vivian
 * @Description:剑指 Offer 59 - I. 滑动窗口的最大值
 * 给定一个数组 nums 和滑动窗口的大小 k，请找出所有滑动窗口里的最大值。
 * @Date:Created in 2023/9/15
 * @Modified By:
 * @since DK 1.8
 */
public class MaxSlidingWindow {
    /**
     * 示例:
     *
     * 输入: nums = [1,3,-1,-3,5,3,6,7], 和 k = 3
     * 输出: [3,3,5,5,6,7]
     * 解释:
     *
     *   滑动窗口的位置                最大值
     * ---------------               -----
     * [1  3  -1] -3  5  3  6  7       3
     *  1 [3  -1  -3] 5  3  6  7       3
     *  1  3 [-1  -3  5] 3  6  7       5
     *  1  3  -1 [-3  5  3] 6  7       5
     *  1  3  -1  -3 [5  3  6] 7       6
     *  1  3  -1  -3  5 [3  6  7]      7
     * @param nums
     * @param k
     * @return
     */
//    public static int[] maxSlidingWindow2(int[] nums, int k) {
//        if(nums.length == 0 || k == 0) return new int[0];
//        Deque<Integer> deque = new LinkedList<>();
//        int[] res = new int[nums.length - k + 1];
//        for(int j = 0, i = 1 - k; j < nums.length; i++, j++) {
//            // 删除 deque 中对应的 nums[i-1]
//            if(i > 0 && deque.peekFirst() == nums[i - 1])
//                deque.removeFirst();
//            // 保持 deque 递减
//            while(!deque.isEmpty() && deque.peekLast() < nums[j])
//                deque.removeLast();
//            deque.addLast(nums[j]);
//            // 记录窗口最大值
//            if(i >= 0)
//                res[i] = deque.peekFirst();
//        }
//        return res;
//    }

    /**
     * 初始化： 双端队列 dequedequedeque ，结果列表 resresres ，数组长度 nnn ；
     * 滑动窗口： 左边界范围 i∈[1−k,n−k]，右边界范围 j∈[0,n−1] ；
     * 若 i>0 且 队首元素 deque[0] =被删除元素 nums[i−1] ：则队首元素出队；
     * 删除 deque 内所有 <nums[j] 的元素，以保持 deque 递减；
     * 将 nums[j] 添加至 deque 尾部；
     * 若已形成窗口（即 i≥0）：将窗口最大值（即队首元素 deque[0] ）添加至列表 res；
     * 返回值： 返回结果列表 res ；
     * @param nums
     * @param k
     * @return
     */
    public int[] maxSlidingWindow4(int[] nums, int k) {
        if (nums.length == 0 || k ==0){
            return new int[0];
        }
        LinkedList<Integer> deque = new LinkedList<>();
        int[] res = new int[nums.length - k + 1];
        //未形成窗口
        for (int i = 0; i < k; i++) {
            while (!deque.isEmpty() && deque.peekLast() < nums[i]){
                deque.removeLast();
            }
            deque.addLast(nums[i]);
        }
        res[0] = deque.peekFirst();
        //形成窗口后
        //删除前一个元素，最后一个元素往后移动一个
        for (int i = k; i < nums.length; i++) {
            //前一个元素 i - k
            if (deque.peekFirst() == nums[i-k]){
                deque.removeFirst();
            }
            while (!deque.isEmpty() && deque.peekLast() < nums[i]){
                deque.removeLast();
            }
            deque.addLast(nums[i]);
            res[i - k + 1] = deque.peekFirst();
        }
        return res;
    }
    public static int[] maxSlidingWindow(int[] nums, int k) {
        if (nums.length == 0){
            return new int[0];
        }
        int[] arr = new int[nums.length - k + 1];
        LinkedList<Integer> queue = new LinkedList<>();
        int begin = 0;
        int end = k-1;
        int index = 0;
        while (end <= nums.length - 1){
            for (int i = begin; i <= end; i++) {
                queue.add(nums[i]);
            }
            int max = queue.getFirst();
            while (!queue.isEmpty()){
                max = queue.getFirst() > max ? queue.getFirst() : max;
                queue.remove();
            }
            arr[index++] = max;
            begin++;
            end++;
        }
        return arr;
    }

    public static void main(String[] args) {
//        int[] arr = new int[]{1,3,-1,-3,5,3,6,7};
        int[] arr = new int[]{1,-1};

        int[] ints = maxSlidingWindow(arr, 1);
        Arrays.stream(ints).forEach(System.out::println);

    }
}
