package com.leetcode.offer.mid;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:LCR 185. 统计结果概率
 * 你选择掷出 num 个色子，请返回所有点数总和的概率。
 *
 * 你需要用一个浮点数数组返回答案，其中第 i 个元素代表这 num 个骰子所能掷出的点数集合中第 i 小的那个的概率。
 * @Date:Created in 2023/10/20
 * @Modified By:
 * @since DK 1.8
 */
public class StatisticsProbability {
    /**
     * 示例 1：
     *
     * 输入：num = 3
     * 输出：[0.00463,0.01389,0.02778,0.04630,0.06944,0.09722,0.11574,0.12500,0.12500,0.11574,0.09722,0.06944,
     * 0.04630,0.02778,0.01389,0.00463]
     * 示例 2：
     *
     * 输入：num = 5
     * 输出:[0.00013,0.00064,0.00193,0.00450,0.00900,0.01620,0.02636,0.03922,0.05401,0.06944,0.08372,0.09452,
     * 0.10031,0.10031,0.09452,0.08372,0.06944,0.05401,0.03922,0.02636,0.01620,0.00900,0.00450,0.00193,0.00064,0.00013]
     * @param num
     * @return
     */
    public double[] statisticsProbability(int num) {
        double[] dp = new double[6];
        Arrays.fill(dp, 1.0/6.0);
        for (int i = 2; i <= num; i++) {
            double[] temp = new double[5 * i + 1];
            for (int j = 0; j < dp.length; j++) {
                for (int k = 0; k < 6; k++) {
                    temp[j + k] += dp[j]/6.0;
                }
            }
            dp = temp;
        }
        return dp;
    }
}
