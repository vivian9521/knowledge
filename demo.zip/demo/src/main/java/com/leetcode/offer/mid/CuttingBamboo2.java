package com.leetcode.offer.mid;

/**
 * @Auther:vivian
 * @Description:LCR 132. 砍竹子 II
 * 现需要将一根长为正整数 bamboo_len 的竹子砍为若干段，每段长度均为 正整数。请返回每段竹子长度的 最大乘积 是多少。
 * 答案需要取模 1e9+7（1000000007），如计算初始结果为：1000000008，请返回 1。
 * @Date:Created in 2023/10/18
 * @Modified By:
 * @since DK 1.8
 */
public class CuttingBamboo2 {

    public int cuttingBamboo(int bamboo_len) {
        if (bamboo_len <= 3){
            return(bamboo_len - 1)%1000000007;
        }
        long c = 1000000007L;
        long res = 1;
        while (bamboo_len > 4){
            res = (res * 3)%c;
            bamboo_len -= 3;
        }
        res = (res * bamboo_len)%c;
        return (int)(res%c);
    }
}
