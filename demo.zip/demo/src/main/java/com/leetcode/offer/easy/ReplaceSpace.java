package com.leetcode.offer.easy;

/**
 * @Auther:vivian
 * @Description:请实现一个函数，把字符串 s 中的每个空格替换成"%20"。
 * @Date:Created in 2023/8/21
 * @Modified By:
 * @since DK 1.8
 */
public class ReplaceSpace {

    public String replaceSpace(String s) {
        return s;
    }

    public static void main(String[] args) {
        String s = "We are  happy.";
        String replace = s.replace(" ", "%20");

        System.out.println(replace);
    }
}
