package com.leetcode.offer.easy;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:剑指 Offer 29. 顺时针打印矩阵
 * 输入一个矩阵，按照从外向里以顺时针的顺序依次打印出每一个数字。
 * @Date:Created in 2023/9/14
 * @Modified By:
 * @since DK 1.8
 */
public class SpiralOrder {
    /**
     * 示例 1：
     *
     * 输入：matrix = [[1,2,3],[4,5,6],[7,8,9]]
     * 输出：[1,2,3,6,9,8,7,4,5]
     * 示例 2：
     *
     * 输入：matrix = [[1,2,3,4],
     *                [5,6,7,8],
     *                [9,10,11,12]]
     * 输出：[1,2,3,4,8,12,11,10,9,5,6,7]
     * @param matrix
     * @return
     */
    public static int[] spiralOrder(int[][] matrix) {
        if (matrix == null || matrix.length == 0){
            return new int[0];
        }
        int left = 0, right = matrix[0].length - 1;
        int top = 0, bottom = matrix.length - 1;
        int[] arr = new int[matrix.length * matrix[0].length];
        int j =0;
        while (true){
            for (int i = left; i <= right; i++){
                arr[j++] = matrix[top][i];
            }
            if (++top > bottom){
                break;
            }
            for (int i = top; i<=bottom; i++){
                arr[j++] = matrix[i][right];
            }
            if (--right < left){
                break;
            }
            for (int i = right; i >= left; i--){
                arr[j++] = matrix[bottom][i];
            }
            if (--bottom < top){
                break;
            }
            for (int i = bottom; i >= top; i--){
                arr[j++] = matrix[i][left];
            }
            if (++left > right){
                break;
            }
        }

        return arr;
    }

    public static void main(String[] args) {
        int[][] arr = new int[][]{new int[]{1,2,3,4}, new int[]{5,6,7,8}, new int[]{9,10,11,12}};
        int[] ints = spiralOrder(arr);
        Arrays.stream(ints).forEach(System.out::println);
    }
}
