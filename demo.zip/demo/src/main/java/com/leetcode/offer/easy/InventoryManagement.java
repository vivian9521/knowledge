package com.leetcode.offer.easy;

import java.util.Arrays;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;

/**
 * @Auther:vivian
 * @Description:LCR 159. 库存管理 III
 * 仓库管理员以数组 stock 形式记录商品库存表，其中 stock[i] 表示对应商品库存余量。
 * 请返回库存余量最少的 cnt 个商品余量，返回 顺序不限。
 * @Date:Created in 2023/10/9
 * @Modified By:
 * @since DK 1.8
 */
public class InventoryManagement {
    /**
     * 示例 1：
     *
     * 输入：stock = [2,5,7,4], cnt = 1
     * 输出：[2]
     * 示例 2：
     *
     * 输入：stock = [0,2,3,6], cnt = 2
     * 输出：[0,2] 或 [2,0]
     * @param stock
     * @param cnt
     * @return
     */
    public int[] inventoryManagement(int[] stock, int cnt) {
        Arrays.sort(stock);
        return Arrays.copyOf(stock, cnt);
    }

    /**
     * 大根堆
     * @param stock
     * @param cnt
     * @return
     */
    public int[] inventoryManagement3(int[] stock, int cnt) {
        PriorityQueue<Integer> queue = new PriorityQueue<>((o1, o2) -> o1 - o2);
        for (int i : stock) {
            queue.offer(i);
        }
        int[] res = new int[cnt];
        for (int i = 0; i < cnt; i++) {
            res[i] = queue.poll();
        }
        return res;
    }
    /**
     * 快速选择
     * 快速排序+如果排序后的哨兵的索引正好是cnt+1则返回结果
     * @param stock
     * @param cnt
     * @return
     */
    public int[] inventoryManagement2(int[] stock, int cnt) {
        if (cnt >= stock.length){
            return stock;
        }
        return sort(stock, cnt, 0 , stock.length - 1);
    }

    private int[] sort(int[] stock, int cnt, int l, int r) {
        int left = l;
        int right = r;
        while (left < right){
            while (left < right && stock[l] <= stock[right]){
                right--;
            }
            while (left < right && stock[l] >= stock[left]){
                left++;
            }
            swap(stock, left, right);
        }
        swap(stock, l, left);
        if (left > cnt){
            return sort(stock, cnt, l, left - 1);
        }
        if (left < cnt){
            return sort(stock, cnt, left + 1, r);
        }
        return Arrays.copyOf(stock, cnt);
    }

    private void swap(int[] stock, int left, int right){
        int temp = stock[left];
        stock[left] = stock[right];
        stock[right] = temp;
    }

    public static void main(String[] args) {
        int[] arr = new int[]{2,5,7,4};
        InventoryManagement inventoryManagement = new InventoryManagement();
        int[] ints = inventoryManagement.inventoryManagement3(arr, 1);

        Arrays.stream(ints).forEach(System.out::println);

    }
}
