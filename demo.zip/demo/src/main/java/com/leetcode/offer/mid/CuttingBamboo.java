package com.leetcode.offer.mid;

/**
 * @Auther:vivian
 * @Description:LCR 131. 砍竹子 I
 * 现需要将一根长为正整数 bamboo_len 的竹子砍为若干段，每段长度均为正整数。
 * 请返回每段竹子长度的最大乘积是多少。

 * @Date:Created in 2023/10/18
 * @Modified By:
 * @since DK 1.8
 */
public class CuttingBamboo {
    /**
     * 示例 1：
     *
     * 输入: bamboo_len = 12
     * 输出: 81
     * @param bamboo_len
     * @return
     */
    //数学推导

    /**
     * 切分规则：
     * 最优： 3 。把竹子尽可能切为多个长度为 3 的片段，留下的最后一段竹子的长度可能为 0,1,2 三种情况。
     * 次优： 2 。若最后一段竹子长度为 2 ；则保留，不再拆为 1+1 。
     * 最差： 1 。若最后一段竹子长度为 1 ；则应把一份 3+1 替换为 2+2，因为 2×2>3×1。
     * @param bamboo_len
     * @return
     */
    public int cuttingBamboo(int bamboo_len) {
        if (bamboo_len <= 3){
            return bamboo_len - 1;
        }
        Double res = 0.0;
        int a = bamboo_len % 3;
        int b = bamboo_len / 3;
        if (a == 0){
            res = Math.pow(3, b);
        }else if (a == 1){
            res = Math.pow(3, b-1) * 4;
        }else {
            res = Math.pow(3, b) * 2;
        }
        return res.intValue();
    }
}
