package com.leetcode.offer.easy;

import java.util.HashMap;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:LCR 158. 库存管理 II
 * 仓库管理员以数组 stock 形式记录商品库存表。stock[i] 表示商品 id，可能存在重复。
 * 请返回库存表中数量大于 stock.length / 2 的商品 id。
 * @Date:Created in 2023/10/18
 * @Modified By:
 * @since DK 1.8
 */
public class InventoryManagement2 {
    /**
     * 哈希表统计法： 遍历数组 stock ，用 HashMap 统计各数字的数量，即可找出 众数 。此方法时间和空间复杂度均为 O(N) 。
     * 数组排序法： 将数组 stock 排序，数组中点的元素 一定为众数。
     * 摩尔投票法： 核心理念为 票数正负抵消 。此方法时间和空间复杂度分别为 O(N) 和 O(1) ，为本题的最佳解法。
     * @param stock
     * @return
     */
    /**
     * 摩尔投票法
     * @param stock
     * @return
     */
    public int inventoryManagement2(int[] stock) {
        int x = 0, votes = 0, count = 0;
        for (int value : stock) {
            if (votes == 0){
                x = value;
            }
            if (x == value){
                votes += 1;
            }else {
                votes -= 1;
            }
        }

        for (int value : stock) {
            if (x == value){
                count ++;
            }
        }
        return count > stock.length/2 ? x : 0;
    }
    /**
     * 哈希表统计法
     * @param stock
     * @return
     */
    public int inventoryManagement(int[] stock) {
        int i = stock.length / 2;
        Map<Integer, Integer> map = new HashMap<>();
        for (int i1 : stock) {
            map.put(i1, map.containsKey(i1) ? map.get(i1) + 1 : 1);
            if (map.get(i1) > i){
                return i1;
            }
        }
        return -1;
    }

    public static void main(String[] args) {
        InventoryManagement2 management2 = new InventoryManagement2();
        int i = management2.inventoryManagement(new int[]{2,2,1,1,1,2,2});
        System.out.println(i);
    }
}
