package com.leetcode.offer.easy;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:LCR 135. 报数
 * 实现一个十进制数字报数程序，请按照数字从小到大的顺序返回一个证书数列，该数列从数字 1 开始，
 * 到最大的正整数 cnt 位数字结束。
 * @Date:Created in 2023/10/7
 * @Modified By:
 * @since DK 1.8
 */
public class CountNumbers {

    /**
     * 输入：cnt = 2
     * 输出：[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,
     * 25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,
     * 50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76
     * ,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99]
     * @param cnt
     * @return
     */
    public int[] countNumbers(int cnt) {
        int count = 0;
        for (int i = 1; i <= cnt; i++) {
            count = count * 10 + 9;
        }

        int[] res = new int[count];
        for (int i = 0; i < count; i++) {
            res[i] = i + 1;
        }
        return res;
    }

    char[] num;
    char[] loop = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
    int[] res;
    int cnt;
    int count = 0;
    public int[] countNumbers2(int cnt) {
        this.cnt = cnt;
        res = new int[(int) (Math.pow(10, cnt) - 1)];
        num = new char[cnt];
        dfs(0);
        return res;
    }


    private void dfs(int x){
        if (x == cnt){
            String s = String.valueOf(num);
            int i = Integer.parseInt(s);
            if (i != 0){
                res[count++] = i;
            }
            return;
        }

        for (char c : loop) {
            num[x] = c;
            dfs(x + 1);
        }
    }

    public static void main(String[] args) {
        CountNumbers numbers = new CountNumbers();
        int[] ints = numbers.countNumbers2(2);
        Arrays.stream(ints).forEach(System.out::print);
    }
}
