package com.leetcode.offer.easy;

import java.util.LinkedList;
import java.util.Stack;

/**
 * @Auther:vivian
 * @Description:剑指 Offer 30. 包含min函数的栈
 * 定义栈的数据结构，请在该类型中实现一个能够得到栈的最小元素的 min 函数在该栈中，
 * 调用 min、push 及 pop 的时间复杂度都是 O(1)。
 *
 *
 * @Date:Created in 2023/9/13
 * @Modified By:
 * @since DK 1.8
 */
public class MinStack2 {
    /**
     * 算法
     * 按照上面的思路，我们只需要设计一个数据结构，使得每个元素 a 与其相应的最小值 m 时刻保持一一对应。
     * 因此我们可以使用一个辅助栈，与元素栈同步插入与删除，用于存储与每个元素对应的最小值。
     * 当一个元素要入栈时，我们取当前辅助栈的栈顶存储的最小值，与当前元素比较得出最小值，将这个最小值插入辅助栈中；
     * 当一个元素要出栈时，我们把辅助栈的栈顶元素也一并弹出；
     * 在任意一个时刻，栈内元素的最小值就存储在辅助栈的栈顶元素中。
     */

    private final LinkedList<Integer> stack;

    private final LinkedList<Integer> minStack;
    public MinStack2() {
        stack = new LinkedList<>();
        minStack = new LinkedList<>();
    }

    public void push(int x) {
        if (minStack.isEmpty() || minStack.peek() >= x){
            minStack.push(x);
        }
        stack.push(x);
    }

    public void pop() {
        if (stack.pop().equals(minStack.peek())){
            minStack.pop();
        }
    }

    public int top() {
        return stack.peek();
    }

    public int min() {
        return minStack.peek();
    }
}
