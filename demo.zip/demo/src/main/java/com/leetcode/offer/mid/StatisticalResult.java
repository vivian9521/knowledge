package com.leetcode.offer.mid;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:LCR 191. 按规则计算统计结果
 * 为了深入了解这些生物群体的生态特征，你们进行了大量的实地观察和数据采集。
 * 数组 arrayA 记录了各个生物群体数量数据，其中 arrayA[i] 表示第 i 个生物群体的数量。
 * 请返回一个数组 arrayB，该数组为基于数组 arrayA 中的数据计算得出的结果，
 * 其中 arrayB[i] 表示将第 i 个生物群体的数量从总体中排除后的其他数量的乘积。
 *
 * @Date:Created in 2023/10/18
 * @Modified By:
 * @since DK 1.8
 */
public class StatisticalResult {
    /**
     * 输入：arrayA = [2, 4, 6, 8, 10]
     * 输出：[1920, 960, 640, 480, 384]
     * @param arrayA
     * @return
     */
    public int[] statisticalResult2(int[] arrayA) {
        if (arrayA == null || arrayA.length == 0){
            return new int[0];
        }
        int len = arrayA.length;
        int[] arrB = new int[arrayA.length];
        arrB[0] = 1;
        //下三角
        for (int i = 1; i < len; i++) {
            arrB[i] = arrB[i - 1] * arrayA[i - 1];
        }
        //上三角
        int temp = 1;
        for (int i = len - 2; i >= 0; i--) {
            temp *= arrayA[i + 1];
            arrB[i] = arrB[i] * temp;
        }
        return arrB;
    }
    //暴力解法（超时）
    public int[] statisticalResult(int[] arrayA) {
        if (arrayA == null || arrayA.length == 0){
            return new int[0];
        }
        int[] arrB = new int[arrayA.length];
        for (int i = 0; i < arrayA.length; i++) {
            int temp = 1;
            for (int j = 0; j < arrayA.length; j++) {
                if (i == j){
                    continue;
                }
                temp *= arrayA[j];
            }
            arrB[i] = temp;
        }
        return arrB;
    }

    public static void main(String[] args) {
        StatisticalResult statisticalResult = new StatisticalResult();
        int[] ints = statisticalResult.statisticalResult2(new int[]{2, 4, 6, 8, 10});
        Arrays.stream(ints).forEach(System.out::println);
    }
}
