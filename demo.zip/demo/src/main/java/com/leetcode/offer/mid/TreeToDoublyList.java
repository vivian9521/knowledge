package com.leetcode.offer.mid;

import com.leetcode.TreeNode;

/**
 * @Auther:vivian
 * @Description:LCR 155. 将二叉搜索树转化为排序的双向链表
 * 将一个 二叉搜索树 就地转化为一个 已排序的双向循环链表 。
 *
 * 对于双向循环列表，你可以将左右孩子指针作为双向循环链表的前驱和后继指针，第一个节点的前驱是最后一个节点，
 * 最后一个节点的后继是第一个节点。
 *
 * 特别地，我们希望可以 就地 完成转换操作。当转化完成以后，树中节点的左指针需要指向前驱，
 * 树中节点的右指针需要指向后继。还需要返回链表中最小元素的指针。
 * @Date:Created in 2023/9/26
 * @Modified By:
 * @since DK 1.8
 */
public class TreeToDoublyList {
    /**
     * 输入：root = [4,2,5,1,3]
     * 输出：[1,2,3,4,5]
     * @param root
     * @return
     */
    //二叉搜索树采用中序遍历即可排序
    TreeNode head, pre;
    public TreeNode treeToDoublyList(TreeNode root) {
        if (root == null){
            return null;
        }
        dfs(root);
        head.left = pre;
        pre.right = head;
        return head;
    }

    private void dfs(TreeNode cur){
        if (cur == null){
            return;
        }
        dfs(cur.left);
        if (pre != null){
            pre.right = cur;
        }else {
            head = cur;
        }
        cur.left = pre;
        pre = cur;
        dfs(cur.right);
    }
    public static void main(String[] args) {
        TreeToDoublyList treeToDoublyList = new TreeToDoublyList();
        TreeNode node = treeToDoublyList.treeToDoublyList(new TreeNode(4, new TreeNode(2, new TreeNode(1), new TreeNode(3)), new TreeNode(5)));

    }

}
