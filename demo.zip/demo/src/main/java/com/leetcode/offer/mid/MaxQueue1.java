package com.leetcode.offer.mid;

import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

/**
 * @Auther:vivian
 * @Description:剑指 Offer 59 - II. 队列的最大值
 * 请定义一个队列并实现函数 max_value 得到队列里的最大值，
 * 要求函数max_value、push_back 和 pop_front 的均摊时间复杂度都是O(1)。
 *
 * 若队列为空，pop_front 和 max_value 需要返回 -1
 * @Date:Created in 2023/9/13
 * @Modified By:
 * @since DK 1.8
 */
public class MaxQueue1 {

    private final List<Integer> list ;

    //暴力破解法
    public MaxQueue1() {
       list = new ArrayList<>();
    }

    public int max_value() {
        if (list.size() == 0){
            return -1;
        }
        int max = 0;
        for (Integer integer : list) {
            max = Math.max(integer, max);
        }
        return max;
    }

    public void push_back(int value) {
        list.add(value);
    }

    public int pop_front() {
        if (list.size() == 0){
            return -1;
        }
        return list.remove(0);
    }
}
