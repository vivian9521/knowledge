package com.leetcode.offer.mid;

/**
 * @Auther:vivian
 * @Description:LCR 152. 验证二叉搜索树的后序遍历序列
 * 请实现一个函数来判断整数数组 postorder 是否为二叉搜索树的后序遍历结果。
 * @Date:Created in 2023/10/9
 * @Modified By:
 * @since DK 1.8
 */
public class VerifyTreeOrder {

    public boolean verifyTreeOrder(int[] postorder) {
        return recur(postorder, 0, postorder.length - 1);
    }
    boolean recur(int[] postorder, int left, int root) {
        if (left >= root){
            return true;
        }
        int p = postorder[root];
        //左侧树——> 一直遍历比根节点值小的数
        int l = left;
        while (postorder[l] < p){
            l++;
        }
        //判断是否二叉树->遍历比根节点值大的数，l == root ,则是二叉树
        int r = l;
        while (postorder[r] > p){
            r++;
        }
        return r == root && recur(postorder, left, l - 1) && recur(postorder, l, root-1);
    }

    public static void main(String[] args) {
        VerifyTreeOrder verifyTreeOrder = new VerifyTreeOrder();
        boolean b = verifyTreeOrder.verifyTreeOrder(new int[]{1, 2, 3, 6, 5});
        System.out.println(b);
    }
}
