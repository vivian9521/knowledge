package com.leetcode.offer.easy;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * @Auther:vivian
 * @Description:剑指 Offer 03. 数组中重复的数字
 * 找出数组中重复的数字。
 * 在一个长度为 n 的数组 nums 里的所有数字都在 0～n-1 的范围内。
 * 数组中某些数字是重复的，但不知道有几个数字重复了，也不知道每个数字重复了几次。请找出数组中任意一个重复的数字。
 * 2 <= n <= 100000
 * @Date:Created in 2023/9/18
 * @Modified By:
 * @since DK 1.8
 */
public class FindRepeatNumber {
    /**
     * 示例 1：
     *
     * 输入：
     * [2, 3, 1, 0, 2, 5, 3]
     * 输出：2 或 3
     * @param nums
     * @return
     */
    public static int findRepeatNumber(int[] nums) {
        int n = nums.length;
        if (n == 2){
            return nums[0];
        }
        Set<Integer> set = new HashSet<>();
        for (int num : nums) {
            if (set.contains(num)) {
                return num;
            } else {
                set.add(num);
            }
        }
        return 0;
    }

    /**
     * 交换算法
     * 算法流程：
     * 遍历数组 nums ，设索引初始值为 i=0 :
     * 若 nums[i]=i ： 说明此数字已在对应索引位置，无需交换，因此跳过；
     * 若 nums[nums[i]]=nums[i]： 代表索引 nums[i] 处和索引 iii 处的元素值都为 nums[i] ，
     * 即找到一组重复值，返回此值 nums[i] ；
     * 否则： 交换索引为 i 和 nums[i] 的元素值，将此数字交换至对应索引位置。
     * 若遍历完毕尚未返回，则返回 −1 。
     * @param nums
     * @return
     */
    public static int findRepeatNumber2(int[] nums) {
        int i = 0;
        while (i < nums.length){
            if (nums[i] == i){
                i++;
                continue;
            }
            if (nums[nums[i]] == nums[i]){
                return nums[i];
            }
            int temp = nums[i];
            nums[i] = nums[temp];
            nums[temp] = temp;
        }
        return -1;
    }
    public static void main(String[] args) {

    }
}
