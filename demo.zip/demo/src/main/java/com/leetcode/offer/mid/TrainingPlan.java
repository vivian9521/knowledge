package com.leetcode.offer.mid;

import java.security.Key;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * @Auther:vivian
 * @Description:LCR 178. 训练计划 VI
 * 教学过程中，教练示范一次，学员跟做三次。该过程被混乱剪辑后，记录于数组 actions，
 * 其中 actions[i] 表示做出该动作的人员编号。请返回教练的编号。
 * @Date:Created in 2023/10/18
 * @Modified By:
 * @since DK 1.8
 */
public class TrainingPlan {
    /**
     * 示例 1：
     *
     * 输入：actions = [5, 7, 5, 5]
     * 输出：7
     * 示例 2：
     *
     * 输入：actions = [12, 1, 6, 12, 6, 12, 6]
     * 输出：1iceBreakingGame
     * @param actions
     * @return
     */
    /**
     * 考虑数字的二进制形式，对于出现三次的数字，各 二进制位 出现的次数都是 3 的倍数。
     * 因此，统计所有数字的各二进制位中 1 的出现次数，并对 3 求余，结果则为只出现一次的数字。
     * @param actions
     * @return
     */
    public int trainingPlan2(int[] actions) {
        //统计所有数字的各二进制位中 1 的出现次数
        int[] counts = new int[32];
        for (int action : actions) {
            for (int i = 31; i >= 0; i--) {
                if ((action & 1) == 1){
                    counts[i] += 1;
                }
                action >>>= 1;
            }
        }
        //对 3 求余
        int res = 0;
        for (int count : counts) {
            res <<= 1;
            res += count % 3;
        }
        return res;
    }

    public static void main(String[] args) {

    }
    public int trainingPlan(int[] actions) {
        if (actions == null || actions.length == 0){
            return -1;
        }
        Map<Integer, Integer> map = new HashMap<>();
        for (int action : actions) {
            map.put(action, !map.containsKey(action) ? 1 : map.get(action) + 1);
        }
        for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
            if (entry.getValue() == 1){
                return entry.getKey();
            }
        }
        return -1;
    }
}
