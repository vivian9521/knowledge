package com.leetcode.offer.easy;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:LCR 187. 破冰游戏
 * 社团共有 num 为成员参与破冰游戏，编号为 0 ~ num-1。成员们按照编号顺序围绕圆桌而坐。
 * 社长抽取一个数字 target，从 0 号成员起开始计数，排在第 target 位的成员离开圆桌，
 * 且成员离开后从下一个成员开始计数。请返回游戏结束时最后一位成员的编号。
 * @Date:Created in 2023/10/18
 * @Modified By:
 * @since DK 1.8
 */
public class IceBreakingGame {
    /**
     * 示例 1：
     *
     * 输入：num = 7, target = 4
     * 输出：1
     * 示例 2：
     *
     * 输入：num = 12, target = 5
     * 输出：0
     * @param num
     * @param target
     * @return
     */
    /**
     * 下面将讲解怎么推导这个公式。
     *
     * 问题1：假设我们已经知道11个人时，胜利者的下标位置为6。那下一轮10个人时，胜利者的下标位置为多少？
     * 答：其实吧，第一轮删掉编号为3的人后，之后的人都往前面移动了3位，胜利者也往前移动了3位，所以他的下标位置由6变成3。
     *
     * 问题2：假设我们已经知道10个人时，胜利者的下标位置为3。那下一轮11个人时，胜利者的下标位置为多少？
     * 答：这可以看错是上一个问题的逆过程，大家都往后移动3位，所以f(11,3)=f(10,3)+3。不过有可能数组会越界，
     * 所以最后模上当前人数的个数，f(11,3)=（f(10,3)+3）%11
     *
     * 问题3：现在改为人数改为N，报到M时，把那个人杀掉，那么数组是怎么移动的？
     * 答：每杀掉一个人，下一个人成为头，相当于把数组向前移动M位。若已知N-1个人时，胜利者的下标位置位f(N−1,M)，
     * 则N个人的时候，就是往后移动M为，
     * (因为有可能数组越界，超过的部分会被接到头上，所以还要模N)，既f(N,M)=(f(N−1,M)+M)%n
     *
     * 注：理解这个递推式的核心在于关注胜利者的下标位置是怎么变的。每杀掉一个人，其实就是把这个数组向前移动了M位。
     * 然后逆过来，就可以得到这个递推式。
     * @param num
     * @param target
     * @return
     */
    public int iceBreakingGame(int num, int target) {
       int res = 0;
        for (int i = 2; i <= num; i++) {
            res = (res + target)%i;
        }
        return res;
    }
}
