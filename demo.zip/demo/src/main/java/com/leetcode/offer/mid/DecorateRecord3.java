package com.leetcode.offer.mid;

import com.leetcode.TreeNode;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:LCR 151. 彩灯装饰记录 III
 *一棵圣诞树记作根节点为 root 的二叉树，节点值为该位置装饰彩灯的颜色编号。请按照如下规则记录彩灯装饰结果：
 * 第一层按照从左到右的顺序记录
 * 除第一层外每一层的记录顺序均与上一层相反。即第一层为从左到右，第二层为从右到左。
 * @Date:Created in 2023/9/21
 * @Modified By:
 * @since DK 1.8
 */
public class DecorateRecord3 {
    /**
     * 输入：root = [8,17,21,18,null,null,6]
     * 输出：[[8],[21,17],[18,6]]
     * @param root
     * @return
     */
    //层序遍历 + 双端队列
    public List<List<Integer>> decorateRecord(TreeNode root) {
        if (root == null){
            return new ArrayList<>();
        }
        List<List<Integer>> res = new ArrayList<>();

        LinkedList<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        while (!queue.isEmpty()){
            int n = queue.size();
            LinkedList<Integer> temp = new LinkedList<>();
            for (int i = 0; i < n; i++) {
                TreeNode node = queue.poll();
                if (res.size() % 2 == 0){
                    temp.addLast(node.val);
                }else {
                    temp.addFirst(node.val);
                }
                if (node.left != null){
                    queue.offer(node.left);
                }
                if (node.right != null){
                    queue.offer(node.right);
                }
            }
            res.add(temp);
        }
        return res;
    }
}
