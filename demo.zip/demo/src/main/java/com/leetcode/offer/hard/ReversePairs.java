package com.leetcode.offer.hard;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:LCR 170. 交易逆序对的总数
 * 在股票交易中，如果前一天的股价高于后一天的股价，则可以认为存在一个「交易逆序对」。请设计一个程序，
 * 输入一段时间内的股票交易记录 record，返回其中存在的「交易逆序对」总数。
 * @Date:Created in 2023/10/12
 * @Modified By:
 * @since DK 1.8
 */
public class ReversePairs {
    /**
     * 示例 1:
     *
     * 输入：record = [9, 7, 5, 4, 6]
     * 输出：8
     * 解释：交易中的逆序对为 (9, 7), (9, 5), (9, 4), (9, 6), (7, 5), (7, 4), (7, 6), (5, 4)。
     * @param record
     * @return
     */
    /**
     * 归并排序
     * @Description:LCR 170. 交易逆序对的总数
     * 在股票交易中，如果前一天的股价高于后一天的股价，则可以认为存在一个「交易逆序对」。请设计一个程序，
     * 输入一段时间内的股票交易记录 record，返回其中存在的「交易逆序对」总数。
     * @Date:Created in 2023/10/12
     * @param record
     * @return
     */
    int num = 0;
    public int reversePairs2(int[] record) {
        if(record == null || record.length == 0){
            return 0;
        }
        sort(record, 0 , record.length - 1);
        return num;
    }

    private void sort(int[] record, int L, int R){
        if (L == R){
            return;
        }
        int mid = (L + R)/2;
        sort(record, L, mid);
        sort(record, mid + 1, R);
        merge(record, L, mid, R);
    }

    private void merge(int[] record, int L, int M, int R){
        int[] help = new int[R - L + 1];
        int i = 0;
        int p1 = L;
        int p2 = M + 1;
        while (p1 <= M && p2 <= R){
            if (record[p1] > record[p2]){
                num += M - p1 + 1;
                help[i++] = record[p2++];
            }else {
                help[i++] = record[p1++];
            }
        }
        while (p1 <= M){
            help[i++] = record[p1++];
        }
        while (p2 <= R){
            help[i++] = record[p2++];
        }
        //原数组赋排序后的值
        for (int j = 0; j < help.length; j++) {
            record[L + j] = help[j];
        }
    }
    public int reversePairs(int[] record) {
        int num = 0;
        for (int i = 0; i < record.length; i++) {
            for (int j = i + 1; j < record.length; j++) {
                if (record[i] > record[j]){
                    num++;
                }
            }
        }
        return num;
    }

    public static void main(String[] args) {
        ReversePairs reversePairs = new ReversePairs();
        //2,3,6,7
        int i = reversePairs.reversePairs2(new int[]{9, 7, 5, 4, 6});
        System.out.println(i);
    }
}
