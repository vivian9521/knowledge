package com.leetcode.offer.mid;

import com.leetcode.ListNode;
import com.leetcode.Node;

import java.util.HashMap;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:剑指 Offer 35. 复杂链表的复制
 * 请实现 copyRandomList 函数，复制一个复杂链表。在复杂链表中，每个节点除了有一个 next 指针指向下一个节点，还有一个 random 指针指向链表中的任意节点或者 null。
 * @Date:Created in 2023/9/6
 * @Modified By:
 * @since DK 1.8
 */
public class CopyRandomList {

    /**
     * 哈希回溯法
     * 输入：head = [[3,null],[3,0],[3,null]]
     * 输出：[[3,null],[3,0],[3,null]]
     * @param head
     * @return
     */
    /**
     * 回溯+哈希表法
     * 本题要求我们对一个特殊的链表进行深拷贝。如果是普通链表，我们可以直接按照遍历的顺序创建链表节点。
     * 而本题中因为随机指针的存在，当我们拷贝节点时，「当前节点的随机指针指向的节点」可能还没创建，
     * 因此我们需要变换思路。一个可行方案是，我们利用回溯的方式，让每个节点的拷贝操作相互独立。
     * 对于当前节点，我们首先要进行拷贝，然后我们进行「当前节点的后继节点」
     * 和「当前节点的随机指针指向的节点」拷贝，拷贝完成后将创建的新节点的指针返回，
     * 即可完成当前节点的两指针的赋值。
     *)
     * 具体地，我们用哈希表记录每一个节点对应新节点的创建情况。
     * 遍历该链表的过程中，我们检查「当前节点的后继节点」和「当前节点的随机指针指向的节点」的创建情况。
     * 如果这两个节点中的任何一个节点的新节点没有被创建，我们都立刻递归地进行创建。
     * 当我们拷贝完成，回溯到当前层时，我们即可完成当前节点的指针赋值。
     * 注意一个节点可能被多个其他节点指向，因此我们可能递归地多次尝试拷贝某个节点，
     * 为了防止重复拷贝，我们需要首先检查当前节点是否被拷贝过，如果已经拷贝过，
     * 我们可以直接从哈希表中取出拷贝后的节点的指针并返回即可。
     *
     * 在实际代码中，我们需要特别判断给定节点为空节点的情况。
     * @param head
     * @return
     */
    Map<Node,Node> nodeMap = new HashMap<>();
    public  Node copyRandomList(Node head) {
        if (head == null){
            return null;
        }
        if (!nodeMap.containsKey(head)){
            Node node = new Node(head.val);
            nodeMap.put(head, node);
            node.next = copyRandomList(head.next);
            node.random = copyRandomList(head.random);
        }
        return nodeMap.get(head);
    }

    /**
     * 迭代+节点拆分
     * @param head
     * @return
     */
    public  Node copyRandomList1(Node head) {
        if(head == null){
            return null;
        }
        //重复每个node在原node后面，然后拆分
        Node h1 = head;
        //1->2
        //合并 1->1`->2->2`
        while (h1 != null){
            Node temp = h1.next;
            h1.next = new Node(h1.val);
            h1.next.next = temp;
            h1 = h1.next.next;
        }
        //组装random
        Node h2 = head;
        while (h2 != null){
            h2.next.random = h2.random == null ? null : h2.random.next;
            h2 = h2.next.next;
        }
        //拆分
        Node headNew = head.next;
        for (Node node = head; node != null; node = node.next){
            Node temp = node.next;
            node.next = node.next.next;
            temp.next = temp.next != null ? temp.next.next : null;
        }
        return headNew;
    }

    public static void main(String[] args) {
        Node node = new Node(1);
        node.next = new Node(2);
        node.random = node.next;
        node.next.random = node.next;
    }
}
