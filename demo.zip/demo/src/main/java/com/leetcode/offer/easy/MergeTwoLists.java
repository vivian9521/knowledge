package com.leetcode.offer.easy;

import com.leetcode.ListNode;

/**
 * @Auther:vivian
 * @Description:剑指 Offer 25. 合并两个排序的链表
 * @Date:Created in 2023/9/12
 * @Modified By:
 * @since DK 1.8
 */
public class MergeTwoLists {
    /**
     * 输入两个递增排序的链表，合并这两个链表并使新链表中的节点仍然是递增排序的。
     * 示例1：
     * 输入：1->2->4, 1->3->4
     * 输出：1->1->2->3->4->4
     * 1->1->2->4    3->4
     * 1->1->2->3->4 4
     * @param l1
     * @param l2
     * @return
     */
    public static ListNode mergeTwoLists(ListNode l1, ListNode l2) {
        ListNode head = new ListNode(0);
        ListNode res = head;
        ListNode r1 = l1;
        ListNode r2 = l2;
        while (r1 != null || r2 != null){
            if (r1 == null){
                head.next = new ListNode(r2.val);
                head = head.next;
                r2 = r2.next;
            }else if (r2 == null){
                head.next = new ListNode(r1.val);
                head = head.next;
                r1 = r1.next;
            }else {
                int value = Math.min(r1.val, r2.val);
                head.next = new ListNode(value);
                head = head.next;
                if (r1.val >= r2.val){
                    r2 = r2.next;
                }else {
                    r1 = r1.next;
                }
            }
        }
        return res.next;
    }
    public static ListNode mergeTwoLists3(ListNode l1, ListNode l2){
        ListNode head = new ListNode(0);
        ListNode res = head;
        ListNode r1 = l1;
        ListNode r2 = l2;
        while (r1 != null && r2 != null){
            int value = Math.min(r1.val, r2.val);
            head.next = new ListNode(value);
            head = head.next;
            if (r1.val >= r2.val){
                r2 = r2.next;
            }else {
                r1 = r1.next;
            }
        }
        head.next = r1 == null ? r2 : r1;
        return res.next;
    }
    /**
     * 递归
     * @param l1
     * @param l2
     * @return
     */
    public static ListNode mergeTwoLists1(ListNode l1, ListNode l2){
        if (l1 == null){
            return l2;
        }else if (l2 == null){
            return l1;
        }else if (l1.val >= l2.val){
            l2.next = mergeTwoLists1(l1, l2.next);
            return l2;
        }else {
            l1.next = mergeTwoLists(l1.next, l2);
            return l1;
        }
    }
    public static void main(String[] args) {
        ListNode node1 = new ListNode(1, new ListNode(2, new ListNode(4)));
        ListNode node2 = new ListNode(1, new ListNode(3, new ListNode(4)));

        ListNode node = mergeTwoLists3(node1, node2);
        ListNode.foreachListNode(node);
    }

}
