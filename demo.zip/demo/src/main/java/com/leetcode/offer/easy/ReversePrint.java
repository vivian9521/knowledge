package com.leetcode.offer.easy;

import com.leetcode.ListNode;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

/**
 * @Auther:vivian
 * @Description:剑指 Offer 06. 从尾到头打印链表
 *输入一个链表的头节点，从尾到头反过来返回每个节点的值（用数组返回）。
 * @Date:Created in 2023/9/6
 * @Modified By:
 * @since DK 1.8
 */
public class ReversePrint {

    public static int[] reversePrint(ListNode head) {
        ListNode res = null;
        ListNode cur = head;
        int i = 0;
        while (cur != null){
            ListNode temp = cur.next;
            cur.next = res;
            res = cur;
            cur = temp;
            i++;
        }
        int[] arr = new int[i];
        for (int j = 0; res!= null; j++){
            arr[j] = res.val;
            res = res.next;
        }
        return arr;
    }

    /**
     * 栈
     * @param head
     * @return
     */
    public int[] reversePrint1(ListNode head) {
        Stack<ListNode> stack = new Stack<ListNode>();
        ListNode temp = head;
        while (temp != null) {
            stack.push(temp);
            temp = temp.next;
        }
        int size = stack.size();
        int[] print = new int[size];
        for (int i = 0; i < size; i++) {
            print[i] = stack.pop().val;
        }
        return print;
    }
    public static void main(String[] args) {
        ListNode head = new ListNode(1, new ListNode(2,new ListNode(3,new ListNode(4,new ListNode(5)))));
        int[] ints = reversePrint(head);
        Arrays.stream(ints).forEach(System.out::println);
    }
}
