package com.leetcode.offer.mid;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Stack;

/**
 * @Auther:vivian
 * @Description:剑指 Offer 31. 栈的压入、弹出序列
 * 输入两个整数序列，第一个序列表示栈的压入顺序，请判断第二个序列是否为该栈的弹出顺序。
 * 假设压入栈的所有数字均不相等。例如，序列 {1,2,3,4,5} 是某栈的压栈序列，
 * 序列 {4,5,3,2,1} 是该压栈序列对应的一个弹出序列，但 {4,3,5,1,2} 就不可能是该压栈序列的弹出序列。
 * @Date:Created in 2023/9/15
 * @Modified By:
 * @since DK 1.8
 */
public class ValidateStackSequences {
    /**
     * 示例 1：
     *
     * 输入：pushed = [1,2,3,4,5], popped = [4,5,3,2,1]
     * 输出：true
     * 解释：我们可以按以下顺序执行：
     * push(1), push(2), push(3), push(4), pop() -> 4,
     * push(5), pop() -> 5, pop() -> 3, pop() -> 2, pop() -> 1
     * 示例 2：
     *
     * 输入：pushed = [1,2,3,4,5], popped = [4,3,5,1,2]
     * 输出：false
     * 解释：1 不能在 2 之前弹出。
     *
     * @param pushed
     * @param popped
     * @return
     */
    /**
     * 辅助栈
     * @param pushed
     * @param popped
     * @return
     */
    public static boolean validateStackSequences1(int[] pushed, int[] popped) {
        Stack<Integer> stack = new Stack<>();
        int i =0;
        for (int num : pushed) {
            stack.push(num);
            while (!stack.isEmpty() && stack.peek().equals(popped[i])){
                stack.pop();
                i++;
            }
        }
        return stack.isEmpty();
    }

    /**
     * 滑动窗口
     * @param pushed
     * @param popped
     * @return
     */
    public boolean validateStackSequences2(int[] pushed, int[] popped) {
        int top = 0;
        int out = 0;
        for(int push : pushed){
            pushed[top] = push;
            while(top>=0&&pushed[top]==popped[out]){
                top--;
                out++;
            }
            top++;
        }
        return top==0;
    }
    public static boolean validateStackSequences(int[] pushed, int[] popped) {
        if (pushed.length == 0 && popped.length == 0){
            return true;
        }
        LinkedList<Integer> pushList = new LinkedList<>();
        LinkedList<Integer> popList = new LinkedList<>();
        for (int i = 0; i < pushed.length; i++) {
            pushList.push(pushed[i]);
            popList.add(popped[i]);
        }
        for (int i = 0; i < pushed.length; i++) {
            if (!pushList.getLast().equals(popList.getFirst())){
                break;
            }
            pushList.removeLast();
            popList.removeFirst();
        }
        //获取第一个pop出数字后面的数字
        while (!pushList.isEmpty()){
            if (popList.getFirst().equals(pushList.peek())){
                break;
            }
            pushList.pop();
        }


        while (!popList.isEmpty()){
            if (pushList.isEmpty()){
                return true;
            }
            if (pushList.peek().equals(popList.peek())){
                pushList.pop();
            }
            popList.removeFirst();
        }
        return pushList.isEmpty();
    }

    public static void main(String[] args) {
//        int[] arr1 = new int[]{4,0,1,2,3};
//        int[] arr2 = new int[]{4,2,3,0,1};
//        int[] arr1 = new int[]{1,2,3,4,5};
//        int[] arr2 = new int[]{4,3,5,2,1};
        int[] arr1 = new int[]{3,2,0,1};
        int[] arr2 = new int[]{1,2,0,3};
//        int[] arr1 = new int[]{2,1,0};
//        int[] arr2 = new int[]{2,1,0};
        boolean b = validateStackSequences1(arr1, arr2);
        System.out.println(b);
    }
}
