package com.leetcode.offer.easy;

import com.design.B;

import java.util.LinkedList;

/**
 * @Auther:vivian
 * @Description:剑指 Offer 09. 用两个栈实现队列
 * 用两个栈实现一个队列。队列的声明如下，请实现它的两个函数 appendTail 和 deleteHead ，
 * 分别完成在队列尾部插入整数和在队列头部删除整数的功能。(若队列中没有元素，deleteHead 操作返回 -1 )
 * @Date:Created in 2023/9/12
 * @Modified By:
 * @since DK 1.8
 */
public class CQueue {
    /**
     * 示例 1：
     *
     * 输入：
     * ["CQueue","appendTail","deleteHead","deleteHead","deleteHead"]
     * [[],[3],[],[],[]]
     * 输出：[null,null,3,-1,-1]
     * 示例 2：
     *
     * 输入：
     * ["CQueue","deleteHead","appendTail","appendTail","deleteHead","deleteHead"]
     * [[],[],[5],[2],[],[]]
     * 输出：[null,-1,null,null,5,2]
     */
    //栈无法实现队列功能： 栈底元素（对应队首元素）无法直接删除，需要将上方所有元素出栈。
    //双栈可实现列表倒序： 设有含三个元素的栈 A=[1,2,3]A = [1,2,3]A=[1,2,3] 和空栈 B=[]B = []B=[]。
    // 若循环执行 AAA 元素出栈并添加入栈 BBB ，直到栈 AAA 为空，则 A=[]A = []A=[] , B=[3,2,1]B = [3,2,1]B=[3,2,1] ，
    // 即 栈 BBB 元素实现栈 AAA 元素倒序 。
    //利用栈 BBB 删除队首元素： 倒序后，BBB 执行出栈则相当于删除了 AAA 的栈底元素，即对应队首元素。
    LinkedList<Integer> A,B;
    public CQueue() {
        A = new LinkedList<>();
        B = new LinkedList<>();
    }

    public void appendTail(int value) {
        A.push(value);
    }

    public int deleteHead() {
        if (!B.isEmpty()){
            return B.pop();
        }
        if (A.isEmpty()){
            return -1;
        }
        while (!A.isEmpty()){
            B.push(A.pop());
        }
        return B.pop();
    }
}
