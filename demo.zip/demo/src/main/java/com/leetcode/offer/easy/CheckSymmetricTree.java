package com.leetcode.offer.easy;

import com.leetcode.TreeNode;

/**
 * @Auther:vivian
 * @Description:LCR 145. 判断对称二叉树
 * 请设计一个函数判断一棵二叉树是否 轴对称 。
 * @Date:Created in 2023/9/25
 * @Modified By:
 * @since DK 1.8
 */
public class CheckSymmetricTree {

    public boolean checkSymmetricTree(TreeNode root) {
        if (root == null){
            return true;
        }
        return check(root.left, root.right);
    }

    private boolean check (TreeNode leftNode, TreeNode rightNode){
        if (leftNode == null && rightNode == null){
            return true;
        }
        if (leftNode == null || rightNode == null){
            return false;
        }
        return (leftNode.val == rightNode.val) && check(leftNode.left, rightNode.right) && check(leftNode.right, rightNode.left);
    }


}
