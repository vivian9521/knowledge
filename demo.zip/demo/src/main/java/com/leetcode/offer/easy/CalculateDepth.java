package com.leetcode.offer.easy;

import com.leetcode.TreeNode;

/**
 * @Auther:vivian
 * @Description:LCR 175. 计算二叉树的深度
 * 某公司架构以二叉树形式记录，请返回该公司的层级数。
 * @Date:Created in 2023/9/27
 * @Modified By:
 * @since DK 1.8
 */
public class CalculateDepth {
    /**
     * 输入：root = [1, 2, 2, 3, null, null, 5, 4, null, null, 4]
     * 输出: 4
     * 解释: 上面示例中的二叉树的最大深度是 4，沿着路径 1 -> 2 -> 3 -> 4 或 1 -> 2 -> 5 -> 4 到达叶节点的最长路径上有 4 个节点。
     * @param root
     * @return
     */
    int max = 0;
    public int calculateDepth(TreeNode root) {
        if (root == null){
            return 0;
        }
        dfs(root, 0);
        return max;
    }
    private void dfs(TreeNode node, int depth){
        if (node == null){
            max = Math.max(max, depth);
            return;
        }
        depth ++;
        dfs(node.left, depth);
        dfs(node.right, depth);
    }

    public int maxDepth1(TreeNode root) {
        if(root == null) return 0;
        return Math.max(maxDepth1(root.left), maxDepth1(root.right)) + 1;
    }


}
