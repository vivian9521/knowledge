package com.leetcode.offer.mid;

import java.util.concurrent.TransferQueue;

/**
 * @Auther:vivian
 * @Description:LCR 130. 衣橱整理
 *家居整理师将待整理衣橱划分为 m x n 的二维矩阵 grid，其中 grid[i][j] 代表一个需要整理的格子。
 * 整理师自 grid[0][0] 开始 逐行逐列 地整理每个格子。
 *
 * 整理规则为：在整理过程中，可以选择 向右移动一格 或 向下移动一格，但不能移动到衣柜之外。
 * 同时，不需要整理 digit(i) + digit(j) > cnt 的格子，其中 digit(x) 表示数字 x 的各数位之和。
 *
 * 请返回整理师 总共需要整理多少个格子。
 * @Date:Created in 2023/9/25
 * @Modified By:
 * @since DK 1.8
 */
public class WardrobeFinishing {
    /**
     * 示例 1：
     *
     * 输入：m = 4, n = 7, cnt = 5
     * 输出：18
     * @param m
     * @param n
     * @param cnt
     * @return
     */
    public int wardrobeFinishing(int m, int n, int cnt) {
        if (cnt == 0){
            return 1;
        }
        int total = 1;
        //每个单元格是否可达
        boolean[][] visit = new boolean[m][n];
        visit[0][0] = true;
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (i == 0 && j == 0){
                    continue;
                }
                if (get(i) + get(j) > cnt){
                    continue;
                }
                //只能向右，向下移动，右前一个或者下的前一个其中一个可达即可
                if (i - 1 >= 0){
                    visit[i][j] |= visit[i-1][j];
                }
                if (j - 1 >= 0){
                    visit[i][j] |= visit[i][j-1];
                }
                total += visit[i][j] ? 1 : 0;
            }
        }
        return total;
    }

    private int get(int num){
        int total = 0;
        while (num != 0){
            int remain = num % 10 ;
            num = num / 10;
            total = total + remain;
        }
        return total;
    }

    public static void main(String[] args) {
        WardrobeFinishing finishing = new WardrobeFinishing();
        int i = finishing.wardrobeFinishing(16, 8, 4);
        System.out.println(i);
    }
}
