package com.leetcode.offer.hard;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

/**
 * @Auther:vivian
 * @Description:LCR 160. 数据流中的中位数
 * 中位数 是有序整数列表中的中间值。如果列表的大小是偶数，则没有中间值，中位数是两个中间值的平均值。
 *
 * 例如，
 * [2,3,4] 的中位数是 3
 * [2,3] 的中位数是 (2 + 3) / 2 = 2.5
 * 设计一个支持以下两种操作的数据结构：
 *
 * void addNum(int num) - 从数据流中添加一个整数到数据结构中。
 * double findMedian() - 返回目前所有元素的中位数。
 * @Date:Created in 2023/10/20
 * @Modified By:
 * @since DK 1.8
 */
public class MedianFinder {

    /**
     * 示例 1：
     *
     * 输入：
     * ["MedianFinder","addNum","addNum","findMedian","addNum","findMedian"]
     * [[],[1],[2],[],[3],[]]
     * 输出：[null,null,null,1.50000,null,2.00000]
     * 示例 2：
     *
     * 输入：
     * ["MedianFinder","addNum","findMedian","addNum","findMedian"]
     * [[],[2],[],[3],[]]
     * 输出：[null,null,2.00000,null,2.50000]
     */


//    List<Integer> list;
    PriorityQueue<Integer> minQueue;
    PriorityQueue<Integer> maxQueue;
    /** initialize your data structure here. */
    public MedianFinder() {
//        list = new ArrayList<>();
        minQueue = new PriorityQueue<>();
        maxQueue = new PriorityQueue<>((o1, o2) -> o2-o1);
    }

    public void addNum(int num) {
        //小顶堆放较大的数，大顶堆放较小的数
        //  12 10  9       8 6 5
        //        堆顶     堆顶
        if (minQueue.size() != maxQueue.size()){
            minQueue.offer(num);
            maxQueue.offer(minQueue.poll());
        }else {
            maxQueue.offer(num);
            minQueue.offer(maxQueue.poll());
        }
//        if (list.size() == 0){
//            list.add(num);
//        }else{
//           int i = 0;
//           int j = list.size() - 1;
//           while (i < j){
//               int m = (i + j)/2;
//               if (list.get(m) > num){
//                   j = m - 1;
//               }else if (list.get(m) < num){
//                   i = m + 1;
//               }else {
//                   list.add(m, num);
//                   return;
//               }
//           }
//            if (list.get(i) < num){
//                if (i + 1 > list.size() - 1){
//                    list.add(num);
//                }else {
//                    list.add(i + 1, num);
//                }
//            }else {
//                list.add(i, num);
//            }
//        }
    }

    public double findMedian() {
        if (minQueue.size() == maxQueue.size()){
            return (minQueue.peek() + maxQueue.peek())/2.0;
        }else {
            return minQueue.peek();
        }
//        int num = (list.size() - 1) / 2;
//        if (list.size() % 2 == 1){
//            return list.get(num);
//        }else {
//            return (list.get(num) + list.get(num + 1))/2.0;
//        }
    }

    public static void main(String[] args) {
        MedianFinder medianFinder = new MedianFinder();
//        medianFinder.addNum(40);
//        medianFinder.addNum(12);
//        medianFinder.addNum(16);
//        medianFinder.addNum(14);
//        medianFinder.addNum(35);
//        medianFinder.addNum(19);
//        medianFinder.addNum(34);
        medianFinder.addNum(3);
        medianFinder.addNum(1);
        medianFinder.addNum(0);
        medianFinder.addNum(0);
        double median = medianFinder.findMedian();
        System.out.println(median);
//        System.out.println(medianFinder.list);


//        median = medianFinder.findMedian();
//        System.out.println(median);
//        System.out.println(medianFinder.list);
    }
}
