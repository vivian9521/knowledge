package com.leetcode.offer.mid;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/9/14
 * @Modified By:
 * @since DK 1.8
 */
public class MaxQueue3 {
    int[] q = new int[20000];
    int begin = 0, end = 0;

    public MaxQueue3() {

    }

    public int max_value() {
        int ans = -1;
        for (int i = begin; i != end; ++i) {
            ans = Math.max(ans, q[i]);
        }
        return ans;
    }

    public void push_back(int value) {
        q[end++] = value;
    }

    public int pop_front() {
        if (begin == end) {
            return -1;
        }
        return q[begin++];
    }
}
