package com.leetcode.mid;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:螺旋矩阵
 * @Date:Created in 2022/11/4
 * @Modified By:
 * @since DK 1.8
 */
public class SpiralOrder {
    public static void main(String[] args) {
        //输入：matrix = [[1,2,3,4],
                     // [5,6,7,8],
                     // [9,10,11,12]]
        //输出：[1,2,3,4,8,12,11,10,9,5,6,7]
        // 8 位置 n + i - 1
        // 5 位置 n - 1 + m + n - 1 + m - i - 1 =  2n + m -2 + m - i - 1 -1 = 2m + 2n -4 -i
        int[][] matrix =
                {{1,2,3,4},
                {5,6,7,8},
                {9,10,11,12}};
//        int[][] matrix = {{3},{2}};
        List<Integer> list = spiralOrder2(matrix);
        System.out.println(list);
    }

    public static List<Integer> spiralOrder3(int[][] matrix){
        if (matrix == null){
            return null;
        }
        List<Integer> list = new ArrayList<>();
        int top = 0; int bottom = matrix[0].length - 1; int left = 0; int right = matrix.length - 1;
        while (top <= bottom  && left <= right){
            for (int i = left; i <= right; i++){
                list.add(matrix[top][i]);
            }
            for (int i = top + 1; i <= bottom; i++){
                list.add(matrix[i][right]);
            }
            if (left < right && top < bottom){
                for (int i = right - 1; i >= left + 1; i--){
                    list.add(matrix[bottom][i]);
                }
                for (int i = bottom; i>= top + 1; i--){
                    list.add(matrix[i][left]);
                }
            }
            left++;
            right--;
            top++;
            bottom--;
        }
        return list;
    }


    /**
     * 按层模拟
     * 给你一个 m 行 n 列的矩阵 matrix ，请按照 顺时针螺旋顺序 ，返回矩阵中的所有元素。
     * @param matrix
     * @return
     */
    public static List<Integer> spiralOrder2(int[][] matrix) {
        if (matrix == null || matrix.length == 0 || matrix[0].length == 0){
            return null;
        }
        List<Integer> res = new ArrayList<>();

        int left = 0; int right = matrix[0].length - 1; int top = 0; int bottom = matrix.length - 1;

        while (left <= right && top <= bottom ){
            //上层(top,left)...(top,right)
            for ( int i = left; i <= right; i++){
                res.add(matrix[top][i]);
            }
            //右层(top+1, right)...(bottom, right)
            for (int i = top + 1; i <= bottom; i++) {
               res.add(matrix[i][right]);
            }
            if (left < right && top < bottom){
                //下层(bottom, right-1)...(bottom,left+1)
                for (int i = right - 1; i >= left + 1; i--) {
                    res.add(matrix[bottom][i]);
                }
                //上层(bottom, left)...(top+1, left)
                for (int i = bottom; i >= top + 1; i--) {
                    res.add(matrix[i][left]);
                }
            }

            left += 1;
            right -= 1;
            top += 1;
            bottom -= 1;
        }
        return res;
    }



    /**
     * 给你一个 m 行 n 列的矩阵 matrix ，请按照 顺时针螺旋顺序 ，返回矩阵中的所有元素。
     * @param matrix
     * @return
     */
    public static List<Integer> spiralOrder(int[][] matrix) {
        if (matrix == null || matrix.length == 0){
            return null;
        }
        List<Integer> list = new ArrayList<>(matrix.length * matrix[0].length);
        int[][] res = addList(matrix, list);
        return list;
    }

    private static int[][] addList(int[][] matrix, List<Integer> list) {
        if (matrix == null || matrix.length == 0){
            return null;
        }
        int m = matrix.length;
        int n = matrix[0].length;
        int[][] matrix2 = new int[m - 2][n - 2];

        for (int i = 0; i < m; i++) {
            int[] arr = matrix[i];
            if (i == 0){
                for (int j = 0; j < arr.length; j++) {
                    list.add(arr[j]);
                }
            }else if ( i == m - 1){
                for (int k = arr.length - 1; k >= 0; k--) {
                    list.add(arr[k]);
                }
            }else {
                for (int l = 0; l < arr.length; l++) {
                    if (l == 0){
                        list.set(2 * m + 2 * n -4 -i, arr[l]);
                    }else if (l == arr.length -1 ){
                        list.set(n + i - 1, arr[l]);
                    }else {
                        matrix2[i - 1][l - 1] = arr[l];
                    }
                }
            }
        }
        return addList(matrix2, list);
    }
}
