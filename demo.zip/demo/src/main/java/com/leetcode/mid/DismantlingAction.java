package com.leetcode.mid;

import com.microsoft.schemas.office.visio.x2012.main.SectionType;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * @Auther:vivian
 * @Description:LCR 167. 招式拆解 I
 * 某套连招动作记作序列 arr，其中 arr[i] 为第 i 个招式的名字。请返回 arr 中最多可以出连续不重复的多少个招式。
 *
 *
 * @Date:Created in 2023/10/16
 * @Modified By:
 * @since DK 1.8
 */
public class DismantlingAction {
    /**
     * 示例 1:
     * f(n) = 未重复 ? f(n) + 1 : f(n)
     * 输入: arr = "dbascDdad"
     * 输出: 6
     * 解释: 因为连续且最长的招式序列是 "dbascD" 或 "bascDd"，所以其长度为 6。
     * 示例 2:
     *
     * 输入: arr = "KKK"
     * 输出: 1
     * 解释: 因为无重复字符的最长子串是 "K"，所以其长度为 1。
     * 示例 3:
     *
     * 输入: arr = "pwwkew"
     * 输出: 3
     * 解释: 因为连续且最长的招式序列是 "wke"，所以其长度为 3。
     * 请注意区分 子串 与 子序列 的概念：你的答案必须是 连续招式 的长度，也就是 子串。而 "pwke" 是一个非连续的 子序列，不是 子串。
     * @param arr
     * @return
     */
    //滑动窗口 + 哈希表
    public int dismantlingAction(String arr) {
        int res = 0;
        char[] chars = arr.toCharArray();
        int j = -1;
        Map<Character, Integer> map = new HashMap<>();
        for (int i = 0; i < chars.length; i++) {
            if (map.containsKey(chars[i])){
                j = Math.max(j, map.get(chars[i]));
            }
            map.put(chars[i], i);

            res = Math.max(res, i - j);
        }
        return res;
    }

    /**
     * 动态规划 + 哈希表
     * @param arr
     * @return
     */
    public int dismantlingAction2(String arr) {
        Map<Character, Integer> dic = new HashMap<>();
        int res = 0, tmp = 0, len = arr.length();
        for(int j = 0; j < len; j++) {
            int i = dic.getOrDefault(arr.charAt(j), -1); // 获取索引 i
            dic.put(arr.charAt(j), j); // 更新哈希表
            tmp = tmp < j - i ? tmp + 1 : j - i; // dp[j - 1] -> dp[j]
            res = Math.max(res, tmp); // max(dp[j - 1], dp[j])
        }
        return res;
    }

}
