package com.leetcode.mid;

import com.leetcode.ListNode;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/9/7
 * @Modified By:
 * @since DK 1.8
 */
public class Test {
    public static void main(String[] args) {
//        String s1 = new String("a");
//        String s2 = new String("a");
//        System.out.println("a" == s1.intern());
//        ListNode head = new ListNode(1, new ListNode(2,new ListNode(3,new ListNode(4,new ListNode(5)))));
//        ListNode node = reverseList(head);
//        ListNode.foreachListNode(node);

        List<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(2);
        list.add(1);
        for (Integer integer : list) {
            if (integer == 1){
                list.remove(integer);
            }
        }
    }

    /**
     * 反转链表
     * @param head
     * @return
     */
    private static ListNode reverseList (ListNode head){
        if (head == null){
            return null;
        }
        ListNode cur = head;
        ListNode res = null;
        while (cur != null){
            ListNode temp = cur.next;
            cur.next = res;
            res = cur;
            cur = temp;
        }
        return res;
    }


}
