package com.leetcode.mid;

import com.leetcode.ListNode;

/**
 * @Auther:vivian
 * @Description:两两交换链表中的节点
 * @Date:Created in 2022/9/15
 * @Modified By:
 * @since DK 1.8
 */
public class SwapPairs {
    public static void main(String[] args) {
        //输入：head = [1,2,3,4]
        //输出：[2,1,4,3]
        ListNode node = swapPairs2(new ListNode(1, new ListNode(2, new ListNode(3, new ListNode(4)))));
        ListNode.foreachListNode(node);
    }

    /**
     * 给你一个链表，两两交换其中相邻的节点，并返回交换后链表的头节点。
     * 你必须在不修改节点内部的值的情况下完成本题（即，只能进行节点交换）。
     * @param head
     * @return
     */
    public static ListNode swapPairs2(ListNode head) {
        if(head == null || head.next == null){
            return head;
        }
        // head next 两个待交换链表
        // next.next = head
        // head.next = 下一组交换链表
        ListNode next = head.next;
        head.next = swapPairs2(next.next);
        next.next = head;
        return next;
    }

    /**
     * 给你一个链表，两两交换其中相邻的节点，并返回交换后链表的头节点。
     * 你必须在不修改节点内部的值的情况下完成本题（即，只能进行节点交换）。
     * @param head
     * @return
     */
    public static ListNode swapPairs(ListNode head) {
        ListNode pre = new ListNode(0);
        pre.next = head;
        ListNode temp = pre;
        while(temp.next != null && temp.next.next != null) {
            ListNode start = temp.next;
            ListNode end = temp.next.next;
            temp.next = end;
            start.next = end.next;
            end.next = start;
            temp = start;
        }
        return pre.next;
    }
}
