package com.leetcode.mid;

import com.leetcode.ListNode;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/8/15
 * @Modified By:
 * @since DK 1.8
 */
public class RotateRight {
    public static void main(String[] args) {
        ListNode listNode = rotateRight(new ListNode(1, new ListNode(2, new ListNode(3, new ListNode(4, new ListNode(5))))), 2);
        ListNode.foreachListNode(listNode);
    }

    /**
     * 给你一个链表的头节点 head ，旋转链表，将链表每个节点向右移动 k 个位置。
     * @param head
     * @param k
     * @return
     */
    public static ListNode rotateRight(ListNode head, int k) {
        ListNode cur = head;
        while (cur.next !=null){

        }
        return null;
    }
}
