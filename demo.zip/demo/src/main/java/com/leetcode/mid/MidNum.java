package com.leetcode.mid;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/9/22
 * @Modified By:
 * @since DK 1.8
 */
public class MidNum {

    public static void main(String[] args) {

    }

    /**
     * 有一个无序的整数序列（无重复项，长度为奇数），请用你认为最优的方法求序列的中位数。例如给
     * 定数组 1、5、2、9、8、0、6，中位数是 5。要求算法的时间复杂度需要小于 O(n2)，不能使用内置排
     * 序函数，可以用任何语言实现。
     * 输入：一个无序的整数序列。
     * 输出：中位数
     * @return
     */
    private static int solution(){

       return 0;
    }
}
