package com.leetcode.mid;

import com.leetcode.ListNode;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:链表排序
 * @Date:Created in 2022/8/31
 * @Modified By:
 * @since DK 1.8
 */
public class SortList {
    public static void main(String[] args) {
        ListNode head = new ListNode(6, new ListNode(7,new ListNode(3,new ListNode(4,new ListNode(5)))));
        ListNode listNode = sortList(head);
        ListNode.foreachListNode(listNode);
    }
    /**
     * 给定链表的头结点 head ，请将其按 升序 排列并返回 排序后的链表 。
     * @param head
     * @return
     */
    public static ListNode sortList2(ListNode head){
        
        return null;
    }

    /**
     * 给定链表的头结点 head ，请将其按 升序 排列并返回 排序后的链表 。
     * @param head
     * @return
     */
    public static ListNode sortList(ListNode head) {
        if (head == null){
            return null;
        }
        List<Integer> list = new ArrayList<>();
        ListNode cur = head;
        while (cur != null){
            list.add(cur.val);
            cur = cur.next;
        }
        list.sort(Comparator.comparing(Integer::intValue, Comparator.reverseOrder()));
        cur = null;
        for (Integer a : list) {
            cur = new ListNode(a, cur);
        }
        return cur;
    }
}
