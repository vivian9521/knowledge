package com.leetcode.mid;

/**
 * @Auther:vivian
 * @Description:LCR 168. 丑数
 * 给你一个整数 n ，请你找出并返回第 n 个 丑数 。
 *
 * 说明：丑数是只包含质因数 2、3 和/或 5 的正整数；1 是丑数。
 * @Date:Created in 2023/10/16
 * @Modified By:
 * @since DK 1.8
 */
public class NthUglyNumber {
    /**
     * 示例 1：
     *
     * 输入: n = 11
     * 输出: 15
     * 解释: 1, 2, 3, 4, 5, 6, 8, 9, 10, 12 是前 10 个丑数。
     * @param n
     * @return
     */
    /**
     * 利用三个指针生成丑数的算法流程：

     * 初始化丑数列表 res ，首个丑数为 1 ，三个指针 a , b, c 都指向首个丑数。
     * 开启循环生成丑数：
     * 计算下一个丑数的候选集 res[a]⋅2, res[b]⋅3 , res[c]⋅5 。
     * 选择丑数候选集中最小的那个作为下一个丑数，填入 res 。
     * 将被选中的丑数对应的指针向右移动一格。
     * 返回 res 的最后一个元素即可。
     * @param n
     * @return
     */
    public int nthUglyNumber(int n) {
        int[] res = new int[n];
        int a = 0, b = 0, c = 0;
        res[0] = 1;
        for (int i = 1; i < n; i++) {
            int n2 = res[a] * 2, n3 = res[b] * 3, n5 = res[c] * 5;
            res[i] = Math.min(Math.min(n2, n3), n5);
            if (res[i] == n2) a++;
            if (res[i] == n3) b++;
            if (res[i] == n5) c++;
        }
        return res[n - 1];
    }

    public static void main(String[] args) {
        NthUglyNumber nthUglyNumber = new NthUglyNumber();
        int i = nthUglyNumber.nthUglyNumber(11);
        System.out.println(i);
    }
}
