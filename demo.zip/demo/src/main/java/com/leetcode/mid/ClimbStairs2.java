package com.leetcode.mid;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/9/22
 * @Modified By:
 * @since DK 1.8
 */
public class ClimbStairs2 {
    public static void main(String[] args) {
//        int climb = climb(10);
        System.out.println(climb(14));
        System.out.println(climb3(14));

    }
    private static int climb3(int k){
        int[] arr = new int[k + 1];
        arr[1] = 1;
        arr[2] = 1;
        arr[3] = 2;
        for (int i = 4; i <= k; i++) {
            arr[i] = arr[i - 1] + arr[i - 3];
        }
        return arr[k];
    }
    /**
     * 有一座高度是 k 级台阶的楼梯，从下往上走，每跨一步只能向上 1 级或者 3 级台阶。请用
     * 你认为最优的方法求一共有多少种走法。例如给定楼梯台阶数 k 为 3，一共有 2 种走法。要求算法的
     * 时间复杂度需要小于 O(2n)，可以用任何语言实现。
     * 输入：楼梯台阶数 k。
     * 输出：走法总数。
     * @return
     */
    private static int climb(int k){
        //f(n) = f(n-1) + f(n-3)
        // f(1) = 1;
        // f(2) = 1;
        // f(3) = f(2) + f(0);
        //  r      p      q
        // f(4) = f(3) + f(1);
        //          r     pre
        // f(5) = f(4) + f(2)
        // f(6) = f(5) + f(3)
        // f(7) = f(6) + f(4)
        if (k == 1 || k == 2){
            return 1;
        }
        int r = 0;
        int p = 1;
        int q = 1;
        List<Integer> list = new ArrayList<>();
        list.add(1);
        list.add(1);
        list.add(1);
        for (int i = 3; i <= k; i++) {
            r = p + q;
            list.add(r);
            p = r;
            //pre
            q = list.get(i - 2);
        }
        return r;
    }
}
