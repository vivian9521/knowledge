package com.leetcode.mid;

import java.util.HashMap;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:最长回文子串
 * @Date:Created in 2022/9/5
 * @Modified By:
 * @since DK 1.8
 */
public class LongestPalindrome {
    public static void main(String[] args) {
        //输入：s = "babad"
        //输出："bab"
        //解释："aba" 同样是符合题意的答案。
        //absghsgb
        String s = "babad";
        String s1 = longestPalindrome(s);
        System.out.println(s1);
    }

    /**
     * 中心扩散法
     * 给你一个字符串 s，找到 s 中最长的回文子串。
     * @param s
     * @return
     */
    public static String longestPalindrome(String s) {
        if (s == null || s.length() == 0){
            return "";
        }
        int maxStart = 0;
        int maxLen = 0;
        int left = 0;
        int right = 0;
        int len = 1;
        for (int i = 0; i < s.length(); i++) {
            left = i - 1;
            right = i + 1;
            while (left >= 0 && s.charAt(left) == s.charAt(i)){
                len ++;
                left--;
            }
            while (right < s.length() && s.charAt(right) == s.charAt(i)){
                len ++;
                right++;
            }
            while (left >= 0 && right < s.length() && s.charAt(left) == s.charAt(right)){
                len = len + 2;
                left--;
                right++;
            }
            if (len > maxLen){
                maxLen = len;
                maxStart = left;
            }
            len = 1;
        }
        return s.substring(maxStart + 1, maxStart + maxLen + 1);
    }

    /**
     * 是否是回文串
     * @param s
     * @return
     */
    private static boolean isPalindrome(String s){
        int p =0;
        int q = s.length() - 1;
        while (p < q){
            if (s.charAt(p) != s.charAt(q)){
                return false;
            }
            p++;
            q--;
        }
        return true;
    }


}
