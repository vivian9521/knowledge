package com.leetcode.mid;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:括号生成
 * @Date:Created in 2022/9/13
 * @Modified By:
 * @since DK 1.8
 */
public class GenerateParenthesis {
    public static void main(String[] args) {
        // n = 2
        // ()() (())
        //输入：n = 3
        //输出：["((()))","(()())","(())()","()(())","()()()"]
        List<String> list = generateParenthesis(3);
        System.out.println(list);

    }

    /**
     * 数字 n 代表生成括号的对数，请你设计一个函数，用于能够生成所有可能的并且 有效的 括号组合。
     * @param n
     * @return
     */
    public static List<String> generateParenthesis(int n) {
        char[] chars = new char[2*n];
        int pos = 0;
        List<String> res = new ArrayList<>();
        generate(chars, pos, res);
        return res;
    }

    private static void generate (char[] chars, int pos, List<String> res){
        if (chars.length == pos){
            if (valid(chars)){
                res.add(new String(chars));
            }
        }else {
            //左括号
            chars[pos] = '(';
            generate(chars, pos + 1, res);
            //右括号
            chars[pos] = ')';
            generate(chars, pos + 1, res);
        }
    }

    /**
     * 校验是否有效
     * @param chars
     * @return
     */
    private static boolean valid(char[] chars) {
        int balance = 0;
        for (char c : chars) {
            if (c == '('){
                balance++;
            }else {
                balance--;
            }
            if (balance < 0){
                return false;
            }
        }
        return balance == 0;
    }

}
