package com.leetcode.mid;

import com.leetcode.ListNode;

import java.util.Stack;

/**
 * @Auther:vivian
 * @Description:删除链表的倒数第 N 个结点
 * @Date:Created in 2022/9/9
 * @Modified By:
 * @since DK 1.8
 */
public class RemoveNthFromEnd {
    public static void main(String[] args) {
        ListNode listNode = new ListNode(1, new ListNode(2, new ListNode(3, new ListNode(4, new ListNode(5)))));
        ListNode listNode1 = new ListNode(1, new ListNode(2));
        ListNode rs = removeNthFromEnd3(listNode, 2);
        ListNode.foreachListNode(rs);

    }
    /**
     * 快慢指针
     * 给你一个链表，删除链表的倒数第 n 个结点，并且返回链表的头结点。
     * @param head
     * @param n
     * @return
     */
    public static ListNode removeNthFromEnd3(ListNode head, int n){
        //由于我们需要找到倒数第 nn 个节点，因此我们可以使用两个指针
        // first 和 second 同时对链表进行遍历，并且first 比 second 超前 n 个节点。
        // 当first 遍历到链表的末尾时，second 就恰好处于倒数第 n 个节点。
        ListNode ans = new ListNode(0, head);
        ListNode first = head;
        ListNode second = ans;
        for (int i = 0; i < n; i++) {
            first = first.next;
        }
        while (first != null){
            first = first.next;
            second = second.next;
        }
        second.next = second.next.next;
        return ans.next;
    }
    /**
     * 栈
     * 给你一个链表，删除链表的倒数第 n 个结点，并且返回链表的头结点。
     * @param head
     * @param n
     * @return
     */
    public static ListNode removeNthFromEnd2(ListNode head, int n) {
        ListNode ans = new ListNode(0, head);
        ListNode cur = ans;
        Stack<ListNode> stack = new Stack<>();
        while (cur != null){
            stack.push(cur);
            cur = cur.next;
        }
        for (int i = 0; i < n; i++) {
            stack.pop();
        }
        ListNode node = stack.peek();
        node.next = node.next.next;
        return ans.next;
    }
    /**
     * 栈
     * 给你一个链表，删除链表的倒数第 n 个结点，并且返回链表的头结点。
     * @param head
     * @param n
     * @return
     */
    public static ListNode removeNthFromEnd(ListNode head, int n) {
        ListNode cur = head;
        Stack<ListNode> stack = new Stack<>();
        while (cur != null){
            stack.push(cur);
            cur = cur.next;
        }
        int i = 0;
        while (!stack.isEmpty()){
            ListNode node = stack.pop();
            if (i == n){
                node.next = node.next.next;
                return head;
            }
            i++;
        }
        if (i == n){
            head = head.next;
            return head;
        }
        return null;
    }
}
