package com.leetcode.mid;

/**
 * @Auther:vivian
 * @Description:pow(x, n)
 * @Date:Created in 2022/9/20
 * @Modified By:
 * @since DK 1.8
 */
public class MyPow {
    public static void main(String[] args) {
        //输入：x = 2.00000, n = 10
        //输出：1024.00000
        //输入：x = 2.00000, n = -2
        //输出：0.25000
        //解释：2^-2 = 1/2^2 = 1/4 = 0.25
        double myPow = myPow(2.00000 , -2);
        System.out.println(myPow);
    }

    /**
     * 快速幂+迭代
     * 实现 pow(x, n) ，即计算 x 的整数 n 次幂函数（即，x^n ）。
     * @param x
     * @param n
     * @return
     */
    public static double myPow(double x, int n) {
        if (x == 0){
            return 0;
        }
        long N = n;
        double res = 1;
        if (N < 0){
            x = 1/x;
            N = -N;
        }
        while (N > 0){
            if ((N & 1) == 1){
                res = res * x;
            }
            x = x * x;
            N = N >> 1;
        }
        return res;
    }


    /**
     * 快速幂+递归
     * 实现 pow(x, n) ，即计算 x 的整数 n 次幂函数（即，x^n ）。
     * @param x
     * @param n
     * @return
     */
    public static double myPow2(double x, int n) {
        return  n > 0 ? pow(x, (long) n) : 1/pow(x, -(long) n);
    }

    private static double pow(double x, long n){
        if (n == 0){
            return 1;
        }
        // x^|n/2|
        double y = pow(x, n/2);
        return (n & 1 )!= 1 ? y * y : y * y * x;
    }
}
