package com.leetcode.algorithm;

import org.junit.Test;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:快速排序
 * @Date:Created in 2022/7/28
 * @Modified By:
 * @since DK 1.8
 */
public class FastSort {
    /**
     * 给定一个数组arr，和一个数num，请把小于等于num的数放在数组的左边，大于num的
     * 数放在数组的右边。要求额外空间复杂度0(1)，时间复杂度0 (N)
     */
    @Test
    public void sort1(){
        int num=28;
        int[] arr=new int[]{7,2,41,5,28,32,21,21};
        partition11(num,arr);
    }
    public void partition11(int num,int[] arr){
        if (arr==null||arr.length<2){
            return;
        }
        int length = arr.length;
        //<num区间,如果当前数小于num 则<区间向右+1，并且与+1所在索引交换数据
        int p1=-1;
        for (int i = 0; i < length; i++) {
            if (arr[i]<=num){
                swap(arr,i,++p1);
            }
        }
        System.out.println(Arrays.toString(arr));
    }

    /**
     * 荷兰国旗问题
     * 给定一个数组arr，和一个数num，请把小于num的数放在数组的左边，等于num的数放在数组的中间，大于num的数放在数组的右边。
     * 要求额外空间复杂度O(1)，时间复杂度O(N)
     */
    @Test
    public void sort2(){
        int num=28;
        int[] arr=new int[]{7,2,41,5,28,32,21,21};
        partition21(num,arr);
    }

    public void partition21(int num,int[] arr){
        if (arr==null||arr.length<2){
            return;
        }
        int length = arr.length;
        //<num区间
        int less=-1;
        //>num区间
        int more=length;
        int i=0;
        while (i<more){
            //进入<num区间，区间向右扩+1 ，与当前数进行交换，交换后索引+1
            if (arr[i]<num){
                swap(arr,i++,++less);
            }
            //进入>num区间，区间向左扩 -1,与当前数进行交换，交换后i索引不动
            else if (arr[i]>num){
                swap(arr,i,--more);
            }
            //=num 时，i++
            else {
                i++;
            }
        }
        System.out.println(Arrays.toString(arr));
    }

    /**
     * 快速排序
     */
    @Test
    public void fastSort(){
        int[] arr=new int[]{7,2,41,5,28,32,21,21};
        if (arr==null||arr.length<2){
            return;
        }
        fastSort1(arr,0,arr.length-1);
        System.out.println(Arrays.toString(arr));
    }

    public void fastSort1(int[] arr,int L,int R){
        if (L<R){
            //设置随机数，使平均复杂度=n*logN
            swap(arr,L+ (int)(Math.random()*(R-L+1)),R);
            int[] p = partition(arr, L, R);
            fastSort1(arr,L,p[0]-1);
            fastSort1(arr,p[1]+1,R);
        }
    }

    public int[] partition(int[] arr,int L,int R){
        //<num区间
        int less=L-1;
        //>num区间
        int more=R;
        //以arr[R]为基准数
        while (L<more){
            //进入<num区间，区间向右扩+1 ，与当前数进行交换，交换后索引+1
            if (arr[L]<arr[R]){
                swap(arr,L++,++less);
            }
            //进入>num区间，区间向左扩 -1,与当前数进行交换，交换后i索引不动
            else if (arr[L]>arr[R]){
                swap(arr,L,--more);
            }
            //=num 时，i++
            else {
                L++;
            }
        }
        //>区间索引最小值和基准值进行交换，使基准值左边<基准值，右边大于基准值
        swap(arr,more,R);
        return new int[]{less+1,more};
    }

    /**
     * 交换数据
     * @param i
     * @param j
     */
    public void swap(int[] arr,int i,int j){
        int temp=arr[j];
        arr[j]=arr[i];
        arr[i]=temp;
    }

}
