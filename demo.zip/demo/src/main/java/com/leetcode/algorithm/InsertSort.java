package com.leetcode.algorithm;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

/**
 * @Auther:vivian
 * @Description:插入排序
 * @Date:Created in 2022/7/20
 * @Modified By:
 * @since DK 1.8
 */
public class InsertSort {
    /**
     * 将第一待排序序列第一个元素看做一个有序序列，把第二个元素到最后一个元素当成是未排序序列。
     * 从头到尾依次扫描未排序序列，将扫描到的每个元素插入有序序列的适当位置。
     * @param args
     */
    public static void main(String[] args) {
        int[] arr=new int[]{7,2,41,5,28,32,21,21};
        int length = arr.length;
        for (int i = 0; i < length; i++) {
            for (int j =i; j>0; j--) {
                if (arr[j]<arr[j-1]){
                    int swap=arr[j];
                    arr[j]=arr[j-1];
                    arr[j-1]=swap;
                }
            }
        }
        System.out.println(Arrays.toString(arr));
    }
}
