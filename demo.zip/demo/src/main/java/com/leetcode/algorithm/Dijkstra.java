package com.leetcode.algorithm;

import java.util.Arrays;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2023/12/12
 * @Modified By:
 * @since DK 1.8
 */
public class Dijkstra {
    /**
     * 最短路径
     * @param map
     */
    private void dijkstra(int[][] map){
        //优先队列new int[] , index1 = 编号，index2 = 长度
        Queue<int[]> queue = new PriorityQueue<>(Comparator.comparingInt(o -> o[1]));
        //最短路径数组
        int[] dist = new int[map.length];
        Arrays.fill(dist, Integer.MAX_VALUE);
        dist[0] = 0;
        //是否已知
        boolean[] seen =new boolean[map.length];
        queue.add(new int[]{0, 0});
        while (!queue.isEmpty()){
            int[] t1 = queue.poll();
            int index = t1[0];
            int len = t1[1];
            //确定点
            seen[index] = true;
            for (int i = 0; i < map[index].length; i++) {
                int l = len + map[index][i];
                if (map[index][i] > 0 && !seen[i] && dist[i] > l){
                    dist[i] = l;
                    queue.add(new int[]{i, l});
                }
            }
        }
        for (int i : dist) {
            System.out.println(i);
        }
    }

    public static void main(String[] args) {
        int[][] map = new int[6][6];
        map[0][1]=2;map[0][2]=3;map[0][3]=6;
        map[1][0]=2;map[1][4]=4;map[1][5]=6;
        map[2][0]=3;map[2][3]=2;
        map[3][0]=6;map[3][2]=2;map[3][4]=1;map[3][5]=3;
        map[4][1]=4;map[4][3]=1;
        map[5][1]=6;map[5][3]=3;

        Dijkstra dijkstra = new Dijkstra();
        dijkstra.dijkstra(map);

    }
}
