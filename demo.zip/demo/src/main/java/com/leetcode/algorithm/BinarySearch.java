package com.leetcode.algorithm;

/**
 * @Auther:vivian
 * @Description:二分法查找
 * @Date:Created in 2022/7/25
 * @Modified By:
 * @since DK 1.8
 */
public class BinarySearch {

    public static void main(String[] args) {
        int[] arr=new int[]{7,2,41,5,28,32,21,21};
        BinarySearch search=new BinarySearch();
        int search1 = search.search(arr, 0, arr.length - 1);
        System.out.println(search1);
    }

    /**
     * 二分法求最大值
     */
    public int search(int[] arr,int L,int R){
        if (L==R){
            return arr[L];
        }
        int mid = L + ((R - L)>> 1) ;
        int leftMax = search(arr, L, mid);
        int rightMax = search(arr, mid + 1, R);
        return Math.max(leftMax,rightMax);
    }
}
