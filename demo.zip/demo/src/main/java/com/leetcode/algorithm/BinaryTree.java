package com.leetcode.algorithm;

import com.leetcode.TreeNode;
import org.junit.Test;

import java.util.Objects;
import java.util.Stack;

/**
 * @Auther:vivian
 * @Description:二叉树
 * @Date:Created in 2022/8/24
 * @Modified By:
 * @since DK 1.8
 */
public class BinaryTree {
    public static void main(String[] args) {
        TreeNode head = new TreeNode(5);
        head.left = new TreeNode(3);
        head.right = new TreeNode(8) ;
        head.left.left = new TreeNode(2);
        head.left.right = new TreeNode(4);
        head.left.left.left = new TreeNode(1);
        head.right.left = new TreeNode(7);
        head. right.left.left = new TreeNode(6);
        head.right.right = new TreeNode(10);
        head.right.right.left = new TreeNode(9);
        head.right.right.right = new TreeNode(11);
        preBinTree(head);
        System.out.println("---------------前序遍历------------");
        minBinTree(head);
        System.out.println("---------------中序遍历------------");
        posBinTree(head);
        System.out.println("---------------后序遍历------------");
        preStackBinTree(head);
    }

    /**
     * 前序二叉树遍历
     */
    public static void preBinTree(TreeNode treeNode){
        if (treeNode == null){
            return;
        }
        System.out.print(treeNode.val + " ");
        preBinTree(treeNode.left);
        preBinTree(treeNode.right);
    }
    /**
     * 中序二叉树遍历
     */
    public static void minBinTree(TreeNode treeNode){
        if (treeNode == null){
            return;
        }
        minBinTree(treeNode.left);
        System.out.print(treeNode.val + " ");
        minBinTree(treeNode.right);
    }
    /**
     * 后序二叉树遍历
     */
    public static void posBinTree(TreeNode treeNode){
        if (treeNode == null){
            return;
        }
        posBinTree(treeNode.left);
        posBinTree(treeNode.right);
        System.out.print(treeNode.val + " ");
    }

    /**
     * 前序遍历二叉树栈
     * @param head
     */
    public static void preStackBinTree(TreeNode head){
        //从栈中弹出一个节点cur
        //打印cur
        //先右后左（如果有）
        //依次循环
        System.out.println("------------前序遍历-栈---------------");
        if (head == null){
            return;
        }
        Stack<TreeNode> stack = new Stack<>();
        stack.add(head);
        while (!stack.isEmpty()){
            head = stack.pop();
            System.out.print(head.val+ " ");
            if (Objects.nonNull(head.right)){
                stack.push(head.right);
            }
            if (Objects.nonNull(head.left)){
                stack.push(head.left);
            }
        }
    }

}
