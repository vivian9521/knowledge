package com.leetcode.algorithm;


import com.sun.jmx.remote.internal.ArrayQueue;

import java.util.Arrays;
import java.util.Comparator;
import java.util.PriorityQueue;

/**
 * @Auther:vivian
 * @Description:堆排序
 * @Date:Created in 2022/8/4
 * @Modified By:
 * @since DK 1.8
 */
public class HeapSort {
    public static void main(String[] args) {
        int[] arr = {13, 52, 121, 54, 312, 121, 534};
        //堆排序
//        heapSort(arr);
//        System.out.println(Arrays.toString(arr));
        //小根堆排序
        prioritySort(arr);
    }

    /**
     * 堆排序
     * @param arr
     */
    public static void  heapSort(int[] arr){
        if (arr==null || arr.length<2){
            return;
        }
        for (int i = 0; i < arr.length; i++){
            heapInsert(arr, i);
        }
        int heapSize = arr.length;
        swap(arr, 0, --heapSize);
        while (heapSize > 0){
            heapIfy(arr, 0, heapSize);
            swap(arr, 0, --heapSize);
        }
    }

    public static void heapIfy(int[] arr ,int index, int heapSize){
        int left=2 * index + 1;
        while (left < heapSize){
            //两个孩子中谁的值大下标给谁
            int largest = left + 1 < heapSize && arr[left + 1] > arr[left] ? left + 1 : left;
            //孩子最大下标值和index比较，谁的值大，把下标给谁
            largest = arr[largest] > arr[index] ? largest : index;
            if (largest == index){
                break;
            }
            swap(arr,largest,index);
            index=largest;
            left = 2 * index + 1;
        }
    }

    /**
     * 堆插入排序
     * @param arr
     */
    public static void heapInsert(int[] arr,int index){
        while (arr[index]>arr[(index-1)/2]){
            swap(arr,index,(index-1)/2);
            index=(index-1)/2;
        }
    }

    public static void swap(int[] arr,int i, int j){
        int temp=arr[i];
        arr[i]=arr[j];
        arr[j]=temp;
    }

    /**
     * 小根堆排序
     */
    public static void prioritySort(int[] arr){
        //大根堆排序
//        PriorityQueue<Integer> heap=new PriorityQueue<>((o1, o2) -> o2-o1);
        //小根堆排序
        PriorityQueue<Integer> heap=new PriorityQueue<>();
        for (int i : arr) {
            heap.add(i);
        }
        while (!heap.isEmpty()){
            System.out.println(heap.poll());
        }
    }
}
