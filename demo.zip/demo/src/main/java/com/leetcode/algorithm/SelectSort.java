package com.leetcode.algorithm;

import jdk.nashorn.internal.ir.annotations.Ignore;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:选择排序
 * @Date:Created in 2022/7/20
 * @Modified By:
 * @since DK 1.8
 */
public class SelectSort {
    /**
     * 每遍历一次把最小值放到前面
     * 冒泡排序是通过数去找位置，选择排序是给定位置去找数；
     * @param args
     */
    public static void main(String[] args) {
        int[] arr=new int[]{7,2,41,5,28,32,21,21};
        int length = arr.length;
        /*for (int i = 0; i < length-1; i++) {//外循环控制循环的轮数
            int minIndex=i; //定义变量，表示每一轮假设最小元素的索引
            for (int j=i+1;j<length;j++){//内循环控制每一轮被比较的元素
                if (arr[minIndex]>arr[j]){
                    int swap=arr[minIndex];
                    arr[minIndex]=arr[j];
                    arr[j]=swap;
                }
            }
        }*/
        for (int i = 0; i < length; i++) {
            //默认最小值索引
            int minIndex=i;
            for (int j =i+1; j < arr.length; j++) {
                minIndex=arr[minIndex]>arr[j]?j:minIndex;
            }
            //最小值索引与默认最小值索引交换
            int swap=arr[i];
            arr[i]=arr[minIndex];
            arr[minIndex]=swap;
        }
        System.out.println(Arrays.toString(arr));
    }

    private void swap(int[] arr,int i,int j){
        arr[i]=arr[i]^arr[j];
        arr[j]=arr[i]^arr[j];
        arr[i]=arr[i]^arr[j];
    }
}
