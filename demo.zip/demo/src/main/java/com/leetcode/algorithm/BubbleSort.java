package com.leetcode.algorithm;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:冒泡排序
 * @Date:Created in 2022/7/20
 * @Modified By:
 * @since DK 1.8
 */
public class BubbleSort {
    /**
     * 每遍历一次最大值放到后面
     * @param args
     */
    public static void main(String[] args) {
        int[] arr=new int[]{7,2,41,5,28,32,21,21};
        int length = arr.length;
        /*for (int i = 0; i < length; i++) {
            for (int j=0;j<length-1;j++){
                if (arr[j]>arr[j+1]){
                    int swap=arr[j+1];
                    arr[j+1]=arr[j];
                    arr[j]=swap;
                }
            }
        }*/

        for (int i = 0; i <length; i++) {
            for (int j = 0; j <length-1-i; j++) {
                if (arr[j]>arr[j+1]){
                    int swap=arr[j+1];
                    arr[j+1]=arr[j];
                    arr[j]=swap;
                }
            }
        }


        System.out.println(Arrays.toString(arr));
    }

    private void swap(int[] arr, int i ,int j){
        arr[i]=arr[i]^arr[j];
        arr[j]=arr[i]^arr[j];
        arr[i]=arr[i]^arr[j];
    }
}
