package com.leetcode.algorithm;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:归并排序
 * @Date:Created in 2022/7/26
 * @Modified By:
 * @since DK 1.8
 */
public class MergeSort {

    public static void main(String[] args) {
//        int[] arr=new int[]{7,2,41,5,28,32,21,21};
        int[] arr=new int[]{7,2,1,1,2,2};
        //归并排序
//        sort(arr,0,arr.length-1);
//        System.out.println(Arrays.toString(arr));
        //小和数
        if (arr==null||arr.length<2){
            return;
        }
        int sum = littleSum(arr, 0, arr.length - 1);
        System.out.println(sum);
    }

    /**
     * 归并排序
     * @param arr
     * @param L
     * @param R
     */
    public static void sort(int[] arr,int L,int R){
        if (L==R){
            return;
        }
        int mid=(L+R)/2;
        sort(arr,L,mid);
        sort(arr,mid+1,R);
        merge(arr,L,mid,R);
    }

    public static void merge(int[] arr,int L,int M,int R){
        int[] help=new int[R-L+1];
        int i=0;
        int p1=L;
        int p2=M+1;
        while (p1<=M&&p2<=R){
            help[i++]=arr[p1]<=arr[p2]?arr[p1++]:arr[p2++];
        }
        while (p1<=M){
            help[i++]=arr[p1++];
        }
        while (p2<=R){
            help[i++]=arr[p2++];
        }
        for (i=0;i<help.length;i++){
            arr[L+i]=help[i];
        }

    }

    /**
     * 进阶归并排序：求小和数
     * 在一个数组中，每一个数组左边比当前数小的数累加起来，叫做这个数组的小和。求一个数组的小和。
     */
    public static int littleSum(int[] arr,int L,int R){
        //可以转换为当前数比右边大的数的个数*当前数
        //递归计算左子树的数比右子树大的 个数*左子树当前数
        if (L==R){
            return 0;
        }
        int mid=L+((R-L)>>1);
        //左侧树小数和+右侧树小数和+两树比较小数和
        return littleSum(arr,L,mid)
                +littleSum(arr,mid+1,R)
                +mergePlus(arr,L,mid,R);
    }

    public static int mergePlus(int[] arr,int L,int M,int R){
        int[] help=new int[R-L+1];
        int i=0;
        int p1=L;
        int p2=M+1;
        int res=0;
        while (p1<=M&&p2<=R){
            //计算左子树的数比右子树大的 个数*左子树当前数
            res+=arr[p1]<arr[p2]?arr[p1]*(R-p2+1):0;
            //如果p1<p2则p1往右移动，
            // 如果p1=p2则p2往右移动，因为需要计算左子树的数比右子树大的 个数*左子树当前数
            //如果p1>p2 则p2往右移动
            help[i++]=arr[p1]<arr[p2]?arr[p1++]:arr[p2++];
        }
        while (p1<=M){
            help[i++]=arr[p1++];
        }
        while (p2<=R){
            help[i++]=arr[p2++];
        }
        for (i=0;i<help.length;i++){
            arr[L+i]=help[i];
        }
        return res;
    }

}
