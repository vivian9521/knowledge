package com.leetcode;

import java.util.List;

/**
 * @Auther:vivian
 * @Description:    N叉树
 * @Date:Created in 2024/2/19
 * @Modified By:
 * @since DK 1.8
 */
public class Nnode {
    public int val;
    public List<Nnode> children;

    public Nnode() {}

    public Nnode(int _val) {
        val = _val;
    }

    public Nnode(int _val, List<Nnode> _children) {
        val = _val;
        children = _children;
    }
}
