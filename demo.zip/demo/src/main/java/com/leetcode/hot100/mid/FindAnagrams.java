package com.leetcode.hot100.mid;

import org.apache.poi.util.StringUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:438. 找到字符串中所有字母异位词
 * 给定两个字符串 s 和 p，找到 s 中所有 p 的 异位词 的子串，返回这些子串的起始索引。不考虑答案输出的顺序。
 *
 * 异位词 指由相同字母重排列形成的字符串（包括相同的字符串）。
 * @Date:Created in 2023/10/26
 * @Modified By:
 * @since DK 1.8
 */
public class FindAnagrams {
    /**
     * 示例 1:
     *
     * 输入: s = "cbaebabacd", p = "abc"
     * 输出: [0,6]
     * 解释:
     * 起始索引等于 0 的子串是 "cba", 它是 "abc" 的异位词。
     * 起始索引等于 6 的子串是 "bac", 它是 "abc" 的异位词。
     *  示例 2:
     *
     * 输入: s = "abab", p = "ab"
     * 输出: [0,1,2]
     * 解释:
     * 起始索引等于 0 的子串是 "ab", 它是 "ab" 的异位词。
     * 起始索引等于 1 的子串是 "ba", 它是 "ab" 的异位词。
     * 起始索引等于 2 的子串是 "ab", 它是 "ab" 的异位词。
     *
     * @param s
     * @param p
     * @return
     */

    public List<Integer> findAnagrams2(String s, String p) {
        if (s.length() == 0 || p.length() == 0){
            return new ArrayList<>();
        }
        if (s.length() < p.length()){
            return new ArrayList<>();
        }
        List<Integer> res = new ArrayList<>();
        int pLen = p.length();
        int sLen = s.length();
        int[] sCnt = new int[26];
        int[] pCnt = new int[26];
        for (int i = 0; i < pLen; i++) {
            ++pCnt[p.charAt(i) - 'a'];
            ++sCnt[s.charAt(i) - 'a'];
        }
        if (Arrays.equals(sCnt, pCnt)){
            res.add(0);
        }
        for (int i = pLen; i < sLen; i++) {
            --sCnt[s.charAt(i - pLen) - 'a'];
            ++sCnt[s.charAt(i) - 'a'];
            if (Arrays.equals(sCnt, pCnt)){
                res.add(i - pLen + 1);
            }
        }
        return res;
    }

    public List<Integer> findAnagrams(String s, String p) {
        if (s.length() == 0 || p.length() == 0){
            return new ArrayList<>();
        }
        if (s.length() < p.length()){
            return new ArrayList<>();
        }
        List<Integer> res = new ArrayList<>();
        char[] pChars = p.toCharArray();
        Arrays.sort(pChars);
        String p1 = String.valueOf(pChars);
        int size = p.length();
        for (int i = 0; i < s.length() - size + 1; i++) {
            String str = s.substring(i, i + size);
            char[] chars = str.toCharArray();
            Arrays.sort(chars);
            str = String.valueOf(chars);
            if (str.equals(p1)){
                res.add(i);
            }
        }
        return res;
    }

    public static void main(String[] args) {
        FindAnagrams findAnagrams = new FindAnagrams();
        List<Integer> list = findAnagrams.findAnagrams("cbaebabacd", "abc");
        System.out.println(list);


        Integer[] a = new Integer[]{1,2,3};
        Integer[] b = new Integer[]{1,2,3};
        System.out.println(Arrays.equals(a, b));
    }
}
