package com.leetcode.hot100.mid;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:152. 乘积最大子数组
 * 给你一个整数数组 nums ，请你找出数组中乘积最大的非空连续子数组（该子数组中至少包含一个数字），
 * 并返回该子数组所对应的乘积。
 *
 * 测试用例的答案是一个 32-位 整数。
 *
 * 子数组 是数组的连续子序列。
 * @Date:Created in 2023/11/29
 * @Modified By:
 * @since DK 1.8
 */
public class MaxProduct {

    public int maxProduct(int[] nums) {
        if (nums.length == 1){
            return nums[0];
        }
        //最大的遇到负数可能会变成最小的，最小的遇到负数可能变成最大的
        //所以需要求出最大的和最小的
        int min = nums[0], max = nums[0], res = nums[0];

        for (int i = 1; i < nums.length; i++) {
            int mx = max, mi = min;
            max = Math.max(nums[i], Math.max(mx * nums[i], mi * nums[i]));
            min = Math.min(nums[i], Math.min(mx * nums[i],mi * nums[i]));
            res = Math.max(max, res);
        }
        return res;
    }

    public static void main(String[] args) {
        MaxProduct maxProduct = new MaxProduct();
        int i = maxProduct.maxProduct(new int[]{2, 3, -3, -4});
        System.out.println(i);
    }
}
