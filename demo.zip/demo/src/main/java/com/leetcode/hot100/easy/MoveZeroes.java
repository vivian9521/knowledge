package com.leetcode.hot100.easy;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:283. 移动零
 * 给定一个数组 nums，编写一个函数将所有 0 移动到数组的末尾，同时保持非零元素的相对顺序。
 *
 * 请注意 ，必须在不复制数组的情况下原地对数组进行操作。
 * @Date:Created in 2023/10/26
 * @Modified By:
 * @since DK 1.8
 */
public class MoveZeroes {
    /**
     * 示例 1:
     *
     * 输入: nums = [0,1,0,3,12]
     *              1,0,0,3,12
     *              1,3,0,0,12
     *                [1,0,3,12,0]
     * 输出: [1,3,12,0,0]
     * 示例 2:
     *
     * 输入: nums = [0]
     * 输出: [0]
     *
     * @param nums
     */
    public void moveZeroes(int[] nums) {
        if (nums == null || nums.length == 0){
            return;
        }
        // i 代表0指针
        int i = 0;
        //j 代表非0指针
        int j = 0;
        while (i < nums.length){
            if (nums[i] != 0){
                //i==j时不需要交换
                if (i > j){
                    swap(i, j, nums);
                }
                j++;
            }
            i++;
        }
    }

    public void moveZeroes2(int[] nums) {
        if(nums==null) {
            return;
        }
        //第一次遍历的时候，j指针记录非0的个数，只要是非0的统统都赋给nums[j]
        int j = 0;
        for(int i=0;i<nums.length;++i) {
            if(nums[i]!=0) {
                nums[j++] = nums[i];
            }
        }
        //非0元素统计完了，剩下的都是0了
        //所以第二次遍历把末尾的元素都赋为0即可
        for(int i=j;i<nums.length;++i) {
            nums[i] = 0;
        }
    }
    private void swap(int i , int j, int[] nums){
        int temp = nums[i];
        nums[i] = nums[j];
        nums[j] = temp;
    }

    public static void main(String[] args) {
        MoveZeroes zeroes = new MoveZeroes();
//        int[] ints = {0, 1, 0, 3, 12};
        int[] ints = {0};
        zeroes.moveZeroes(ints);
        Arrays.stream(ints).forEach(System.out::println);
    }
}
