package com.leetcode.hot100.hard;

import net.sf.jsqlparser.statement.select.First;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * @Auther:vivian
 * @Description:41. 缺失的第一个正数
 * 给你一个未排序的整数数组 nums ，请你找出其中没有出现的最小的正整数。
 *
 * 请你实现时间复杂度为 O(n) 并且只使用常数级别额外空间的解决方案。
 * @Date:Created in 2023/11/2
 * @Modified By:
 * @since DK 1.8
 */
public class FirstMissingPositive {
    /**
     * 示例 1：
     *
     * 输入：nums = [1,2,0]
     * 输出：3
     * 示例 2：
     *
     * 输入：nums = [3,4,-1,1]
     * 输出：2
     * 示例 3：
     *
     * 输入：nums = [7,8,9,11,12]
     * 输出：1
     * @param nums
     * @return
     */
    public int firstMissingPositive2(int[] nums) {
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] <= 0){
                nums[i] = nums.length + 1;
            }
        }
        for (int i = 0; i < nums.length; i++){
            int num = Math.abs(nums[i]);
            if (num <= nums.length){
                nums[num - 1] = -Math.abs(nums[num - 1]);
            }
        }
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] > 0){
                return i + 1;
            }
        }
        return nums.length + 1;
    }
    public int firstMissingPositive(int[] nums) {
        Set<Integer> set = new HashSet<>();
        for (int num : nums) {
            if (num > 0){
                set.add(num);
            }
        }
        for (int i = 1; i < Integer.MAX_VALUE; i++) {
            if (!set.contains(i)){
                return i;
            }
        }
        return 1;
    }

    public static void main(String[] args) {
        int[] nums = new int[]{3,4,-1,1};
        FirstMissingPositive firstMissingPositive = new FirstMissingPositive();
        int i = firstMissingPositive.firstMissingPositive2(nums);
        System.out.println(i);
    }
}
