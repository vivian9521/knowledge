package com.leetcode.hot100.easy;

import com.leetcode.TreeNode;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:94. 二叉树的中序遍历
 * 给定一个二叉树的根节点 root ，返回 它的 中序 遍历 。
 * @Date:Created in 2023/11/9
 * @Modified By:
 * @since DK 1.8
 */
public class InorderTraversal {

    private List<Integer> list;
    public List<Integer> inorderTraversal(TreeNode root) {
        list = new ArrayList<>();
        inOrder(root);
        return list;
    }
    private void inOrder(TreeNode node){
        if (node == null){
            return;
        }
        inOrder(node.left);
        list.add(node.val);
        inOrder(node.right);
    }
}
