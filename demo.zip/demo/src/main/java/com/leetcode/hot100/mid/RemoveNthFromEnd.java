package com.leetcode.hot100.mid;

import com.leetcode.ListNode;

import java.util.Stack;

/**
 * @Auther:vivian
 * @Description:19. 删除链表的倒数第 N 个结点
 * 给你一个链表，删除链表的倒数第 n 个结点，并且返回链表的头结点。
 * @Date:Created in 2023/11/7
 * @Modified By:
 * @since DK 1.8
 */
public class RemoveNthFromEnd {
    /**
     * 快慢指针
     * @param head
     * @param n
     * @return
     */
    public ListNode removeNthFromEnd3(ListNode head, int n) {
        ListNode dump = new ListNode(0,head);
        ListNode fast = head;
        ListNode slow = dump;
        for (int i = 0; i < n; i++) {
            fast = fast.next;
        }
        while (fast != null){
            slow = slow.next;
            fast = fast.next;
        }
        slow.next = slow.next.next;
        return dump.next;
    }
    /**
     * 栈
     * @param head
     * @param n
     * @return
     */
    public ListNode removeNthFromEnd2(ListNode head, int n) {
        if (head == null){
            return null;
        }
        ListNode dump = new ListNode(0, head);
        ListNode cur = dump;
        Stack<ListNode> stack = new Stack<>();
        while (cur != null){
            stack.push(cur);
            cur = cur.next;
        }
        for (int i = 0; i < n; i++) {
            stack.pop();
        }
        ListNode preNode = stack.peek();
        preNode.next = preNode.next.next;
        return dump.next;
    }
    /**
     * 计算链表长度
     * @param head
     * @param n
     * @return
     */
    public ListNode removeNthFromEnd(ListNode head, int n) {
        if (head == null){
            return null;
        }
        int count = 0;
        ListNode cur = head;
        while (cur != null){
            count++;
            cur = cur.next;
        }
        int num = count - n;
        if (num == 0){
            return head.next;
        }
        cur = head;
        while (--num != 0){
            cur = cur.next;
        }
        cur.next = cur.next.next;
        return head;
    }

    public static void main(String[] args) {
        RemoveNthFromEnd removeNthFromEnd  = new RemoveNthFromEnd();
        ListNode node = removeNthFromEnd.removeNthFromEnd2(new ListNode(1, new ListNode(2, new ListNode(3, new ListNode(4, new ListNode(5))))), 5);

    }
}
