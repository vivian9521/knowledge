package com.leetcode.hot100.hard;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:51. N 皇后
 * 按照国际象棋的规则，皇后可以攻击与之处在同一行或同一列或同一斜线上的棋子。
 *
 * n 皇后问题 研究的是如何将 n 个皇后放置在 n×n 的棋盘上，并且使皇后彼此之间不能相互攻击。
 *
 * 给你一个整数 n ，返回所有不同的 n 皇后问题 的解决方案。
 *
 * 每一种解法包含一个不同的 n 皇后问题 的棋子放置方案，该方案中 'Q' 和 '.' 分别代表了皇后和空位。
 * @Date:Created in 2023/11/17
 * @Modified By:
 * @since DK 1.8
 */
public class SolveNQueens {

    public List<List<String>> solveNQueens(int n) {
        List<List<String>> res = new ArrayList<>();
        List<String> list = new ArrayList<>();
        backTrack(n, 0, list, res);
        return res;
    }

    private void backTrack(int n, int row, List<String> list, List<List<String>> res){
        if (list.size() == n){
            res.add(new ArrayList<>(list));
            return;
        }
        for (int i = row; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (check(i, j, list)){
                    char[] chars = new char[n];
                    Arrays.fill(chars, '.');
                    chars[j] = 'Q';
                    list.add(new String(chars));
                    backTrack(n, i + 1, list, res);
                    list.remove(list.size() - 1);
                }
            }
        }
    }

    private boolean check(int row, int col, List<String> list){
        for (int i = 0; i < list.size(); i++) {
            String s = list.get(i);
            for (int j = 0; j < s.length(); j++) {
                if (s.charAt(j) == 'Q'){
                    if (row == i || col == j || Math.abs(row - i) == Math.abs(col - j)){
                        return false;
                    }
                }
            }
        }
        return true;
    }

    public static void main(String[] args) {
        SolveNQueens solveNQueens = new SolveNQueens();
        List<List<String>> lists = solveNQueens.solveNQueens(4);
        lists.stream().forEach(System.out::println);
    }
}
