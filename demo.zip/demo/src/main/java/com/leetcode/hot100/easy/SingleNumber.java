package com.leetcode.hot100.easy;

import java.util.Arrays;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:136. 只出现一次的数字
 * 给你一个 非空 整数数组 nums ，除了某个元素只出现一次以外，其余每个元素均出现两次。找出那个只出现了一次的元素。
 *
 * 你必须设计并实现线性时间复杂度的算法来解决此问题，且该算法只使用常量额外空间。
 * @Date:Created in 2023/11/30
 * @Modified By:
 * @since DK 1.8
 */
public class SingleNumber {
    public int singleNumber3(int[] nums) {
        if (nums.length == 1){
            return nums[0];
        }
        int res = 0;
        for (int num : nums) {
            res = res ^ num;
        }
        return res;
    }
    public int singleNumber2(int[] nums) {
        Map<Integer, Integer> map = new HashMap<>();
        for (int num : nums) {
            if (map.containsKey(num)){
                map.remove(num);
            }else {
                map.put(num, 1);
            }
        }
        for (Integer num : map.keySet()) {
            return num;
        }
        return -1;
    }

    public int singleNumber(int[] nums) {
        if (nums.length == 1){
            return nums[0];
        }
        Arrays.sort(nums);
        int i = 0;
        while (i < nums.length - 1){
            if (nums[i] != nums[i + 1]){
                return nums[i];
            }
            i+=2;
        }
        return nums[nums.length - 1];
    }

    public static void main(String[] args) {
        SingleNumber singleNumber = new SingleNumber();
        int i = singleNumber.singleNumber3(new int[]{4, 1, 2, 1, 2});
        System.out.println(i);

        System.out.println((1 ^ 1));
    }
}
