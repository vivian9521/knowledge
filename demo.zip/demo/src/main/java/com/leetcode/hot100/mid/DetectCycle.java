package com.leetcode.hot100.mid;

import com.leetcode.ListNode;

import java.util.HashSet;
import java.util.Set;

/**
 * @Auther:vivian
 * @Description:142. 环形链表 II
 * 给定一个链表的头节点  head ，返回链表开始入环的第一个节点。 如果链表无环，则返回 null。
 *
 * 如果链表中有某个节点，可以通过连续跟踪 next 指针再次到达，则链表中存在环。 为了表示给定链表中的环，
 * 评测系统内部使用整数 pos 来表示链表尾连接到链表中的位置（索引从 0 开始）。如果 pos 是 -1，则在该链表中没有环。
 * 注意：pos 不作为参数进行传递，仅仅是为了标识链表的实际情况。
 *
 * 不允许修改 链表。
 * @Date:Created in 2023/11/6
 * @Modified By:
 * @since DK 1.8
 */
public class DetectCycle {
    public ListNode detectCycle3(ListNode head) {
        // a = 链表头到入口节点，   b= 环节点
        // f = 2s,  第一次相遇：f = s + nb ->  s = nb
        //所以第一次相遇时，慢指针走了n圈环
        //第二次相遇时， 只有 s = a+nb 才会在入口,所以还需要走a步
        if (head == null || head.next == null){
            return null;
        }
        ListNode s = head;
        ListNode f = head;
        while (true){
            if (f == null || f.next == null){
                return null;
            }
            s = s.next;
            f = f.next.next;
            if (s == f){
                break;
            }
        }
        f = head;
        while (f != s){
            s = s.next;
            f = f.next;
        }
        return f;
    }

    /**
     * 快慢指针
     * @param head
     * @return
     */
    public ListNode detectCycle2(ListNode head) {
        // a = 链表头到入口节点，   b= 环节点
        // f = 2s,  第一次相遇：f = s + nb ->  s = nb
        //所以第一次相遇时，慢指针走了n圈环
        //第二次相遇时， 只有 s = a+nb 才会在入口,所以还需要走a步
        if (head == null || head.next == null){
            return null;
        }
        ListNode s = head;
        ListNode f = head.next;
        while (s != f){
            if (f == null || f.next == null){
                return null;
            }
            s = s.next;
            f = f.next.next;
        }
        f = head;
        while (f != s){
            s = s.next;
            f = f.next;
        }
        return f;
    }
    /**
     * 哈希表
     * @param head
     * @return
     */
    public ListNode detectCycle(ListNode head) {
        Set<ListNode> set = new HashSet<>();
        ListNode cur = head;
        while (cur != null){
            if (set.contains(cur)){
                return cur;
            }
            set.add(cur);
            cur = cur.next;
        }
        return null;
    }

    public static void main(String[] args) {
        DetectCycle detectCycle = new DetectCycle();
    }
}
