package com.leetcode.hot100.mid;

/**
 * @Auther:vivian
 * @Description:287. 寻找重复数
 * 给定一个包含 n + 1 个整数的数组 nums ，其数字都在 [1, n] 范围内（包括 1 和 n），可知至少存在一个重复的整数。
 *
 * 假设 nums 只有 一个重复的整数 ，返回 这个重复的数 。
 *
 * 你设计的解决方案必须 不修改 数组 nums 且只用常量级 O(1) 的额外空间。
 * @Date:Created in 2023/12/1
 * @Modified By:
 * @since DK 1.8
 */
public class FindDuplicate {
    /**
     * 环形链表-快慢指针
     * @param nums
     * @return
     */
    public int findDuplicate(int[] nums) {
        //映射关系 n->f(n)看做链表
        //慢指针走一步 slow = slow.next ==> 本题 slow = nums[slow]
        //快指针走两步 fast = fast.next.next ==> 本题 fast = nums[nums[fast]]
        int slow = 0, fast = 0;
        slow = nums[slow];
        fast = nums[nums[fast]];
        while (slow != fast){
            slow = nums[slow];
            fast = nums[nums[fast]];
        }
        int p1 = 0;
        int p2 = slow;
        while (p1 != p2){
            p1 = nums[p1];
            p2 = nums[p2];
        }
        return p1;
    }

    public static void main(String[] args) {
        int[] nums = new int[]{2,1,3,1};
        FindDuplicate findDuplicate = new FindDuplicate();
        int duplicate = findDuplicate.findDuplicate(nums);
        System.out.println(duplicate);

        System.out.println(2^1^3^1);
        System.out.println(2 & 2 & 2);
    }
}
