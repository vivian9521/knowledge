package com.leetcode.hot100.easy;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:169. 多数元素
 * 给定一个大小为 n 的数组 nums ，返回其中的多数元素。多数元素是指在数组中出现次数 大于 ⌊ n/2 ⌋ 的元素。
 *
 * 你可以假设数组是非空的，并且给定的数组总是存在多数元素。
 * @Date:Created in 2023/11/30
 * @Modified By:
 * @since DK 1.8
 */
public class MajorityElement {
    /**
     * 摩尔投票法
     * @param nums
     * @return
     */
    public int majorityElement(int[] nums) {
        int x = 0, vote = 0;
        for (int num : nums) {
            if (vote == 0){
                x = num;
            }
            vote+=  x == num ? 1 : -1;
        }
        return x;
    }
    public int majorityElement3(int[] nums) {
        Arrays.sort(nums);
        return nums[nums.length/2];
    }
    public int majorityElement2(int[] nums) {
        if (nums.length == 1){
            return nums[0];
        }
        int mid =nums.length / 2 + 1;
        Map<Integer, Integer> map = new HashMap<>();
        for (int num : nums) {
            map.put(num, map.getOrDefault(num, 0) + 1);
            if (map.get(num) >= mid){
                return num;
            }
        }
        return nums[0];
    }

    public static void main(String[] args) {
        MajorityElement majorityElement = new MajorityElement();
        int i = majorityElement.majorityElement(new int[]{-1,1,1,1,2,1});
        System.out.println(i);
    }
}
