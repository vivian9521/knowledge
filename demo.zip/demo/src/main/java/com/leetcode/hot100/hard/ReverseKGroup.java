package com.leetcode.hot100.hard;

import com.leetcode.ListNode;

/**
 * @Auther:vivian
 * @Description:25. K 个一组翻转链表
 * 给你链表的头节点 head ，每 k 个节点一组进行翻转，请你返回修改后的链表。
 *
 * k 是一个正整数，它的值小于或等于链表的长度。如果节点总数不是 k 的整数倍，那么请将最后剩余的节点保持原有顺序。
 *
 * 你不能只是单纯的改变节点内部的值，而是需要实际进行节点交换。
 * @Date:Created in 2023/11/8
 * @Modified By:
 * @since DK 1.8
 */
public class ReverseKGroup {

    public ListNode reverseKGroup(ListNode head, int k) {
        if (head == null){
            return null;
        }
        ListNode cur = head;
        ListNode dump = new ListNode(0, head);
        ListNode pre = dump;
        ListNode end = dump;
        while (cur != null){
            for (int i = 0; i < k; i++) {
                end = end.next;
                if (end == null){
                    return dump.next;
                }
            }
            ListNode start = pre.next;
            ListNode next = end.next;
            end.next = null;
            pre.next = reverseList(start);

            start.next = next;
            pre = start;
            end = pre;
            cur = cur.next;
        }
        return dump.next;
    }

    public ListNode reverseList(ListNode head) {
        if (head == null){
            return head;
        }
        ListNode cur = head;
        ListNode res = null;
        while (cur != null){
            ListNode temp = cur.next;
            cur.next = res;
            res = cur;
            cur = temp;
        }
        return res;
    }

    public static void main(String[] args) {
        ReverseKGroup reverseKGroup = new ReverseKGroup();
        ListNode node = reverseKGroup.reverseKGroup(new ListNode(1, new ListNode(2, new ListNode(3, new ListNode(4, new ListNode(5))))), 2);

    }
}
