package com.leetcode.hot100.easy;

import com.leetcode.ListNode;

/**
 * @Auther:vivian
 * @Description:21. 合并两个有序链表
 * 将两个升序链表合并为一个新的 升序 链表并返回。新链表是通过拼接给定的两个链表的所有节点组成的。
 * @Date:Created in 2023/11/7
 * @Modified By:
 * @since DK 1.8
 */
public class MergeTwoLists {
    public ListNode mergeTwoLists(ListNode list1, ListNode list2) {
        ListNode res = new ListNode(0);
        ListNode cur = res;
        ListNode l1 = list1;
        ListNode l2 = list2;
        while (l1 != null && l2 != null){
            if (l1.val < l2.val){
                cur.next = new ListNode(l1.val);
                l1 = l1.next;
            }else {
                cur.next = new ListNode(l2.val);
                l2 = l2.next;
            }
            cur = cur.next;
        }
        cur.next = l1 != null ? l1 : l2;

        return res.next;
    }

    public ListNode mergeTwoLists2(ListNode list1, ListNode list2) {
        ListNode res = new ListNode(0);
        ListNode cur = res;
        ListNode l1 = list1;
        ListNode l2 = list2;
        while (l1 != null || l2 != null){

            if (l1 != null && l2 != null){
                if (l1.val < l2.val){
                    cur.next = new ListNode(l1.val);
                    l1 = l1.next;
                }else {
                    cur.next = new ListNode(l2.val);
                    l2 = l2.next;
                }
                cur = cur.next;
            }else if (l1 == null){
                cur.next = new ListNode(l2.val);
                l2 = l2.next;
                cur = cur.next;
            }else {
                cur.next = new ListNode(l1.val);
                l1 = l1.next;
                cur = cur.next;
            }
        }
        return res.next;
    }


    public static void main(String[] args) {
        MergeTwoLists mergeTwoLists = new MergeTwoLists();
        mergeTwoLists.mergeTwoLists2(new ListNode(1,new ListNode(2, new ListNode(4))), new ListNode(1,new ListNode(3, new ListNode(4))));
    }
}
