package com.leetcode.hot100.easy;

import com.leetcode.TreeNode;
import jdk.management.jfr.RecordingInfo;

/**
 * @Auther:vivian
 * @Description:226. 翻转二叉树
 * 给你一棵二叉树的根节点 root ，翻转这棵二叉树，并返回其根节点。
 * @Date:Created in 2023/11/9
 * @Modified By:
 * @since DK 1.8
 */
public class InvertTree {

    public TreeNode invertTree(TreeNode root) {
        if (root == null){
            return null;
        }
        TreeNode temp = invertTree(root.left);
        root.left = invertTree(root.right);
        root.right = temp;
        return root;
    }
}
