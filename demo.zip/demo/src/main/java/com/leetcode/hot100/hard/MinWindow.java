package com.leetcode.hot100.hard;

import java.util.HashMap;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:76. 最小覆盖子串
 * 给你一个字符串 s 、一个字符串 t 。返回 s 中涵盖 t 所有字符的最小子串。
 * 如果 s 中不存在涵盖 t 所有字符的子串，则返回空字符串 "" 。
 * 注意：
 *
 * 对于 t 中重复字符，我们寻找的子字符串中该字符数量必须不少于 t 中该字符数量。
 * 如果 s 中存在这样的子串，我们保证它是唯一的答案。
 * @Date:Created in 2023/10/31
 * @Modified By:
 * @since DK 1.8
 */
public class MinWindow {
    /**
     * 示例 1：
     *
     * 输入：s = "ADOBECODEBANC", t = "ABC"
     * 输出："BANC"
     * 解释：最小覆盖子串 "BANC" 包含来自字符串 t 的 'A'、'B' 和 'C'。
     * @param s
     * @param t
     * @return
     */
    //思路：1、先初始化含有t字符数量字典；（s字符遍历时，字符数组进行加减不包含t的字符数量只能是<0或=0,只有包含t字符才可能>0）
    // 2、开始遍历s,设置开始索引和结束索引，（设置t.len=cnt，当cnt==0时，代表已经满足了包含t所需所有字符的条件），
    // 结束索引右移，字典里字符数量-1,（一旦包含t字符，且字典数>0,cnt-1）（负数代表多余字符，）
    public String minWindow(String s, String t) {
        int cnt = t.length();
        int[] need = new int[128];
        //统计子串字符数量
        for (int i = 0; i < t.length(); i++) {
            need[t.charAt(i)]++;
        }
        int start = 0;
        int end = 0;
        int size = Integer.MAX_VALUE;
        int l = 0;
        while (end < s.length()){
            char c = s.charAt(end);
            //表示t中包含当前遍历到的这个c字符（因为t不包含的只能<0或=0），更新目前所需要的count数大小，应该减少一个
            if (need[c] > 0){
                cnt--;
            }
            //无论这个字符是否包含在t中，need[]数组中对应那个字符的计数都减少1，利用正负区分这个字符是多余的还是有用的
            need[c]--;
            //count==0说明当前的窗口已经满足了包含t所需所有字符的条件
            if (cnt == 0){
                //小于0都是多余的，右移
                while (start < end && need[s.charAt(start)] < 0){
                    //数组字符+1
                    need[s.charAt(start)]++;
                    //右移，过滤元素
                    start++;
                }
                //如果当前的这个窗口值比之前维护的窗口值更小，需要进行更新
                if ((end - start + 1) < size){
                    size = end - start + 1;
                    //更新窗口起始位置，方便之后找到这个位置返回结果
                    l = start;
                }
                //先将l位置的字符计数重新加1
                need[s.charAt(start)]++;
                //重新维护左边界值和当前所需字符的值count
                start++;
                cnt++;
            }
            //右移边界，开始下一次循环
            end++;
        }
        return size == Integer.MAX_VALUE ? "" : s.substring(l, l + size);
    }

    public static void main(String[] args) {
        MinWindow minWindow = new MinWindow();
        String s = minWindow.minWindow("bab", "cab");
        System.out.println(s);
    }
}
