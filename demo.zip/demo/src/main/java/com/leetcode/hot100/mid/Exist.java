package com.leetcode.hot100.mid;

/**
 * @Auther:vivian
 * @Description:79. 单词搜索
 * 给定一个 m x n 二维字符网格 board 和一个字符串单词 word 。如果 word 存在于网格中，返回 true ；
 * 否则，返回 false 。
 *
 * 单词必须按照字母顺序，通过相邻的单元格内的字母构成，其中“相邻”单元格是那些水平相邻或垂直相邻的单元格。
 * 同一个单元格内的字母不允许被重复使用。
 * @Date:Created in 2023/11/17
 * @Modified By:
 * @since DK 1.8
 */
public class Exist {

    public boolean exist(char[][] board, String word) {
        for (int i = 0; i < board.length; i++) {
            for (int j = 0; j < board[0].length; j++) {
                if (board[i][j] == word.charAt(0)){
                    boolean[][] selected = new boolean[board.length][board[0].length];
                    boolean rlt = recur(board, word, 0, selected, i, j);
                    if (rlt){
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean recur(char[][] board, String word, int index, boolean[][] selected, int i, int j){
        if (i < 0 || j < 0 || i >= board.length || j >= board[0].length || index >= word.length() || selected[i][j] || board[i][j] != word.charAt(index)){
            return false;
        }
        if (index == word.length() - 1){
            return true;
        }
        selected[i][j] = true;
        boolean rlt = recur(board, word, index + 1, selected, i - 1, j) || recur(board, word, index + 1, selected, i + 1, j)
                || recur(board, word, index + 1, selected, i, j - 1) || recur(board, word, index + 1, selected, i, j + 1);
        selected[i][j] = false;
        return rlt;
    }

    public static void main(String[] args) {
        Exist exist = new Exist();
        boolean abcced = exist.exist(new char[][]{{'A', 'B', 'C', 'E'}, {'S', 'F', 'C', 'S'}, {'A', 'D', 'E', 'E'}}, "ABCCED");
        System.out.println(abcced);
    }
}
