package com.leetcode.hot100.hard;

import java.util.Deque;
import java.util.LinkedList;

/**
 * @Auther:vivian
 * @Description:84. 柱状图中最大的矩形
 * 给定 n 个非负整数，用来表示柱状图中各个柱子的高度。每个柱子彼此相邻，且宽度为 1 。
 *
 * 求在该柱状图中，能够勾勒出来的矩形的最大面积。
 * @Date:Created in 2023/11/23
 * @Modified By:
 * @since DK 1.8
 */
public class LargestRectangleArea {
    /**
     * 单调栈
     * @param heights
     * @return
     */
    public int largestRectangleArea(int[] heights) {
        if (heights.length == 0){
            return 0;
        }
        if (heights.length == 1){
            return heights[0];
        }
        int res = 0;
        //面积=宽度*高度，所以记录索引即可
        Deque<Integer> stack = new LinkedList<>();
        for (int i = 0; i < heights.length; i++) {
            while (!stack.isEmpty() && heights[stack.peek()] > heights[i]){
                res = calcArea(heights, res, stack, i);
            }
            stack.push(i);
        }
        int nextIndex = heights.length;
        while (!stack.isEmpty()){
            res = calcArea(heights, res, stack, nextIndex);
        }
        return res;
    }

    private int calcArea(int[] heights, int res, Deque<Integer> stack, int i) {
        Integer curIndex = stack.pop();
        while (!stack.isEmpty() && heights[curIndex] == heights[stack.peek()]){
            stack.pop();
        }
        Integer preIndex = !stack.isEmpty() ? stack.peek() : -1;
        int width = i - preIndex - 1;
        int height = heights[curIndex];
        res = Math.max(res, width * height);
        return res;
    }

    public static void main(String[] args) {
        LargestRectangleArea largestRectangleArea = new LargestRectangleArea();
        int i = largestRectangleArea.largestRectangleArea(new int[]{1,1});
        System.out.println(i);
    }
}
