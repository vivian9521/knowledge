package com.leetcode.hot100.hard;

import java.net.HttpRetryException;
import java.util.Arrays;
import java.util.Stack;

/**
 * @Auther:vivian
 * @Description:42. 接雨水
 * 给定 n 个非负整数表示每个宽度为 1 的柱子的高度图，计算按此排列的柱子，下雨之后能接多少雨水。
 * @Date:Created in 2023/10/27
 * @Modified By:
 * @since DK 1.8
 */
public class Trap {
    /**
     * 输入：height = [0,1,0,2,1,0,1,3,2,1,2,1]
     * 输出：6
     * 解释：上面是由数组 [0,1,0,2,1,0,1,3,2,1,2,1] 表示的高度图，在这种情况下，
     * 可以接 6 个单位的雨水（蓝色部分表示雨水）。
     * 示例 2：
     *
     * 输入：height = [4,2,0,3,2,5]
     * 输出：9
     *
     * @param height
     * @return
     */
    //按列计算
    public int trap2(int[] height) {
        int sum = 0;
        ////最两端的列不用考虑，因为一定不会有水。所以下标从 1 到 length - 2
        for (int i = 1; i < height.length - 1; i++) {
            //找出当前列左边最高
            int lmax = 0;
            for (int l = 0; l < i; l++) {
                lmax = Math.max(height[l], lmax);
            }
            //找出当前列右边最高
            int rmax = 0;
            for (int r = i + 1; r < height.length; r++) {
                rmax = Math.max(height[r], rmax);
            }
            //找出两边最高比较矮的那一个
            int min = Math.min(lmax, rmax);
            //算出较矮的那个与当前列的差高。如果较矮<=当前列，则没有雨水接住
            if (min > height[i]){
                sum += (min - height[i]);
            }
        }
        return sum;
    }
    //动态规划
    public int trap3(int[] height) {
        int sum = 0;
        int[] lmax = new int[height.length];
        int[] rmax = new int[height.length];
        //它前边的墙的左边的最高高度和它前边的墙的高度选一个较大的，就是当前列左边最高的墙了。
        for (int i = 1; i < height.length; i++) {
            lmax[i] = Math.max(lmax[i - 1], height[i - 1]);
        }
        //它后边的墙的右边的最高高度和它后边的墙的高度选一个较大的，就是当前列右边最高的墙了。
        for (int j = height.length - 2; j >= 0; j--) {
            rmax[j] = Math.max(rmax[j + 1], height[j + 1]);
        }

        for (int i = 1; i < height.length - 1; i++) {
            int min = Math.min(lmax[i], rmax[i]);
            if (min > height[i]){
                sum += min - height[i];
            }
        }
        return sum;
    }
    //双指针
    public int trap4(int[] height) {
        int sum = 0;
        int lmax = 0;
        int rmax = 0;
        int l = 1;
        int r = height.length - 2;
        for (int i = 1; i < height.length - 1; i++) {
            // pre大        >            pre小

            if (height[l - 1] < height[r + 1]){
                lmax = Math.max(lmax, height[l - 1]);
                int min = lmax;
                if (min > height[l]){
                    sum += min - height[l];
                }
                l++;
            }else {
                rmax = Math.max(rmax, height[r + 1]);
                int min = rmax;
                if (min > height[r]){
                    sum += min - height[r];
                }
                r--;
            }

        }
        return sum;
    }
    //单调栈

    /**
     * 总体的原则就是，当前高度小于等于栈顶高度，入栈，指针后移。
     * 当前高度大于栈顶高度，出栈，计算出当前墙和栈顶的墙之间水的多少，
     * 然后计算当前的高度和新栈的高度的关系，重复第 2 步。直到当前墙的高度不大于栈顶高度或者栈空，
     * 然后把当前墙入栈，指针后移。
     * @param height
     * @return
     */
    public int trap5(int[] height) {
        int sum = 0;
        Stack<Integer> stack = new Stack<>();
        int current = 0;
        while (current < height.length) {
            //如果栈不空并且当前指向的高度大于栈顶高度就一直循环
            while (!stack.isEmpty() && height[current] > height[stack.peek()]){
                Integer h = height[stack.peek()];
                stack.pop();
                //栈空就出去
                if (stack.isEmpty()){
                    break;
                }
                //两堵墙之间距离
                int distance = current - stack.peek() - 1;
                int min = Math.min(height[current], height[stack.peek()]);
                sum += distance * (min - h);
            }
            stack.push(current);//当前墙指针入栈
            current++;//指针右移
        }
        return sum;
    }
    //按行计算（会超时）
    public int trap(int[] height) {
        int max = 0;
        for (int num : height) {
            max = Math.max(num, max);
        }
        int sum = 0;
        for (int h = 1; h <= max; h++) {
            boolean isStart = false;//标记是否开始更新
            int tempSum = 0;
            for (int i = 0; i < height.length; i++) {
                if (isStart && height[i] < h){
                    tempSum++;
                }
                if (height[i] >= h){
                    sum += tempSum;
                    tempSum = 0;
                    isStart = true;
                }

            }
        }
        return sum;
    }
}
