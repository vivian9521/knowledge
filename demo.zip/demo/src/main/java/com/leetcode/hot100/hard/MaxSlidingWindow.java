package com.leetcode.hot100.hard;

import java.util.Arrays;
import java.util.LinkedList;

/**
 * @Auther:vivian
 * @Description:239. 滑动窗口最大值
 * 给你一个整数数组 nums，有一个大小为 k 的滑动窗口从数组的最左侧移动到数组的最右侧。
 * 你只可以看到在滑动窗口内的 k 个数字。滑动窗口每次只向右移动一位。
 *
 * 返回 滑动窗口中的最大值 。
 * @Date:Created in 2023/10/30
 * @Modified By:
 * @since DK 1.8
 */
public class MaxSlidingWindow {
    /**
     * 示例 1：
     *
     * 输入：nums = [1,3,-1,-3,5,3,6,7], k = 3
     * 输出：[3,3,5,5,6,7]
     * 解释：
     * 滑动窗口的位置                最大值
     * ---------------               -----
     * [1  3  -1] -3  5  3  6  7       3
     *  1 [3  -1  -3] 5  3  6  7       3
     *  1  3 [-1  -3  5] 3  6  7       5
     *  1  3  -1 [-3  5  3] 6  7       5
     *  1  3  -1  -3 [5  3  6] 7       6
     *  1  3  -1  -3  5 [3  6  7]      7
     *
     * -1 3 1->  -3 -1 3 -> 5
     *
     * @param nums
     * @param k
     * @return
     */
    public int[] maxSlidingWindow(int[] nums, int k) {
        if (nums.length == 0){
            return new int[0];
        }
        LinkedList<Integer> queue = new LinkedList<>();
        int[] res = new int[nums.length - k + 1];
        int j = 0;
        for (int i = 0; i < nums.length ; i++) {
            if ( i >= k){
                //如果队首数值=待滑出窗口的数值，则移除
                if (!queue.isEmpty() && nums[i - k] == queue.getFirst()){
                    queue.removeFirst();
                }
            }
            //移除比待进队列数小的数
            while (!queue.isEmpty() && queue.getLast() < nums[i]){
                queue.removeLast();
            }
            queue.add(nums[i]);
            if (!queue.isEmpty() && i >= k - 1){
                res[j++] = queue.getFirst();
            }
        }
        return res;
    }

    public static void main(String[] args) {
        MaxSlidingWindow maxSlidingWindow = new MaxSlidingWindow();
        int[] ints = maxSlidingWindow.maxSlidingWindow(new int[]{1,3,-1,-3,5,3,6,7}, 3);
        Arrays.stream(ints).forEach(System.out::println);
    }
}
