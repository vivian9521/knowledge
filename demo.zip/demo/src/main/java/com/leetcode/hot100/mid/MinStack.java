package com.leetcode.hot100.mid;

import java.util.Deque;
import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Stack;

/**
 * @Auther:vivian
 * @Description:155. 最小栈
 * 设计一个支持 push ，pop ，top 操作，并能在常数时间内检索到最小元素的栈。
 *
 * 实现 MinStack 类:
 *
 * MinStack() 初始化堆栈对象。
 * void push(int val) 将元素val推入堆栈。
 * void pop() 删除堆栈顶部的元素。
 * int top() 获取堆栈顶部的元素。
 * int getMin() 获取堆栈中的最小元素。
 * @Date:Created in 2023/11/21
 * @Modified By:
 * @since DK 1.8
 */
public class MinStack {

    Deque<Integer> deque;
    Deque<Integer> minQueue;
    public MinStack() {
        deque = new LinkedList<>();
        minQueue = new LinkedList<>();
    }

    public void push(int val) {
        deque.push(val);
        minQueue.push(minQueue.isEmpty() ? val : Math.min(val, minQueue.peek()));
    }

    public void pop() {
        deque.poll();
        minQueue.poll();
    }

    public int top() {
        return deque.peek();
    }

    public int getMin() {
        return minQueue.peek();
    }
}
