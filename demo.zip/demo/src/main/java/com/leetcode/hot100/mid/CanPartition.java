package com.leetcode.hot100.mid;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:416. 分割等和子集
 * 给你一个 只包含正整数 的 非空 数组 nums 。请你判断是否可以将这个数组分割成两个子集，使得两个子集的元素和相等。
 * @Date:Created in 2023/11/29
 * @Modified By:
 * @since DK 1.8
 */
public class CanPartition {

    public boolean canPartition(int[] nums) {
        int n = nums.length;
        if (n < 2){
            return false;
        }
        int sum = 0, maxNum = 0;
        for (int num : nums) {
            sum +=num;
            maxNum = Math.max(num, maxNum);
        }
        if (sum % 2 == 1){
            return false;
        }
        int target = sum/2;
        if (maxNum > target){
            return false;
        }
        //0-1背包问题

        boolean[][] dp = new boolean[n][target + 1];
        for (int i = 0; i < n; i++) {
            dp[i][0] = true;
        }
        dp[0][nums[0]] = true;
        for (int i = 1; i < nums.length; i++) {
            for (int j = 1; j <= target; j++) {
                boolean p1 = dp[i - 1][j];
                if (j - nums[i] < 0){
                    dp[i][j] = p1;
                }else {
                    boolean p2 = dp[i - 1][j - nums[i]];
                    dp[i][j] = p1 | p2;
                }
            }
        }
        return dp[n-1][target];
    }

    public static void main(String[] args) {
        CanPartition canPartition = new CanPartition();
        boolean b = canPartition.canPartition(new int[]{1, 5, 5, 11});
        System.out.println(b);
    }

    private int dfs(int[] nums, int index, int target){
        if (target < 0){
            return -1;
        }
        if (index == nums.length){
            return 0;
        }
        int p1 = dfs(nums, index + 1, target);
        if (target - nums[target] < 0){
            return p1;
        }
        int p2 = dfs(nums, index + 1, target - nums[index]);
        return Math.max(p1, p2);
    }
}
