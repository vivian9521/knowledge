package com.leetcode.hot100.mid;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:78. 子集
 * 给你一个整数数组 nums ，数组中的元素 互不相同 。返回该数组所有可能的子集（幂集）。
 *
 * 解集 不能 包含重复的子集。你可以按 任意顺序 返回解集。
 * @Date:Created in 2023/11/17
 * @Modified By:
 * @since DK 1.8
 */
public class Subsets {

    public List<List<Integer>> subsets(int[] nums) {
        List<List<Integer>> res = new ArrayList<>();
        List<Integer> list = new ArrayList<>();
        recur(nums, 0, list, res);
        return res;
    }

    private void recur(int[] nums, int len, List<Integer> list, List<List<Integer>> res){
        res.add(new ArrayList<>(list));
        if (list.size() == nums.length){
            return;
        }
        for (int i = len; i < nums.length; i++) {
            list.add(nums[i]);
            recur(nums, i + 1, list, res);
            list.remove(list.size() - 1);
        }
    }

    public static void main(String[] args) {
        Subsets subsets = new Subsets();
        List<List<Integer>> list = subsets.subsets(new int[]{1, 2, 3});
        list.stream().forEach(System.out::println);

        System.out.println("--------------");
        System.out.println(list.size());

        System.out.println(1<<3);
    }

}
