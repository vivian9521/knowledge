package com.leetcode.hot100.mid;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:17. 电话号码的字母组合
 * 给定一个仅包含数字 2-9 的字符串，返回所有它能表示的字母组合。答案可以按 任意顺序 返回。
 *
 * 给出数字到字母的映射如下（与电话按键相同）。注意 1 不对应任何字母。
 * @Date:Created in 2023/11/17
 * @Modified By:
 * @since DK 1.8
 */
public class LetterCombinations {

    public List<String> letterCombinations(String digits) {
        if (digits == null || digits.length() == 0){
            return new ArrayList<>();
        }
        List<String> res = new ArrayList<>();
        char[] chars = digits.toCharArray();
        int[] nums = new int[chars.length];
        for (int i = 0; i < chars.length; i++) {
            nums[i] = chars[i] -'0';
        }
        Map<Integer, char[]> map = new HashMap<>();
        map.put(2, new char[]{'a','b','c'});
        map.put(3, new char[]{'d','e','f'});
        map.put(4, new char[]{'g','h','i'});
        map.put(5, new char[]{'j','k','l'});
        map.put(6, new char[]{'m','n','o'});
        map.put(7, new char[]{'p','q','r','s'});
        map.put(8, new char[]{'t','u','v'});
        map.put(9, new char[]{'w','x','y','z'});
        List<Character> charList = new ArrayList<>();
        recur(nums, 0, map, charList, res);
        return res;
    }

    private void recur(int[] nums, int len,Map<Integer, char[]> map, List<Character> charList, List<String> res){
        if (charList.size() == nums.length){
            StringBuilder stringBuilder = new StringBuilder();
            for (Character character : charList) {
                stringBuilder.append(character);
            }
            res.add(stringBuilder.toString());
            return;
        }
        for (int i = len; i < nums.length; i++) {
            char[] letters = map.get(nums[i]);
            for (char letter : letters) {
                charList.add(letter);
                recur(nums, i + 1, map, charList, res);
                charList.remove(charList.size() - 1);
            }
        }
    }

    public static void main(String[] args) {
        //i = 2   0 1 2   3*(i - 2)
        //3   3 4 5   3*(i - 2)
        //4   6 7 8   3*(i - 2)
        LetterCombinations letterCombinations = new LetterCombinations();
        List<String> list = letterCombinations.letterCombinations("23");
        System.out.println(list);

    }
}
