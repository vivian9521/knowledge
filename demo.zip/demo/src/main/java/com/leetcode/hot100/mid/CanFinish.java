package com.leetcode.hot100.mid;

import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:207. 课程表
 * 你这个学期必须选修 numCourses 门课程，记为 0 到 numCourses - 1 。
 *
 * 在选修某些课程之前需要一些先修课程。 先修课程按数组 prerequisites 给出，其中 prerequisites[i] = [ai, bi] ，
 * 表示如果要学习课程 ai 则 必须 先学习课程  bi 。
 *
 * 例如，先修课程对 [0, 1] 表示：想要学习课程 0 ，你需要先完成课程 1 。
 * 请你判断是否可能完成所有课程的学习？如果可以，返回 true ；否则，返回 false 。
 * @Date:Created in 2023/11/15
 * @Modified By:
 * @since DK 1.8
 */
public class CanFinish {
    /**
     * 深度优先遍历
     * 记住这三个标志位对应的状态
     * i == 0 ： 干净的，未被 DFS 访问
     * i == -1：其他节点启动的 DFS 访问过了，路径没问题，不需要再访问了
     * i == 1  ：本节点启动的 DFS 访问过了，一旦遇到了也说明有环了
     *
     * 然后就是遍历+标记判断有无环：
     *
     * 1、从课程0启动DFS，先判断下，哦，节点0还没被访问，将flag[0]置1，表明被当前节点启动的dfs访问过了，在访问0时
     * 就通过以下代码一连串把3、5都访问了,返回true之前标志位置-1，这样从其他节点进来看到标志位-1时就无需再访问了，
     * 直接返回true.
     * 2.从课程1启动DFS一样的道理，3、5上一步已经访问过了标志位为-1，这一步就不访问了，只要访问4，并把标志位置为-1.,
     * 3、剩下的同理。这里是举了个无环的情况，那有环是什么样子呢？
     * 下标  0     1     2     3    4    5   先学的课程
     *      [3]  [3,4]  [4]   [5]  [5]  [3 ]  这里多加了一个，先学5才能学3，这回肯定就有问题了
     *
     * 在第一步从课程0启动DFS，一连串访问3，5，从5又遍历到3时，由于我们本节点启动的dfs已经访问过3了，标志位为1，
     * 所以碰到标志位为1，说明有环了，直接返回false;一旦某次df返回了false,整个遍历就结束了，返回最终结果false
     *
     * @param numCourses
     * @param prerequisites
     * @return
     */
    public boolean canFinish(int numCourses, int[][] prerequisites) {
        List<List<Integer>> adjacency = new ArrayList<>();
        for(int i = 0; i < numCourses; i++)
            adjacency.add(new ArrayList<>());
        int[] flags = new int[numCourses];
        for(int[] cp : prerequisites)
            adjacency.get(cp[1]).add(cp[0]);
        for(int i = 0; i < numCourses; i++)
            if(!dfs(adjacency, flags, i)) return false;
        return true;
    }
    private boolean dfs(List<List<Integer>> adjacency, int[] flags, int i) {
        if(flags[i] == 1) return false;
        if(flags[i] == -1) return true;
        flags[i] = 1;
        for(Integer j : adjacency.get(i))
            if(!dfs(adjacency, flags, j)) return false;
        flags[i] = -1;
        return true;
    }

    /**
     * 拓扑排序（入度，出度）广度优先遍历
     * @param numCourses
     * @param prerequisites
     * @return
     */
    public boolean canFinish2(int numCourses, int[][] prerequisites) {
        //入度Map<课程号，入度数量>，如果入度数量为0，则放入队列，出队时，
        // 对其依赖课程Map<课程数，依赖课程列表>进行入度数量-1,如果入度数量为0，对其入队，循环进行此操作，
        // 直到队列为空，如果入度Map数量依然不为空，则失败
        Map<Integer, Integer> inDegree = new HashMap<>();
        Map<Integer, List<Integer>> adj = new HashMap<>();
        Deque<Integer> queue = new LinkedList<>();
        //初始化入度为0
        for (int i = 0; i < numCourses; i++) {
            inDegree.put(i, 0);
        }

        for (int[] prerequisite : prerequisites) {
            int last = prerequisite[0];
            int pre = prerequisite[1];
            //入度
            inDegree.put(last, inDegree.get(last) + 1);
            //添加依赖列表
            if (!adj.containsKey(pre)) {
                adj.put(pre, new ArrayList<>());
            }
            adj.get(pre).add(last);
        }
        //入度数量为0的课程号放入队列,代表可以选这个课程
        for (Map.Entry<Integer, Integer> entry : inDegree.entrySet()) {
            if (entry.getValue() == 0){
                queue.offer(entry.getKey());
            }
        }
        //出队列，对其依赖列表课程号入度-1
        while (!queue.isEmpty()){
            Integer num = queue.poll();
            if (!adj.containsKey(num)){
                continue;
            }
            //对关联课程号入度-1
            List<Integer> list = adj.get(num);
            for (Integer val : list) {
                inDegree.put(val, inDegree.get(val) - 1);
                if (inDegree.get(val) == 0){
                    queue.offer(val);
                }
            }
        }
        //查看是否有入度非0的课程号
        for (Integer key : inDegree.keySet()) {
            if (inDegree.get(key) != 0){
                return false;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        CanFinish canFinish = new CanFinish();
        boolean b = canFinish.canFinish(2, new int[][]{{1, 0}});
        System.out.println(b);
    }
}
