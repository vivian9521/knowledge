package com.leetcode.hot100.hard;

import com.leetcode.ListNode;
import com.leetcode.hot100.easy.MergeTwoLists;

import java.util.PriorityQueue;
import java.util.Queue;

/**
 * @Auther:vivian
 * @Description:23. 合并 K 个升序链表
 * 给你一个链表数组，每个链表都已经按升序排列。
 *
 * 请你将所有链表合并到一个升序链表中，返回合并后的链表。
 * @Date:Created in 2023/11/9
 * @Modified By:
 * @since DK 1.8
 */
public class MergeKLists {
    /**
     * 二分法
     * @param lists
     * @return
     */
    public ListNode mergeKLists2(ListNode[] lists) {
        if (lists.length == 0){
            return null;
        }
        return merge(lists, 0, lists.length - 1);

    }
    private ListNode merge(ListNode[] lists, int left, int right){
        if (left == right){
            return lists[left];
        }
        int mid = (left + right)/2;

        return sort(merge(lists, left, mid), merge(lists, mid + 1, right));
    }
    private ListNode sort(ListNode aNode, ListNode bNode){
        ListNode res = new ListNode(0);
        ListNode cur = res;
        ListNode a = aNode;
        ListNode b = bNode;
        while (a != null && b != null){
            if (a.val < b.val){
                cur.next = new ListNode(a.val);
                a = a.next;
            }else {
                cur.next = new ListNode(b.val);
                b = b.next;
            }
            cur = cur.next;
        }
        cur.next = a == null ? b : a;
        return res.next;
    }
    /**
     * 优先队列
     * @param lists
     * @return
     */
    public ListNode mergeKLists(ListNode[] lists) {
        if (lists.length == 0){
            return null;
        }
        Queue<Integer> queue = new PriorityQueue<>();
        for (ListNode node : lists) {
            ListNode cur = node;
            while (cur != null){
                queue.add(cur.val);
                cur = cur.next;
            }
        }
        ListNode res = new ListNode(0);
        ListNode c = res;
        while (!queue.isEmpty()){
            c.next = new ListNode(queue.poll());
            c = c.next;
        }
        return res.next;
    }

    public static void main(String[] args) {
        MergeKLists mergeKLists = new MergeKLists();
        mergeKLists.mergeKLists(new ListNode[]{new ListNode(1, new ListNode(2)), new ListNode(1, new ListNode(3))});
    }
}
