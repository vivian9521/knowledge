package com.leetcode.hot100.mid;

import com.leetcode.hot100.easy.IsPalindrome;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:131. 分割回文串
 * 给你一个字符串 s，请你将 s 分割成一些子串，使每个子串都是 回文串 。返回 s 所有可能的分割方案。
 *
 * 回文串 是正着读和反着读都一样的字符串。
 * @Date:Created in 2023/11/20
 * @Modified By:
 * @since DK 1.8
 */
public class Partition {
    /**
     *回溯+动态规则
     * @param s
     * @return
     */
    public List<List<String>> partition(String s) {
        List<List<String>> res = new ArrayList<>();
        int n = s.length();
        if (n == 0){
            return res;
        }
        List<String> list = new ArrayList<>();
        //dp[i][j] = dp[i+1][j-1] && s[i] == s[j]
        boolean[][] dp = new boolean[n][n];
        for (int j = 0; j< n; j++) {
            for (int i = 0; i <= j; i++) {
                dp[i][j] = (j - i <= 2 || dp[i + 1][j - 1]) && s.charAt(i) == s.charAt(j);
            }
        }
        dfs(s.toCharArray(), 0, n, list, res, dp);
        return res;
    }
    private void dfs(char[] chars, int index, int len, List<String> list, List<List<String>> res, boolean[][] dp){
        if (index == len){
            res.add(new ArrayList<>(list));
            return;
        }
        for (int i = index; i < len; i++) {
            if (!dp[index][i]){
                continue;
            }
            list.add(new String(chars, index, i + 1 - index));
            dfs(chars, i + 1, len, list, res, dp);
            list.remove(list.size() - 1);
        }
    }
    /**
     *回溯
     * @param s
     * @return
     */
    public List<List<String>> partition2(String s) {
        List<List<String>> res = new ArrayList<>();
        if (s.length() == 0){
            return res;
        }
        List<String> list = new ArrayList<>();
        dfs2(s.toCharArray(), 0, s.length(), list, res);
        return res;
    }

    private void dfs2(char[] chars, int index, int len, List<String> list, List<List<String>> res){
        if (index == len){
            res.add(new ArrayList<>(list));
            return;
        }
        for (int i = index; i < len; i++) {
            if (!isPalindrome(chars, index, i)){
                continue;
            }
            list.add(new String(chars, index, i + 1 - index));
            dfs2(chars, i + 1, len, list, res);
            list.remove(list.size() - 1);
        }
    }

    /**
     * 是否回文串判断
     * @param chars
     * @param left
     * @param right
     * @return
     */
    private boolean isPalindrome(char[] chars, int left, int right) {
        while (left < right){
            if (chars[left] != chars[right]){
                return false;
            }
            left++;
            right--;
        }
        return true;
    }
}
