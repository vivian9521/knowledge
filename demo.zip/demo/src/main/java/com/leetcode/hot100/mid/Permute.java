package com.leetcode.hot100.mid;

import java.util.ArrayList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:46. 全排列
 * 给定一个不含重复数字的数组 nums ，返回其 所有可能的全排列 。你可以 按任意顺序 返回答案。
 * @Date:Created in 2023/11/16
 * @Modified By:
 * @since DK 1.8
 */
public class Permute {

    public List<List<Integer>> permute(int[] nums) {
        if (nums.length == 0){
            return new ArrayList<>();
        }
        boolean[] selected = new boolean[nums.length];
        List<Integer> list = new ArrayList<>();
        List<List<Integer>> res = new ArrayList<>();
        recur(nums, selected, list, res);
        return res;
    }

    private void recur(int[] nums, boolean[] selected, List<Integer> list, List<List<Integer>> res){
        int n = nums.length;
        if (list.size() == n){
            res.add(new ArrayList<>(list));
            return;
        }
        for (int i = 0; i < n; i++) {
            if (!selected[i]){
                list.add(nums[i]);
                selected[i] = true;
                recur(nums, selected, list, res);
                list.remove(list.size() - 1);
                selected[i] = false;
            }

        }
    }
}
