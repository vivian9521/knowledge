package com.leetcode.hot100.mid;

import com.sun.org.apache.regexp.internal.RE;

/**
 * @Auther:vivian
 * @Description:5. 最长回文子串
 * 给你一个字符串 s，找到 s 中最长的回文子串。
 *
 * 如果字符串的反序与原始字符串相同，则该字符串称为回文字符串。
 * @Date:Created in 2023/11/30
 * @Modified By:
 * @since DK 1.8
 */
public class LongestPalindrome {

    public String longestPalindrome(String s) {
        if (s.length() < 2){
            return s;
        }
        int max = 1;
        int left = 0;
        int n = s.length();
        boolean[][] dp = new boolean[n][n];
        //单个字符一定是回文串
        for (int i = 0; i < n; i++) {
            dp[i][i] = true;
        }
        //字符长度
        for (int L = 2; L < n; L++) {
            //左边界
            for (int i = 0; i < n; i++) {
                // j-i + 1 = L 右边界 = L + i - 1;
                int j = L + i - 1;
                //右边界不能越界
                if (j >= n){
                    break;
                }
                if (s.charAt(i) != s.charAt(j)){
                    dp[i][j] = false;
                }else {
                    if (j - i < 3){
                        dp[i][j] = true;
                    }else {
                        dp[i][j] = dp[i + 1][j - 1];
                    }
                }
                if (dp[i][j] && max < j - i + 1){
                    max = j - i + 1;
                    left = i;
                }
            }
        }
        return s.substring(left, left + max);
    }

    /**
     * 中心拓展法
     * @param s
     * @return
     */
    public String longestPalindrome2(String s) {
        if (s.length() < 2){
            return s;
        }
        int left = 0, maxLen = 1;

        for (int i = 0; i < s.length(); i++) {
            int tempLen = 1;
            int l = i - 1;
            int r = i + 1;
            while (l >= 0 && s.charAt(l) == s.charAt(i)){
                l--;
                tempLen++;
            }
            while (r < s.length() && s.charAt(r) == s.charAt(i)){
                r++;
                tempLen++;
            }
            while (l >= 0 && r <s.length() && s.charAt(l) == s.charAt(r)){
                l--;
                r++;
                tempLen += 2;
            }
            if (maxLen < tempLen){
                maxLen = tempLen;
                left = l;
            }
        }
        return s.substring(left + 1, left + maxLen + 1);
    }

    public static void main(String[] args) {
        LongestPalindrome longestPalindrome = new LongestPalindrome();
        String babad = longestPalindrome.longestPalindrome2("babad");
        System.out.println(babad);
    }
}
