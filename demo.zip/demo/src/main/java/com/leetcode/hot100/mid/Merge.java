package com.leetcode.hot100.mid;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:56. 合并区间
 * 以数组 intervals 表示若干个区间的集合，其中单个区间为 intervals[i] = [starti, endi] 。
 * 请你合并所有重叠的区间，并返回 一个不重叠的区间数组，该数组需恰好覆盖输入中的所有区间 。
 * @Date:Created in 2023/11/1
 * @Modified By:
 * @since DK 1.8
 */
public class Merge {
    /**
     * 示例 1：
     *
     * 输入：intervals = [[1,3],[2,6],[8,10],[15,18]]
     * 输出：[[1,6],[8,10],[15,18]]
     * 解释：区间 [1,3] 和 [2,6] 重叠, 将它们合并为 [1,6].
     * 示例 2：
     *
     * 输入：intervals = [[1,4],[                                                                                                                                                                                                              ,5]]
     * 输出：[[1,5]]
     * 解释：区间 [1,4] 和 [4,5] 可被视为重叠区间。
     * [[1,4],[2,3]]
     * @param intervals
     * @return
     */
    /**
     * 排序+双指针
     * @param intervals
     * @return
     */
    public int[][] merge2(int[][] intervals) {
        List<int[]> resList = new ArrayList<>();
        //排序
        Arrays.sort(intervals, Comparator.comparingInt(o -> o[0]));
        //双指针
        for (int i = 0; i < intervals.length;) {
            int r = intervals[i][1];
            int j =  i + 1;
            while (j < intervals.length && r >= intervals[j][0]){
                r = Math.max(intervals[j][1], r);
                j++;
            }
            resList.add(new int[]{intervals[i][0], r});
            i = j;
        }
        return resList.toArray(new int[0][0]);
    }
    //排序+合并
    public int[][] merge(int[][] intervals) {
        List<int[]> resList = new ArrayList<>();
        //排序
        Arrays.sort(intervals, Comparator.comparingInt(o -> o[0]));
        //合并
        for (int i = 0; i < intervals.length; i++) {
            int l = intervals[i][0];
            int r = intervals[i][1];
            if (resList.size() == 0 || resList.get(resList.size() - 1)[1] < intervals[i][0]){
                resList.add(new int[]{l, r});
            }else {
                int[] last = resList.get(resList.size() - 1);
                last[1] = Math.max(last[1], r);
            }
        }
        return resList.toArray(new int[0][0]);
    }

    public static void main(String[] args) {
        Merge merge = new Merge();
        int[][] arr = {{1, 3}, {2, 6}, {8, 10}, {15, 18}};
        int[][] merge1 = merge.merge2(arr);
//        for (int[] ints : arr) {
//            System.out.println("["+ints[0]+","+ ints[1]+"]");
//        }
        for (int[] ints : merge1) {
            System.out.println("["+ints[0]+","+ ints[1]+"]");
        }

    }
}
