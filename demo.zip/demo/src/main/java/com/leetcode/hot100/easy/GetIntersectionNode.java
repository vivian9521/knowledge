package com.leetcode.hot100.easy;

import com.leetcode.ListNode;

/**
 * @Auther:vivian
 * @Description:160. 相交链表
 * 给你两个单链表的头节点 headA 和 headB ，请你找出并返回两个单链表相交的起始节点。如果两个链表不存在相交节点，
 * 返回 null 。
 * @Date:Created in 2023/11/6
 * @Modified By:
 * @since DK 1.8
 */
public class GetIntersectionNode {

    public ListNode getIntersectionNode(ListNode headA, ListNode headB) {
        ListNode ha = headA;
        ListNode hb = headB;
        while (ha != hb){
            ha = ha == null ? headB : ha.next;
            hb = hb == null ? headA : hb.next;
        }
        return ha;
    }

    public static void main(String[] args) {
        GetIntersectionNode getIntersectionNode = new GetIntersectionNode();
        getIntersectionNode.getIntersectionNode(new ListNode(1, new ListNode(2, new ListNode(5))), new ListNode(3, new ListNode(4)));
    }
}
