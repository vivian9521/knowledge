package com.leetcode.hot100.mid;

import com.leetcode.ListNode;
import com.leetcode.Node;

import java.util.HashMap;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:138. 随机链表的复制
 * @Date:Created in 2023/11/8
 * @Modified By:
 * @since DK 1.8
 */
public class CopyRandomList {
    /**
     * 需要恢复原链表和提前给随机节点赋值
     * @param head
     * @return
     */
    public Node copyRandomList(Node head) {
        if (head == null){
            return head;
        }

        Node cur = head;
        while (cur != null){
            Node next = cur.next;
            Node node = new Node(cur.val);
            cur.next = node;
            node.next = next;

            cur = next;
        }
        cur = head;
        while (cur != null && cur.next != null){
            Node next = cur.next;
            next.random = cur.random == null ? null : cur.random.next;
            cur = cur.next.next;
        }
        cur = head;
        Node res = head.next;
        // 7 7 3 3 1 1
        while (cur != null && cur.next != null){
            Node newNode = cur.next;
            Node temp = cur.next.next;
            cur.next = cur.next.next;
            newNode.next = newNode.next == null ? null : newNode.next.next;

            cur = temp;
        }
        return res;
    }

    /**
     * 哈希表
     * @param head
     * @return
     */
    public Node copyRandomList2(Node head) {
        if (head == null) {
            return head;
        }
        Map<Node, Node> map = new HashMap<>();
        Node cur = head;
        while (cur != null){
            map.put(cur, new Node(cur.val));
            cur = cur.next;
        }
        cur = head;
        while (cur != null){
            map.get(cur).next = map.get(cur.next);
            map.get(cur).random = map.get(cur.random);
            cur = cur.next;
        }
        return map.get(head);
    }
    public static void main(String[] args) {
        CopyRandomList copyRandomList = new CopyRandomList();
        Node node = new Node(7);
        node.next = new Node(3);
        copyRandomList.copyRandomList(node);
    }
}
