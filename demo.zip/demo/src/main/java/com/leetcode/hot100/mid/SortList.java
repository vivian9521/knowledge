package com.leetcode.hot100.mid;

import com.leetcode.ListNode;

import java.util.PriorityQueue;
import java.util.Queue;

/**
 * @Auther:vivian
 * @Description:148. 排序链表
 * 给你链表的头结点 head ，请将其按 升序 排列并返回 排序后的链表 。
 * @Date:Created in 2023/11/8
 * @Modified By:
 * @since DK 1.8
 */
public class SortList {
    /**
     * 归并排序（递归法）
     * @param head
     * @return
     */
    public ListNode sortList(ListNode head) {
        if (head == null || head.next == null){
            return head;
        }
        //快慢指针获取中点
        ListNode slow = head;
        ListNode fast = head.next;
        while (fast != null && fast.next != null){
            slow = slow.next;
            fast = fast.next.next;
        }
        ListNode rightNode = slow.next;
        slow.next = null;
        ListNode left = sortList(head);
        ListNode right = sortList(rightNode);
        //归并
        ListNode res = new ListNode(0);
        ListNode h = res;
        while (left != null && right != null){
            if (left.val < right.val){
                h.next = left;
                left = left.next;
            }else {
                h.next = right;
                right = right.next;
            }
            h = h.next;
        }
        h.next = left != null ? left : right;

        return res.next;

    }

    public ListNode sortList2(ListNode head) {
        if (head == null){
            return head;
        }
        Queue<Integer> queue = new PriorityQueue<>();
        ListNode cur = head;
        while (cur != null){
            queue.add(cur.val);
            cur = cur.next;
        }
        ListNode newHead = new ListNode(0);
        ListNode res = newHead;
        while (!queue.isEmpty()){
            res.next = new ListNode(queue.poll());
            res = res.next;
        }
        return newHead.next;
    }
}
