package com.leetcode.hot100.mid;

/**
 * @Auther:vivian
 * @Description:55. 跳跃游戏
 * 给你一个非负整数数组 nums ，你最初位于数组的 第一个下标 。数组中的每个元素代表你在该位置可以跳跃的最大长度。
 *
 * 判断你是否能够到达最后一个下标，如果可以，返回 true ；否则，返回 false 。
 * @Date:Created in 2023/11/24
 * @Modified By:
 * @since DK 1.8
 */
public class CanJump {

    public boolean canJump(int[] nums) {
        int k = 0;
        for (int i = 0; i <= k; i++) {
            //当前位置到下一个位置最远距离
            int temp = i + nums[i];

            k = Math.max(temp, k);

            if (k >= nums.length - 1){
                return true;
            }
        }
        return false;
    }
}
