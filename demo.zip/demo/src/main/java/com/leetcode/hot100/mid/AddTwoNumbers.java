package com.leetcode.hot100.mid;

import com.leetcode.ListNode;

/**
 * @Auther:vivian
 * @Description:2. 两数相加
 * 给你两个 非空 的链表，表示两个非负的整数。它们每位数字都是按照 逆序 的方式存储的，并且每个节点只能存储 一位 数字。
 *
 * 请你将两个数相加，并以相同形式返回一个表示和的链表。
 *
 * 你可以假设除了数字 0 之外，这两个数都不会以 0 开头。
 * @Date:Created in 2023/11/7
 * @Modified By:
 * @since DK 1.8
 */
public class AddTwoNumbers {

    public ListNode addTwoNumbers(ListNode l1, ListNode l2) {
        ListNode res = new ListNode(0);
        ListNode cur = res;
        ListNode c1 = l1;
        ListNode c2 = l2;
        boolean carry = false;
        while (c1 != null || c2 != null){
            int remain = c1 != null && c2 != null ? (c1.val + c2.val)%10 : c1 == null ? c2.val : c1.val;

            int val = carry ? remain + 1 :remain;
            cur.next = new ListNode(val%10);

            carry = (c1 != null && c2 != null && (c1.val + c2.val)>=10) || (val >= 10);

            cur = cur.next;
            if (c1 != null){
                c1 = c1.next;
            }
            if (c2 != null){
                c2 = c2.next;
            }
        }
        if (carry){
            cur.next = new ListNode(1);
        }
        return res.next;
    }

    public static void main(String[] args) {
        AddTwoNumbers addTwoNumbers = new AddTwoNumbers();
        addTwoNumbers.addTwoNumbers(new ListNode(2, new ListNode(4, new ListNode(3))), new ListNode(5, new ListNode(6, new ListNode(4))));
    }
}
