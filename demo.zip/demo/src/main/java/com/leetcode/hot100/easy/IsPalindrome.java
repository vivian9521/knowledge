package com.leetcode.hot100.easy;

import com.leetcode.ListNode;
import com.leetcode.algorithm.HeapSort;

import java.util.LinkedList;

/**
 * @Auther:vivian
 * @Description:234. 回文链表
 * 给你一个单链表的头节点 head ，请你判断该链表是否为回文链表。如果是，返回 true ；否则，返回 false 。
 * @Date:Created in 2023/11/6
 * @Modified By:
 * @since DK 1.8
 */
public class IsPalindrome {
    //递归
    private ListNode frontPointer;
    public boolean isPalindrome2(ListNode head) {
        frontPointer = head;
        return check(head);
    }
    private boolean check(ListNode head){
        if (head != null){
            if (!check(head.next)){
                return false;
            }
            if (head.val != frontPointer.val){
                return false;
            }
            frontPointer = frontPointer.next;
        }
        return true;
    }
    //快慢指针
    public boolean isPalindrome(ListNode head) {
        if (head == null){
            return false;
        }
       //获取后半部分链表
        ListNode slow = head;
        ListNode fast = head;
        while (fast != null){
            slow = slow.next;
            fast = fast.next == null ? null : fast.next.next;
        }
        //反转后半部分链表
        ListNode revertLastNode = null;
        while (slow != null){
            ListNode temp = slow.next;
            slow.next = revertLastNode;
            revertLastNode = slow;
            slow = temp;
        }
        //前半部分和后半部分反转链表对比
        ListNode cur = head;
        while (revertLastNode != null){
            if (cur.val != revertLastNode.val){
                return false;
            }
            cur = cur.next;
            revertLastNode = revertLastNode.next;
        }
        return true;
    }

    public static void main(String[] args) {
        IsPalindrome isPalindrome = new IsPalindrome();
        boolean palindrome = isPalindrome.isPalindrome(new ListNode(1, new ListNode(2, new ListNode(2, new ListNode(1)))));
        System.out.println(palindrome);
    }
}
