package com.leetcode.hot100.mid;

import java.util.Arrays;
import java.util.zip.ZipEntry;

/**
 * @Auther:vivian
 * @Description:73. 矩阵置零
 * 给定一个 m x n 的矩阵，如果一个元素为 0 ，则将其所在行和列的所有元素都设为 0 。请使用 原地 算法。
 * @Date:Created in 2023/11/3
 * @Modified By:
 * @since DK 1.8
 */
public class SetZeroes {
    /**
     * 示例 1：
     * 输入：matrix = [[1,1,1],[1,0,1],[1,1,1]]
     * 输出：[[1,0,1],[0,0,0],[1,0,1]]
     * 示例 2：
     * 输入：matrix = [[0,1,2,0],[3,4,5,2],[1,3,1,5]]
     * 输出：[[0,0,0,0],[0,4,5,0],[0,3,1,0]]
     * @param matrix
     */
    //使用一个标记变量
    public void setZeroes3(int[][] matrix) {
        int m = matrix.length;
        int n = matrix[0].length;
        boolean flagCol0 = false;
        for (int i = 0; i < m; i++) {
            //先标记是否第一列存在0,第一列的第一个元素即可以标记第一行是否出现 0
            if (matrix[i][0] == 0){
                flagCol0 = true;
            }
            for (int j = 1; j < n; j++) {
                if (matrix[i][j] == 0){
                    matrix[i][0] = matrix[0][j] = 0;
                }
            }
        }
        //但为了防止每一列的第一个元素被提前更新，我们需要从最后一行开始，倒序地处理矩阵元素。
        for (int i = m - 1; i >= 0; i--) {
            for (int j = 1; j < n; j++) {
                if (matrix[i][0] == 0 || matrix[0][j] == 0){
                    matrix[i][j] = 0;
                }
            }
            if (flagCol0){
                matrix[i][0] = 0;
            }
        }
    }
    public void setZeroes2(int[][] matrix) {
        if (matrix.length == 0){
            return;
        }
        int m = matrix.length;
        int n = matrix[0].length;
        boolean[] row = new boolean[m];
        boolean[] col = new boolean[n];
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
                if (matrix[i][j] == 0){
                    row[i] = true;
                    col[j] = true;
                }
            }
        }
        for (int i = 0; i < m; i++) {
            for (int j = 0; j < n; j++) {
               if (row[i] || col[j]){
                   matrix[i][j] = 0;
               }
            }
        }
    }
    public void setZeroes(int[][] matrix) {
        if (matrix.length == 0){
            return;
        }
        boolean[][] bool = new boolean[matrix.length][matrix[0].length];
        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                if (matrix[i][j] == 0 && !bool[i][j]){
                    int top = i - 1, down = i + 1, left = j - 1, right = j + 1;
                    while (top >= 0){
                        if (!(matrix[top][j] == 0 && !bool[top][j])){
                            bool[top][j] = true;
                        }
                        matrix[top][j] = 0;
                        top--;
                    }
                    while (down < matrix.length){
                        if (!(matrix[down][j] == 0 && !bool[down][j])){
                            bool[down][j] = true;
                        }
                        matrix[down][j] = 0;
                        down++;
                    }
                    while (left >= 0){
                        if (!(matrix[i][left] == 0 && !bool[i][left])){
                            bool[i][left] = true;
                        }
                        matrix[i][left] = 0;
                        left--;
                    }
                    while (right < matrix[0].length){
                        if (!(matrix[i][right] == 0 && !bool[i][right])){
                            bool[i][right] = true;
                        }
                        matrix[i][right] = 0;
                        right++;
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        int[][] nums = new int[][]{{0,1,2,0},{3,4,5,2},{1,3,1,5}};
        SetZeroes zeroes = new SetZeroes();
        zeroes.setZeroes(nums);
        for (int[] num : nums) {
            System.out.print("[");
            for (int i : num) {
                System.out.print(i+",");
            }
            System.out.println("]");
        }
    }
}
