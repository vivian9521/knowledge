package com.leetcode.hot100.mid;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:189. 轮转数组
 * 给定一个整数数组 nums，将数组中的元素向右轮转 k 个位置，其中 k 是非负数。
 * @Date:Created in 2023/11/2
 * @Modified By:
 * @since DK 1.8
 */
public class Rotate {
    /**
     * 示例 1:
     *
     * 输入: nums = [1,2,3,4,5,6,7], k = 3
     * 输出: [5,6,7,1,2,3,4]
     * 解释:
     * 向右轮转 1 步: [7,1,2,3,4,5,6]
     * 向右轮转 2 步: [6,7,1,2,3,4,5]
     * 向右轮转 3 步: [5,6,7,1,2,3,4]
     * 示例 2:
     *
     * 输入：nums = [-1,-100,3,99], k = 2
     * 输出：[3,99,-1,-100]
     * 解释:
     * 向右轮转 1 步: [99,-1,-100,3]
     * 向右轮转 2 步: [3,99,-1,-100]
     * @param nums
     * @param k
     */
    public void rotate(int[] nums, int k) {
        if (k == 0){
            return;
        }
        k = k % nums.length;
        int[] res = new int[nums.length];

        for (int i = 0; i < nums.length; i++) {
            if (i < k){
                res[i] = nums[i + nums.length - k ];
            }else{
                res[i] = nums[i - k];
            }
        }
        System.arraycopy(res, 0, nums, 0, res.length);
        Arrays.stream(nums).forEach(System.out::println);
    }

    public void rotate2(int[] nums, int k) {
        int n = nums.length;
        int[] newArr = new int[n];
        for (int i = 0; i < n; ++i) {
            newArr[(i + k) % n] = nums[i];
        }
        System.arraycopy(newArr, 0, nums, 0, n);
    }

    /**
     * 数组反转
     * 我们可以先将所有元素翻转，这样尾部的 k mod nk\bmod nkmodn 个元素就被移至数组头部，
     * 然后我们再翻转 [0,k mod n−1] 区间的元素和 [k mod n,n−1]区间的元素即能得到最后的答案。
     * @param nums
     * @param k
     */
    public void rotate3(int[] nums, int k) {
        k %= nums.length;
        reverse(nums, 0 , nums.length - 1);
        reverse(nums, 0, k - 1);
        reverse(nums, k, nums.length - 1);
    }
    private void reverse(int[] nums, int start, int end){
        while (start < end){
            int temp = nums[start];
            nums[start] = nums[end];
            nums[end] = temp;
            start ++;
            end--;
        }
    }
    public static void main(String[] args) {
        Rotate rotate = new Rotate();
//        int[] arr = {1, 2, 3, 4, 5, 6, 7};
//        int[] arr = {-1,-100,3,99};
        int[] arr = {1, 2};

        rotate.rotate(arr, 3);
//        Arrays.stream(arr).forEach(System.out::println);

    }
}
