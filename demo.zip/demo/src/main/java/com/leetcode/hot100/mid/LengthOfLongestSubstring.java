package com.leetcode.hot100.mid;

import java.util.HashMap;
import java.util.Map;

/**
 * @Auther:vivian
 * @Description:3. 无重复字符的最长子串
 *给定一个字符串 s ，请你找出其中不含有重复字符的 最长子串 的长度。
 * @Date:Created in 2023/10/26
 * @Modified By:
 * @since DK 1.8
 */
public class LengthOfLongestSubstring {
    /**
     * 示例 1:
     *
     * 输入: s = "abcabdcbb"
     * 输出: 3
     * 解释: 因为无重复字符的最长子串是 "abc"，所以其长度为 3。
     * 示例 2:
     *
     * 输入: s = "bbbbb"
     * 输出: 1
     * 解释: 因为无重复字符的最长子串是 "b"，所以其长度为 1。
     * 示例 3:
     *
     * 输入: s = "pwwkew"
     * 输出: 3
     * 解释: 因为无重复字符的最长子串是 "wke"，所以其长度为 3。
     *      请注意，你的答案必须是 子串 的长度，"pwke" 是一个子序列，不是子串。
     * @param s
     * @return
     */
    public int lengthOfLongestSubstring(String s) {
        if (s == null || s.length() == 0){
            return 0;
        }
        int res = 0;
        char[] c = s.toCharArray();
        Map<Character, Integer> map = new HashMap<>();
        int start = 0;
        for (int i = 0; i < c.length; i++) {
            if (map.containsKey(c[i])){
                res = Math.max(res, s.substring(start, i).length());
                Integer index = map.get(c[i]);
                start = Math.max(index + 1, start);
            }
            map.put(c[i], i);
        }
        if (start < c.length){
            res = Math.max(res, s.substring(start).length());
        }
        return res;
    }

    public static void main(String[] args) {
//        StringBuilder builder = new StringBuilder();
//        builder.append("s");
//        builder.append("a");
//        builder.append("b");
//        builder.delete(0, 1);
//        System.out.println(builder.toString());
        LengthOfLongestSubstring lengthOfLongestSubstring = new LengthOfLongestSubstring();
        int num = lengthOfLongestSubstring.lengthOfLongestSubstring("abba");
        System.out.println(num);
    }
}
