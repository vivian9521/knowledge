package com.leetcode.hot100.easy;

import com.leetcode.ListNode;

/**
 * @Auther:vivian
 * @Description:206. 反转链表
 * 给你单链表的头节点 head ，请你反转链表，并返回反转后的链表。
 * @Date:Created in 2023/11/6
 * @Modified By:
 * @since DK 1.8
 */
public class ReverseList {

    public ListNode reverseList(ListNode head) {
        if (head == null){
            return head;
        }
        ListNode cur = head;
        ListNode res = null;
        while (cur != null){
            ListNode temp = cur.next;
            cur.next = res;
            res = cur;
            cur = temp;
        }
        return res;
    }

    public static void main(String[] args) {
        ReverseList reverseList =new ReverseList();
        reverseList.reverseList(new ListNode(1,new ListNode(2, new ListNode(3))));
    }
}
