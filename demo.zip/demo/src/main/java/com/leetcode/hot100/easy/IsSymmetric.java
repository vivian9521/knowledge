package com.leetcode.hot100.easy;

import com.leetcode.TreeNode;

import java.rmi.dgc.Lease;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * @Auther:vivian
 * @Description:101. 对称二叉树
 * 给你一个二叉树的根节点 root ， 检查它是否轴对称。
 * @Date:Created in 2023/11/9
 * @Modified By:
 * @since DK 1.8
 */
public class IsSymmetric {
    public boolean isSymmetric(TreeNode root) {
        if (root == null){
            return true;
        }
        return recver(root.left, root.right);
    }

    private boolean recver(TreeNode left, TreeNode right){
        if (left == null && right == null){
            return true;
        }
        if (left == null || right == null){
            return false;
        }
        if (left.val == right.val){
            return recver(left.left, right.right) && recver(right.left, left.right);
        }else {
            return false;
        }
    }

    public boolean isSymmetric2(TreeNode root) {
        if (root == null){
            return true;
        }
        LinkedList<TreeNode> queue = new LinkedList<>();
        queue.offer(root);
        queue.offer(root);
        while (!queue.isEmpty()){
            TreeNode u = queue.poll();
            TreeNode v = queue.poll();
            if (u == null && v == null){
                continue;
            }
            if (u == null || v == null || u.val != v.val){
                return false;
            }
            queue.offer(u.left);
            queue.offer(v.right);
            queue.offer(u.right);
            queue.offer(v.left);
        }
        return true;
    }
}
