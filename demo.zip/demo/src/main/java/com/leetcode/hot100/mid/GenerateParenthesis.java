package com.leetcode.hot100.mid;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @Auther:vivian
 * @Description:22. 括号生成
 * 数字 n 代表生成括号的对数，请你设计一个函数，用于能够生成所有可能的并且 有效的 括号组合。
 * @Date:Created in 2023/11/17
 * @Modified By:
 * @since DK 1.8
 */
public class GenerateParenthesis {
    List<String> res = new ArrayList<>();
    public List<String> generateParenthesis(int n) {
        if (n <= 0) return null;

        def("", 0, 0, n);

        return res;
    }

    public void def(String paths, int left, int right, int n) {

        if (left > n || right > left) return;
        if (paths.length() == n * 2) {
            res.add(paths);
            return;
        }
        def(paths + "(", left + 1, right, n);
        def(paths + ")", left, right + 1, n);
    }


    public List<String> generateParenthesis2(int n) {
        List<String> res = new ArrayList<>();
        recur("", n, n, res);
        return res;
    }

    private void recur(String str, int left, int right, List<String> res){
        if (left == 0 && right == 0){
            res.add(str);
            return;
        }
        if (left == right){
            recur(str+"(", left - 1, right, res);
        }else if (left < right){
            if (left > 0){
                recur(str + "(", left - 1, right, res);
            }
            recur(str + ")", left, right - 1, res);
        }
    }

    public static void main(String[] args) {
        GenerateParenthesis generateParenthesis = new GenerateParenthesis();
        List<String> list = generateParenthesis.generateParenthesis(4);
        System.out.println(list);
    }
}
