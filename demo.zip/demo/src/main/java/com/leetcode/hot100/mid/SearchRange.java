package com.leetcode.hot100.mid;

import java.util.Arrays;

/**
 * @Auther:vivian
 * @Description:34. 在排序数组中查找元素的第一个和最后一个位置
 * 给你一个按照非递减顺序排列的整数数组 nums，和一个目标值 target。请你找出给定目标值在数组中的开始位置和结束位置。
 *
 * 如果数组中不存在目标值 target，返回 [-1, -1]。
 *
 * 你必须设计并实现时间复杂度为 O(log n) 的算法解决此问题。
 * @Date:Created in 2023/11/20
 * @Modified By:
 * @since DK 1.8
 */
public class SearchRange {
    /**
     * 两次二分
     * @param nums
     * @param target
     * @return
     */
    public int[] searchRange(int[] nums, int target) {
        int l = 0, r = nums.length - 1;
        int left = 0, right = nums.length - 1;
        //左侧边界
        while (left <= right){
            int mid = left + (right - left)/2;
            if (nums[mid] >= target){
                right = mid - 1;
            }else {
                left = mid + 1;
            }
        }
        l = left;
        left = 0;
        right = nums.length - 1;
        while (left <= right){
            int mid = left + (right - left)/2;
            if (nums[mid] <= target){
                left = mid + 1;
            }else {
                right = mid - 1;
            }
        }
        r = right;
        return l > r ? new int[]{-1,-1} : new int[]{l, r};
    }

    /**
     * 二分查找+区间放大
     * @param nums
     * @param target
     * @return
     */
    public int[] searchRange2(int[] nums, int target) {
        int left = 0;
        int right = nums.length - 1;
        while (left <= right){
            int mid = left + (right - left)/2;
            if (nums[mid] == target) {
                int l = mid - 1;
                while (l >= 0){
                    if (nums[l] != target){
                        break;
                    }
                    l--;
                }
                int r = mid + 1;
                while (r <= nums.length - 1){
                    if (nums[r] != target){
                        break;
                    }
                    r++;
                }
                return new int[]{l+1, r-1};
            }else if (nums[mid] < target){
                left = mid + 1;
            }else {
                right = mid - 1;
            }
        }
        return new int[]{-1,-1};
    }

    public static void main(String[] args) {
        SearchRange searchRange = new SearchRange();
        int[] ints = searchRange.searchRange(new int[]{5,7,7,8,8,10}, 6);
        Arrays.stream(ints).forEach(System.out::println);
    }
}
