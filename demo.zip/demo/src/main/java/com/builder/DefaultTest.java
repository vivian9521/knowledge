package com.builder;

import com.defaulttest.DefaultClass;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/3/30
 * @Modified By:
 * @since DK 1.8
 */
public class DefaultTest {
    public static void main(String[] args) {
        DefaultClass a=new DefaultClass();
        a.method();
    }
}
