package com.builder;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2020/10/28 15:47
 * @Modified By:
 */
public class BuilderDemo {
    /**账号*/
    private String userName;

    /**密码*/
    private String password;

    /**年龄*/
    private int age;

    /**性别*/
    private String sex;



    @Override
    public String toString() {
        return "User{" +
                "userName='" + userName + '\'' +
                ", password='" + password + '\'' +
                ", age=" + age +
                ", sex='" + sex + '\'' +
                '}';
    }

    public static class Builder {

        /**账号*/
        private String userName;

        /**密码*/
        private String password;

        /**年龄*/
        private int age;

        /**性别*/
        private String sex;

        public Builder userName(String userName) {
            this.userName = userName;
            return this;
        }

        public Builder password(String password) {
            this.password = password;
            return this;
        }

        public Builder age(int age) {
            this.age = age;
            return this;
        }

        public Builder sex(String sex) {
            this.sex = sex;
            return this;
        }

        public BuilderDemo build() {
            return new BuilderDemo(this);
        }

    }

    private BuilderDemo(Builder b) {
        this.age = b.age;
        this.password = b.password;
        this.sex = b.sex;
        this.userName = b.userName;
    }

    public static void main(String[] args) {
//        BuilderDemo user = new Builder().age(10).password("abc").sex("男").userName("张三").build();
//        System.out.println(user.toString());
        StringBuilder patctPks=new StringBuilder();
        patctPks.append("1");
        patctPks.append(",");
        patctPks.append("2");
        patctPks.append(",");
        System.out.println(patctPks);
        System.out.println(patctPks.substring(0,patctPks.length()-1));
    }

}
