package com.builder;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/3/29
 * @Modified By:
 * @since DK 1.8
 */
public enum a {
    ADD(1,"新增");

    a(int i, String name) {
    }
}
