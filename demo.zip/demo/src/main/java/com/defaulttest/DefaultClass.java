package com.defaulttest;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/3/30
 * @Modified By:
 * @since DK 1.8
 */
public class DefaultClass implements DefaultInterface{
    String name;

    @Override
    public void method() {
        System.out.println("-----------------------");
    }

    @Override
    public void method1() {

    }

//    @Override
//    public void doSomeThing() {
//        System.out.println("#################doSomething               ");
//    }
}
