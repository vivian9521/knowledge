package com.extendstest;

/**
 * @Auther:vivian
 * @Description:
 * @Date:Created in 2022/3/30
 * @Modified By:
 * @since DK 1.8
 */
public class Animal {
    public String name;
    public Animal() {
    }
    public Animal(String name) {
        this.name = name;
    }

    public void eat() {
        System.out.println(this.name + " 正在吃");
    }

}
class Bird extends Animal {
    public String name = "乌鸦";

    public Bird() {
        super();
//        this("");
    }
    public Bird(String name) {
//        super();
        this();
    }

    public void fly() {
        System.out.println(super.name);
        //调用父类的成员变量
        super.eat();
        // 调用父类的构造方法
        System.out.println(this.name + "起飞");
        //调用自己的成员变量
    }

    public static void main(String[] args) {
        Bird bird = new Bird("麻雀");
        bird.fly();
    }
}




